# Actual-main Linux race artifact

The original artifact from Core run **44856110228**, Linux job **136698603892**, was independently downloaded and inspected after successful completion. This is a new push execution of actual main `87651d36558a8e421e41fbd76c514045d88c74ed`; no premerge test counts were used as inputs to the classification.

- Provider artifact: **14689307829**, `test-evidence-ubuntu-24.04`.
- Original ZIP: `circula-actual-main-linux-test-evidence.zip`, **138,870 bytes**.
- ZIP SHA-256: `df5b84d700ad1193afe6244178384fc8ae7fa02eeab2fbe8482220661af89a54`, independently matching provider metadata and the upload log.
- Recorded checkout: `87651d36558a8e421e41fbd76c514045d88c74ed`; `dirty=false`; test process exit code **0**.
- Recorded command: `go test -json -count=1 -race -timeout 30m ./...`.
- Recorded source SHA-256: `9de685071744f0b9e260d53fc7d934cb4289c3b10f84a020db8e319227b77100`, matching a separate read-only calculation over **2,023 source inputs** with only generated `docs/TRACEABILITY.md` excluded.
- Terminal event range: **2026-11-21 02:44:03.322552027 UTC–03:13:38.969671289 UTC**.

## Independently computed counts

| Category | Pass | Fail | Skip | Total |
|---|---:|---:|---:|---:|
| All recorded terminal events | 3,274 | 0 | 8 | 3,282 |
| Named tests and subtests | 3,258 | 0 | 6 | 3,264 |
| Top-level named entries | 1,293 | 0 | 6 | 1,299 |
| Top-level `Test` functions | 1,270 | 0 | 6 | 1,276 |
| Top-level `Fuzz` seed entries | 23 | 0 | 0 | 23 |
| Subtests | 1,965 | 0 | 0 | 1,965 |
| Packages | 16 | 0 | 2 | 18 |

These categories overlap deliberately: top-level entries and subtests partition named results; named results and packages partition all terminal results. A package pass is not an additional test case. No duplicate terminal identities or unknown terminal actions were found.

## Recorded skips and their limits

The six named skips are `TestBackupStagingRefusesForeignOwnedParent`, `TestBackupWorkLeaseChild`, `TestRestoreSwapCrashChild`, `TestLoadConcurrentTrades`, `TestLoginTimingStatistical`, and `TestQA010CrashChild`. Two packages, `internal/storetest` and `internal/testutil`, have no tests and are recorded as skipped.

The compact artifact records terminal actions, not runtime skip text. `skip-guard-review.json` preserves the corresponding inspected actual-main source guards: one test requires Unix root ownership facilities, three are subprocess helper entry points, and the load and statistical sign-in timing tests are opt-in. The separate actual-main API/load smoke job executes the load test. This artifact does not establish statistical timing acceptance or reference-hardware load acceptance.

## Reproducibility and files

`provider-artifact.json` preserves the full provider metadata. `result.json` records both member hashes, classification, all skips, and twelve passing validation checks. `../inspect_linux_artifact.py` contains the standalone standard-library inspection code; `../source-digest/` contains the independent source-fingerprint calculation and receipt. The ZIP is retained byte-for-byte, including both its JSON evidence and generated Markdown traceability report.

Passing cited tests do not independently establish acceptance of every requirement. This review did not execute product tests, modify a checkout, or alter any remote state.
