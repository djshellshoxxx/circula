# Actual-main native-reader and scorecard qualification

Independent read-only observation: **20 November 2026, 18:53:05 America/Los_Angeles**
(21 November, 02:53:05 UTC). Actual main remains
`87651d36558a8e421e41fbd76c514045d88c74ed`.

All four reviewed jobs completed successfully on the actual main commit. Each
complete log was fetched separately, its checkout identity was inspected, and
the decoded UTF-8 bytes were preserved in a deterministic gzip file. Windows
line endings and ANSI sequences remain in the raw record. No product tests were
rerun and no repository, PR, workflow, automation, or remote setting was changed.

## Three native-reader jobs

Workflow [44856110230](https://github.com/djshellshoxxx/circula/actions/runs/44856110230)
has three successful jobs, all with `head_sha` equal to actual main. Each log
contains the checkout/revision output for that same SHA and the explicit
`git rev-parse HEAD`/`git ls-tree` evidence step. These are actual-main push
executions, distinct from the earlier synthetic PR merge executions.

| Platform | Job | Recorded interpreter | Test result |
|---|---:|---|---|
| macOS 15 Intel | 136698603597 | Python 3.14.7 | 49 tests in 39.853 seconds; OK. |
| Ubuntu 24.04 | 136698603854 | Python 3.12.3 | 49 tests in 9.843 seconds; OK. |
| Windows 2022 | 136698603942 | Python 3.12.10 | 49 tests in 20.876 seconds; OK. |

Each run reports **zero failures and zero skipped tests**. The logs contain a
single `Ran 49 tests` summary and unqualified `OK`, without a skipped suffix or
failure marker. The same three recorded source blobs appear on all platforms
and were compared with the local actual-main Git tree:

| Path | Git blob |
|---|---|
| `.github/workflows/export-reader.yml` | `7c251a76694d4f6670ed2442f5a54cef0007d198` |
| `scripts/read-export.py` | `60e6d81d990c0a0e6078f93543e2a2eb051411f3` |
| `scripts/test_read_export.py` | `e3a87bad71ba1725995da5333086bd33876c64b3` |

## Scorecard execution and findings

Workflow [44856110197](https://github.com/djshellshoxxx/circula/actions/runs/44856110197),
job **136698602978**, completed successfully. The checkout output and embedded
Scorecard result both identify actual main. The analysis uploaded successfully.
Scorecard v5.6.0 records an overall score of **5.9** and eighteen individual checks.

Workflow success is execution success. It does not mean every criterion is met.
The recorded findings include:

- Branch protection: 0; protection not enabled on the checked main branch.
- Code review: 0; zero of two sampled changesets had GitHub approval reviews.
- License: 0; no project license file detected.
- Security policy: 4; policy detected, with linked-content limitations.
- Pinned dependencies: 8; two container base images use tags without digests.
- SAST: 0 under the detector's coverage criteria. This is the Scorecard result,
  not a claim that the separate Go lint/security job did not run.
- Maintained: 0 because the repository is less than ninety days old.
- Packaging and signed releases: -1 because no qualifying publication/release
  was detected. They are not failed reader tests.

The other check results and their exact reasons/details are preserved in
`result.json`. The scanner's zero detected known vulnerabilities is limited to
that check; it does not close the separately documented source, policy,
professional-review, or release-acceptance work.

## Evidence

- `provider-observation.json`: full provider job records and actual-main ref.
- `result.json`: extracted checkout evidence, native results and unchanged
  embedded Scorecard JSON.
- `log-manifest.json`: compressed/uncompressed byte lengths and SHA-256 values.
- `logs/*.log.gz`: four full decoded provider logs, preserved without content
  edits. Decompression was checked against the captured bytes.
- `SHA256SUMS`: checksums for this package, excluding itself.

This subreview qualifies only these three reader jobs and the successful
execution of Scorecard. The parent reviewer owns the nine Core jobs and the
combined actual-main qualification conclusion. Historical PR closure remains
the coordinator's guarded action after all applicable post-merge checks pass.
