#!/usr/bin/env python3
"""Inspect a downloaded actual-main test artifact without executing project code."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def counts(events):
    return {key: sum(e.get("Action") == key for e in events)
            for key in ("pass", "fail", "skip")}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("metadata", type=Path)
    parser.add_argument("source_baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--head", required=True)
    args = parser.parse_args()
    raw = args.archive.read_bytes()
    meta = json.loads(args.metadata.read_text())
    baseline = json.loads(args.source_baseline.read_text())
    baseline_digest = baseline.get("source_digest", baseline.get("digest"))
    with zipfile.ZipFile(args.archive) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate archive member names")
        member_data = {name: archive.read(name) for name in names}
    json_names = [n for n in names if Path(n).name == "traceability-results.json"]
    if len(json_names) != 1:
        raise ValueError("Expected exactly one traceability-results.json")
    evidence = json.loads(member_data[json_names[0]])
    events = evidence["results"]
    named = [e for e in events if e.get("Test")]
    top = [e for e in named if "/" not in e["Test"]]
    sub = [e for e in named if "/" in e["Test"]]
    packages = [e for e in events if not e.get("Test")]
    duplicates = [{"package": key[0], "test": key[1], "count": count}
                  for key, count in Counter((e.get("Package"), e.get("Test"))
                                             for e in events).items()
                  if count > 1]
    unknown = [e for e in events if e.get("Action") not in ("pass", "fail", "skip")]
    times = sorted(e["Time"] for e in events if e.get("Time"))
    validations = {
        "archive_sha256_matches_provider": meta.get("digest") == "sha256:" + digest(raw),
        "archive_size_matches_provider": meta.get("size_in_bytes") == len(raw),
        "provider_run_matches": meta.get("workflow_run", {}).get("id") == 44856110228,
        "provider_head_matches": meta.get("workflow_run", {}).get("head_sha") == args.head,
        "recorded_head_matches": evidence.get("head") == args.head,
        "recorded_clean_tree": evidence.get("dirty") is False,
        "recorded_source_digest_matches_independent_baseline": evidence.get("source_digest") == baseline_digest,
        "recorded_exit_zero": evidence.get("exit_code") == 0,
        "command_is_uncached_race_suite": evidence.get("command") == ["go", "test", "-json", "-count=1", "-race", "-timeout", "30m", "./..."],
        "no_duplicate_terminal_results": not duplicates,
        "no_unknown_terminal_actions": not unknown,
        "no_failed_terminal_results": counts(events)["fail"] == 0,
    }
    result = {
        "artifact_id": meta["id"],
        "archive_file": args.archive.name,
        "archive_bytes": len(raw),
        "archive_sha256": digest(raw),
        "provider_artifact_metadata_file": args.metadata.name,
        "source_baseline_file": str(args.source_baseline),
        "members": [{"name": n, "bytes": len(data), "sha256": digest(data)}
                    for n, data in member_data.items()],
        "recorded_evidence": {k: v for k, v in evidence.items() if k != "results"},
        "terminal_counts": {"total": len(events), **counts(events)},
        "named_test_counts": {"total": len(named), **counts(named)},
        "top_level_counts": {"total": len(top), **counts(top)},
        "top_level_test_function_counts": counts([e for e in top if e["Test"].startswith("Test")]),
        "top_level_fuzz_entry_counts": counts([e for e in top if e["Test"].startswith("Fuzz")]),
        "subtest_counts": {"total": len(sub), **counts(sub)},
        "package_counts": {"total": len(packages), **counts(packages)},
        "first_terminal_at": times[0] if times else None,
        "last_terminal_at": times[-1] if times else None,
        "skipped_events": [e for e in events if e.get("Action") == "skip"],
        "failed_events": [e for e in events if e.get("Action") == "fail"],
        "duplicate_terminal_results": duplicates,
        "unknown_terminal_actions": unknown,
        "validations": validations,
        "qualified": all(validations.values()),
        "scope": "Actual-main Linux race execution only. Passing cited tests do not independently establish whole-requirement acceptance."
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    if not result["qualified"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
