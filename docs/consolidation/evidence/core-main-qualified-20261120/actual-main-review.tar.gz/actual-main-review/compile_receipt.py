#!/usr/bin/env python3
"""Combine independently fetched actual-main observations and decoded job logs."""
import gzip
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
HEAD = "87651d36558a8e421e41fbd76c514045d88c74ed"
TREE = "43e65ee91a90ff70b70cc69d0b517b8367a2585f"
PARENTS = ["aa01563fcc891da60fefebb8335eca27855678e8", "3ef43ac1e05360d2a1641742dc056afe8871879b"]
EXPECTED = {
    44856110228: [136698603681, 136698603787, 136698603858, 136698603892, 136698603901, 136698603910, 136698603986, 136698604023, 136698604084],
    44856110230: [136698603597, 136698603854, 136698603942],
    44856110197: [136698602978],
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    provider = json.loads((ROOT / "final-provider-observation.json").read_text())
    linux = json.loads((ROOT / "linux-artifact/result.json").read_text())
    native = json.loads((ROOT / "native-and-scorecard/result.json").read_text())
    jobs = []
    log_manifest = []
    workflow_checks = []
    for run in provider["workflows"]:
        metadata, observed = run["metadata"], run["jobs"]["jobs"]
        run_id = metadata["id"]
        workflow_checks.append({
            "id": run_id,
            "head_sha": metadata["head_sha"],
            "event": metadata["event"],
            "status": metadata["status"],
            "conclusion": metadata["conclusion"],
            "expected_job_set_matches": sorted(j["id"] for j in observed) == sorted(EXPECTED[run_id]),
            "actual_main_push": metadata["head_sha"] == HEAD and metadata["event"] == "push",
        })
        for job in observed:
            folder = "core" if run_id == 44856110228 else "native-and-scorecard"
            log_path = ROOT / folder / "logs" / (str(job["id"]) + ".log.gz")
            compressed = log_path.read_bytes()
            raw = gzip.decompress(compressed)
            lines = [re.sub(r"^\S+\s", "", line).rstrip("\r") for line in raw.decode("utf-8").split("\n")]
            witnesses = []
            for index, line in enumerate(lines[:-1]):
                if "log -1 --format=%H" in line and re.fullmatch("[0-9a-f]{40}", lines[index+1].strip()):
                    witnesses.append({"command": line, "head": lines[index+1].strip()})
            explicit_head = bool(witnesses) and all(w["head"] == HEAD for w in witnesses)
            log_manifest.append({
                "job_id": job["id"], "run_id": run_id,
                "path": str(log_path.relative_to(ROOT)),
                "decoded_utf8_bytes": len(raw), "decoded_utf8_sha256": sha(raw),
                "gzip_bytes": len(compressed), "gzip_sha256": sha(compressed),
                "checkout_witnesses": witnesses,
            })
            jobs.append({
                "id": job["id"], "run_id": run_id, "name": job["name"],
                "url": job["html_url"], "status": job["status"], "conclusion": job["conclusion"],
                "head_sha": job.get("head_sha"), "started_at": job["started_at"], "completed_at": job["completed_at"],
                "explicit_checkout_matches": explicit_head,
                "skipped_steps": [s["name"] for s in job["steps"] if s["conclusion"] == "skipped"],
                "failed_steps": [s["name"] for s in job["steps"] if s["conclusion"] in ("failure", "cancelled", "timed_out")],
                "package_pass_lines": [line for line in lines if re.match(r"ok\s+github\.com/djshellshoxxx/circula/", line)],
            })
    gates = {
        "main_ref_unchanged": provider["main_ref"]["object"]["sha"] == HEAD,
        "commit_tree_matches": provider["main_commit"]["tree"]["sha"] == TREE,
        "ordered_parents_match": [p["sha"] for p in provider["main_commit"]["parents"]] == PARENTS,
        "all_three_expected_runs": sorted(w["id"] for w in workflow_checks) == sorted(EXPECTED),
        "all_three_actual_main_pushes": all(w["actual_main_push"] for w in workflow_checks),
        "all_workflow_job_sets_match": all(w["expected_job_set_matches"] for w in workflow_checks),
        "all_three_runs_succeeded": all(w["status"] == "completed" and w["conclusion"] == "success" for w in workflow_checks),
        "all_thirteen_jobs_succeeded": len(jobs) == 13 and all(j["status"] == "completed" and j["conclusion"] == "success" for j in jobs),
        "all_thirteen_checkout_witnesses_match": len(jobs) == 13 and all(j["explicit_checkout_matches"] for j in jobs),
        "all_thirteen_job_heads_match": len(jobs) == 13 and all(j["head_sha"] == HEAD for j in jobs),
        "linux_artifact_qualified": linux["qualified"],
        "no_failed_steps": all(not j["failed_steps"] for j in jobs),
    }
    result = {
        "schema_version": 1, "observed_at_utc": provider["observed_at_utc"],
        "head": HEAD, "tree": TREE, "parents": PARENTS,
        "qualification": "complete" if all(gates.values()) else "pending-or-failed",
        "gates": gates, "workflows": workflow_checks, "jobs": jobs,
        "linux_evidence_summary": linux,
        "native_readers": [{"job_id": r["job_id"], "head": r["head"], "test_count": r["test_count"], "failed": r["failed"], "skipped": r["skipped"]} for r in native["readers"]],
        "scorecard_execution": {"job_id": native["scorecard_job_id"], "score": native["scorecard"]["score"], "checks": len(native["scorecard"]["checks"]), "note": "Job success confirms execution/upload, not satisfaction of every security criterion. Full findings are preserved in native-and-scorecard/result.json."},
        "scope": "Qualification of actual-main push executions. Premerge synthetic checkout results were not substituted. No product suite was rerun during this review; no remote state was changed.",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    (ROOT / "log-manifest.json").write_text(json.dumps(log_manifest, indent=2) + "\n")
    print(json.dumps({"qualification": result["qualification"], "gates": gates, "jobs": len(jobs), "logs": len(log_manifest)}, indent=2))
    if not all(gates.values()):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
