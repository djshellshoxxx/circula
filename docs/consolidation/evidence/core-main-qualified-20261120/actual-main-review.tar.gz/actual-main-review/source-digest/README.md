# Independent actual-main source fingerprint

Calculated at **19:08:32 America/Los_Angeles on 20 November 2026**
(21 November, 03:08:32 UTC) from the clean checkout at
`87651d36558a8e421e41fbd76c514045d88c74ed`.

The independently calculated source digest is:

`9de685071744f0b9e260d53fc7d934cb4289c3b10f84a020db8e319227b77100`

The Python calculation reproduces the algorithm in
`scripts/traceability/evidence.go`, Git blob
`9337e55a807611d8adcba437143ba6c49257103c`, without invoking Go or any product
test. It reads the exact `git ls-files --cached --others --exclude-standard -z`
input list, deduplicates and sorts path bytes, excludes generated
`docs/TRACEABILITY.md`, uses `lstat`, and frames every included input as
`path-byte-count:path:Go-file-mode:data-byte-count:` followed by its unchanged
data bytes. Symlinks would contribute their link-target bytes without being
followed. Unsupported file types are rejected as in the Go implementation.

## Observed inputs and stable-source checks

| Check | Result |
|---|---|
| HEAD before and after | `87651d36558a8e421e41fbd76c514045d88c74ed` |
| Git tree before and after | `43e65ee91a90ff70b70cc69d0b517b8367a2585f` |
| Git status before and after | Clean |
| Input name list | Unchanged during calculation |
| Listed source inputs | 2,024 |
| Included source inputs | 2,023 |
| Excluded listed inputs | One: `docs/TRACEABILITY.md` |
| Missing tracked inputs | Zero |
| Symlink inputs | Zero |
| Regular mode `-rw-r--r--` | 2,011 inputs |
| Executable mode `-rwxr-xr-x` | Twelve inputs |
| Source data bytes, excluding framing | 35,972,811 |

The result agrees with the previously reported digest, which was used only as a
comparison after the independent calculation. It is not an input to the hash.
The new calculation script and its own SHA-256 are recorded in `result.json`.

## Reproduce this read-only calculation

```sh
python3 calculate_source_digest.py /path/to/circula \
  --expected-head 87651d36558a8e421e41fbd76c514045d88c74ed
```

Keep this script and generated result outside the source checkout, or pass
explicit `--exclude` paths exactly as the Go recorder does. Additional ignored
files are already excluded by Git; additional nonignored source files would
correctly change the fingerprint.

This source-only result supports a later comparison with the actual-main Linux
artifact. **No match to that future artifact or execution of its tests is claimed
here.** The calculation did not modify the shared checkout. The included
symlink/mode handling follows the algorithm; this particular source contained
only the two regular-file modes listed above.
