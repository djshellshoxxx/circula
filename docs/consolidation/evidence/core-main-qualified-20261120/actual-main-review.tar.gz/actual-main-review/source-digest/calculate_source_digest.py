#!/usr/bin/env python3
"""Independently reproduce Circula's sourceDigest on a Unix checkout.

This reads source bytes only. It does not invoke Go or run product tests.
The framing and exclusions follow scripts/traceability/evidence.go at the
recorded Git source. File names remain bytes for Go-compatible sorting/lengths.
"""

from __future__ import annotations

import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess


def git(root: str, *args: str) -> bytes:
    return subprocess.check_output(["git", *args], cwd=root)


def unix_go_file_mode(mode: int) -> str:
    """Format the regular/symlink FileMode values produced by Go on Unix.

    Go uses an uppercase L type marker and separate u/g/t markers. Its final
    nine permission characters do not substitute POSIX s/S/t/T characters.
    Other file types are rejected before this function, as sourceDigest does.
    """
    flags = "L" if stat.S_ISLNK(mode) else ""
    for bit, letter in ((stat.S_ISUID, "u"), (stat.S_ISGID, "g"), (stat.S_ISVTX, "t")):
        if mode & bit:
            flags += letter
    permissions = "".join(
        letter if mode & (1 << bit) else "-"
        for bit, letter in zip(range(8, -1, -1), "rwxrwxrwx")
    )
    return (flags or "-") + permissions


def calculate(root: str, excluded: list[str]) -> dict:
    root = os.path.abspath(root)
    root_bytes = os.fsencode(root)
    before_head = git(root, "rev-parse", "HEAD").decode().strip()
    before_tree = git(root, "rev-parse", "HEAD^{tree}").decode().strip()
    before_status = git(root, "status", "--porcelain")
    raw_names = git(root, "ls-files", "--cached", "--others", "--exclude-standard", "-z")
    names = sorted(set(raw_names.removesuffix(b"\0").split(b"\0")))
    skip = {b"docs/TRACEABILITY.md"}
    for item in excluded:
        if not item:
            continue
        filename = item if os.path.isabs(item) else os.path.join(root, item)
        relative = os.path.relpath(os.path.abspath(filename), root)
        skip.add(os.fsencode(relative.replace(os.sep, "/")))

    digest = hashlib.sha256()
    modes: collections.Counter[str] = collections.Counter()
    included = skipped = deleted = symlinks = data_bytes = 0
    for name in names:
        if not name or name in skip:
            skipped += bool(name)
            continue
        filename = os.path.join(root_bytes, name.replace(b"/", os.fsencode(os.sep)))
        try:
            info = os.lstat(filename)
        except FileNotFoundError:
            deleted += 1
            continue
        if stat.S_ISLNK(info.st_mode):
            data = os.readlink(filename)
            symlinks += 1
        elif stat.S_ISREG(info.st_mode):
            with open(filename, "rb") as stream:
                data = stream.read()
        else:
            raise ValueError(f"unsupported source input {os.fsdecode(name)}")
        mode_text = unix_go_file_mode(info.st_mode)
        header = (
            str(len(name)).encode("ascii") + b":" + name + b":"
            + mode_text.encode("ascii") + b":"
            + str(len(data)).encode("ascii") + b":"
        )
        digest.update(header)
        digest.update(data)
        included += 1
        data_bytes += len(data)
        modes[mode_text] += 1

    after_head = git(root, "rev-parse", "HEAD").decode().strip()
    after_tree = git(root, "rev-parse", "HEAD^{tree}").decode().strip()
    after_status = git(root, "status", "--porcelain")
    after_names = git(root, "ls-files", "--cached", "--others", "--exclude-standard", "-z")
    if before_head != after_head or before_tree != after_tree or raw_names != after_names:
        raise RuntimeError("HEAD/tree/input names changed during source calculation")
    if before_status or after_status:
        raise RuntimeError("source checkout was not clean before and after calculation")

    algorithm_path = "scripts/traceability/evidence.go"
    algorithm_bytes = (Path(root) / algorithm_path).read_bytes()
    return {
        "schema_version": 1,
        "observed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "method": "Independent Python reproduction of the pinned Go sourceDigest algorithm; no product execution",
        "root": root,
        "head_before": before_head,
        "head_after": after_head,
        "tree_before": before_tree,
        "tree_after": after_tree,
        "clean_before": True,
        "clean_after": True,
        "input_name_list_unchanged": True,
        "unique_listed_inputs": sum(bool(n) for n in names),
        "included_inputs": included,
        "excluded_listed_inputs": skipped,
        "missing_tracked_inputs": deleted,
        "symlink_inputs": symlinks,
        "source_data_bytes": data_bytes,
        "go_file_mode_counts": dict(sorted(modes.items())),
        "excluded_relative_paths": [os.fsdecode(p) for p in sorted(skip)],
        "source_digest": digest.hexdigest(),
        "algorithm_source": {
            "path": algorithm_path,
            "git_blob": git(root, "rev-parse", before_head + ":" + algorithm_path).decode().strip(),
            "sha256": hashlib.sha256(algorithm_bytes).hexdigest(),
        },
        "calculation_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "evidence_limit": "This fingerprints current source inputs. No comparison with a future actual-main Linux artifact or execution of its tests is claimed.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root")
    parser.add_argument("--exclude", action="append", default=[])
    parser.add_argument("--expected-head")
    args = parser.parse_args()
    result = calculate(args.root, args.exclude)
    if args.expected_head and result["head_before"] != args.expected_head:
        raise SystemExit("source head does not equal the expected main")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
