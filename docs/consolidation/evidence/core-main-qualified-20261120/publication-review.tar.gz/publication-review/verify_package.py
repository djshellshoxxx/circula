from pathlib import Path, PurePosixPath
from collections import Counter
import datetime, gzip, hashlib, io, json, re, subprocess, tarfile, zipfile
ROOT=Path('/workspace/scratch/56ccc19d5666');REPO=ROOT/'circula-evidence';PKG=REPO/'docs/consolidation/evidence/core-main-qualified-20261120';OUT=ROOT/'circula-final-publication-review'
MAIN='87651d36558a8e421e41fbd76c514045d88c74ed';TREE='43e65ee91a90ff70b70cc69d0b517b8367a2585f';BASE='9f713dcb2157b66b4e2af7aec68a37b4a9057e6d';PARENTS=['aa01563fcc891da60fefebb8335eca27855678e8','3ef43ac1e05360d2a1641742dc056afe8871879b']
checks=[]
def digest(b):return hashlib.sha256(b).hexdigest()
def check(label,condition,details=None):checks.append({'check':label,'pass':bool(condition),'details':details})
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args]).decode().strip()
data={p.name:p.read_bytes() for p in PKG.iterdir() if p.is_file()}
def parsed(name):return json.loads(data[name])
def manifest_check(b,files,prefix=''):
    seen=[];errors=[]
    for line in b.decode().splitlines():
        h,n=line.split('  ',1);full=prefix+n;seen.append(full)
        if full not in files or digest(files[full])!=h:errors.append(full)
    return {'entries':len(seen),'duplicates':len(seen)-len(set(seen)),'errors':errors,'names':seen}
sha=manifest_check(data['SHA256SUMS'],data)
check('package_sha256',not sha['errors'] and not sha['duplicates'] and set(sha['names'])==set(data)-{'SHA256SUMS'},sha)
archive_results={};archived={}
for an,mn,prefix,source in [('actual-main-review.tar.gz','qualification-archive-manifest.json','actual-main-review/',ROOT/'circula-postmerge-review'),('provider-and-reconciliation.tar.gz','provider-archive-manifest.json','',ROOT)]:
    b=data[an];meta=parsed(mn)
    with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as t:
        members=t.getmembers();names=[m.name for m in members]
        safe=all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts and m.name.startswith(prefix) for m in members)
        files={m.name:t.extractfile(m).read() for m in members}
        metadata=all(m.mode==0o644 and m.uid==m.gid==m.mtime==0 and m.uname==m.gname=='' and not m.pax_headers for m in members)
    archived[an]=files
    errors=[m['path'] for m in meta['members'] if m['path'] not in files or len(files[m['path']])!=m['bytes'] or digest(files[m['path']])!=m['sha256']]
    originals=[]
    for n,v in files.items():
        p=source/(n[len(prefix):] if prefix else n);originals.append({'member':n,'byte_equal':p.is_file() and p.read_bytes()==v})
    bio=io.BytesIO()
    with tarfile.open(fileobj=bio,mode='w',format=tarfile.PAX_FORMAT) as t:
        for n in sorted(files):
            info=tarfile.TarInfo(n);info.size=len(files[n]);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';t.addfile(info,io.BytesIO(files[n]))
    rebuilt=gzip.compress(bio.getvalue(),compresslevel=9,mtime=0)
    a={'member_count':len(files),'member_names_unique':len(names)==len(files),'sorted':names==sorted(names),'safe_regular_paths':safe,'normalized_metadata':metadata,'gzip_mtime_zero':b[4:8]==b'\x00'*4,'byte_size':len(b),'sha256':digest(b),'archive_manifest_matches':meta['archive']==an and meta['bytes']==len(b) and meta['sha256']==digest(b),'member_manifest_errors':errors,'member_manifest_set_matches':set(files)=={m['path'] for m in meta['members']},'deterministic_rebuild_byte_equal':rebuilt==b,'original_source_checks':originals};archive_results[an]=a
    check('archive_'+an,all([a['member_names_unique'],a['sorted'],safe,metadata,a['gzip_mtime_zero'],a['archive_manifest_matches'],not errors,a['member_manifest_set_matches'],a['deterministic_rebuild_byte_equal'],all(x['byte_equal'] for x in originals)]),a)
qual=archived['actual-main-review.tar.gz']
for n,b in qual.items():
    if n.endswith('/SHA256SUMS'):
        m=manifest_check(b,qual,n.rsplit('/',1)[0]+'/');check('nested_sha256_'+n,not m['errors'] and not m['duplicates'],{'entries':m['entries'],'errors':m['errors']})
copies={'qualification-review.md':qual['actual-main-review/README.md'],'qualification-result.json':qual['actual-main-review/result.json'],'log-manifest.json':qual['actual-main-review/log-manifest.json'],'actual-main-linux-evidence.zip':qual['actual-main-review/linux-artifact/circula-actual-main-linux-test-evidence.zip'],'scope-review.md':(ROOT/'circula-final-scope-review/report.md').read_bytes(),'scope-review.json':(ROOT/'circula-final-scope-review/result.json').read_bytes()}
copy_results={n:data[n]==b for n,b in copies.items()};check('frozen_readable_copies',all(copy_results.values()),copy_results)
qr=parsed('qualification-result.json');provider=json.loads(qual['actual-main-review/final-provider-observation.json'])
check('qualification_main_identity',qr['head']==MAIN and qr['tree']==TREE and qr['parents']==PARENTS and provider['main_ref']['object']['sha']==MAIN and provider['main_commit']['tree']['sha']==TREE and [p['sha'] for p in provider['main_commit']['parents']]==PARENTS)
expected_sets={44856110228:{136698603681,136698603787,136698603858,136698603892,136698603901,136698603910,136698603986,136698604023,136698604084},44856110230:{136698603597,136698603854,136698603942},44856110197:{136698602978}}
workflows=[];rawjobs={}
for w in provider['workflows']:
    r=w['metadata'];jobs=w['jobs']['jobs'];ids={j['id'] for j in jobs};rawjobs.update({j['id']:j for j in jobs})
    workflows.append({'run_id':r['id'],'head':r['head_sha'],'event':r['event'],'status':r['status'],'conclusion':r['conclusion'],'job_count':len(jobs),'expected_jobs_match':ids==expected_sets.get(r['id']),'all_jobs_success':all(j['status']=='completed' and j['conclusion']=='success' and j['head_sha']==MAIN for j in jobs),'failed_steps':[{'job':j['id'],'name':s['name'],'conclusion':s['conclusion']} for j in jobs for s in j['steps'] if s['conclusion'] in ['failure','cancelled','timed_out','action_required']]})
check('all_13_provider_jobs',len(rawjobs)==13 and {w['run_id'] for w in workflows}==set(expected_sets) and all(w['head']==MAIN and w['event']=='push' and w['status']=='completed' and w['conclusion']=='success' and w['expected_jobs_match'] and w['all_jobs_success'] and not w['failed_steps'] for w in workflows),workflows)
logs=[];logtext={}
for e in parsed('log-manifest.json'):
    b=qual['actual-main-review/'+e['path']];decoded=gzip.decompress(b);s=decoded.decode();logtext[e['job_id']]=s;lines=s.splitlines();witnesses=[]
    for i,line in enumerate(lines[:-1]):
        if '[command]' in line and ' log -1 --format=%H' in line:witnesses.append({'command':line.split(' ',1)[-1],'head':lines[i+1].split(' ',1)[-1]})
    logs.append({'job_id':e['job_id'],'gzip_bytes':len(b),'gzip_sha256':digest(b),'decoded_bytes':len(decoded),'decoded_sha256':digest(decoded),'gzip_manifest_match':len(b)==e['gzip_bytes'] and digest(b)==e['gzip_sha256'],'decoded_manifest_match':len(decoded)==e['decoded_utf8_bytes'] and digest(decoded)==e['decoded_utf8_sha256'],'actual_checkout_witnesses':witnesses,'witness_manifest_match':witnesses==e['checkout_witnesses'],'actual_main_checkout':bool(witnesses) and all(x['head']==MAIN for x in witnesses),'provider_job_match':rawjobs[e['job_id']]['run_id']==e['run_id']})
check('all_13_full_log_hashes_and_actual_checkout',len(logs)==13 and all(x['gzip_manifest_match'] and x['decoded_manifest_match'] and x['witness_manifest_match'] and x['actual_main_checkout'] and x['provider_job_match'] for x in logs),logs)
with zipfile.ZipFile(io.BytesIO(data['actual-main-linux-evidence.zip'])) as z:zfiles={n:z.read(n) for n in z.namelist()};zip_corrupt=z.testzip()
ev=json.loads(zfiles['traceability-results.json']);events=ev['results']
def counts(entries):
    c=Counter(e['Action'] for e in entries);return {'total':sum(c.values()),'pass':c['pass'],'fail':c['fail'],'skip':c['skip']}
terminal=counts(events);named=counts([e for e in events if e.get('Test')]);top=counts([e for e in events if e.get('Test') and '/' not in e['Test']]);subs=counts([e for e in events if '/' in e.get('Test','')]);packages=counts([e for e in events if not e.get('Test')]);test=counts([e for e in events if e.get('Test','').startswith('Test') and '/' not in e['Test']]);fuzz=counts([e for e in events if e.get('Test','').startswith('Fuzz') and '/' not in e['Test']]);ids=[(e['Package'],e.get('Test','')) for e in events]
zipresults={'sha256':digest(data['actual-main-linux-evidence.zip']),'bytes':len(data['actual-main-linux-evidence.zip']),'corrupt_member':zip_corrupt,'recorded_evidence':{k:v for k,v in ev.items() if k!='results'},'members':[{'path':n,'bytes':len(b),'sha256':digest(b)} for n,b in zfiles.items()],'terminal_counts':terminal,'named_counts':named,'top_level_counts':top,'subtest_counts':subs,'package_counts':packages,'top_level_Test_counts':test,'top_level_Fuzz_counts':fuzz,'duplicate_event_count':len(ids)-len(set(ids)),'unknown_actions':sorted({e['Action'] for e in events}-{'pass','fail','skip'}),'reconciliation_targets':[e for e in events if any(w in e.get('Test','') for w in ['WALWrite','WALCommit','UUID'])]}
le=qr['linux_evidence_summary']
check('linux_original_zip_and_counts',zip_corrupt is None and zipresults['sha256']==le['archive_sha256'] and zipresults['bytes']==le['archive_bytes'] and all(zipresults[k]==le[v] for k,v in [('terminal_counts','terminal_counts'),('named_counts','named_test_counts'),('top_level_counts','top_level_counts'),('subtest_counts','subtest_counts'),('package_counts','package_counts')]) and ev['head']==MAIN and ev['dirty'] is False and ev['exit_code']==0 and not zipresults['duplicate_event_count'] and not zipresults['unknown_actions'],zipresults)
source=json.loads(qual['actual-main-review/source-digest/result.json'])
check('independent_source_digest',source['source_digest']==ev['source_digest']=='9de685071744f0b9e260d53fc7d934cb4289c3b10f84a020db8e319227b77100' and source['included_inputs']==2023 and source['head_before']==source['head_after']==MAIN,{'source_digest':source['source_digest'],'inputs':source['included_inputs']})
native=[]
for jid in [136698603597,136698603854,136698603942]:
    s=logtext[jid];native.append({'job_id':jid,'Ran_tests_counts':re.findall(r'Ran (\d+) tests? in [^\n]+',s),'OK_lines':len(re.findall(r'^.*?Z OK\s*$',s,re.M))})
check('native_readers_49_each',all(x['Ran_tests_counts']==['49'] and x['OK_lines']==1 for x in native),native)
browser=json.loads(qual['actual-main-review/core/browser-actual-main.json']);mac=json.loads(qual['actual-main-review/core/macos-actual-main.json']);browserlines=[s for s in logtext[browser['id']].splitlines() if '597 passed' in s];maclines=[s.split(' ',1)[-1] for s in logtext[mac['id']].splitlines() if re.search(r'Z ok\s+github\.com/',s)]
check('browser_597_and_mac_16',bool(browserlines) and len(maclines)==16 and maclines==mac['package_pass_lines'] and rawjobs[mac['id']]['completed_at']=='2026-11-21T03:22:54Z',{'browser_lines':browserlines,'mac_package_pass_lines':maclines,'mac_completed_at':rawjobs[mac['id']]['completed_at']})
artifact=json.loads(qual['actual-main-review/linux-artifact/provider-artifact.json'])
upload_lines=[line for s in logtext.values() for line in s.splitlines() if digest(data['actual-main-linux-evidence.zip']) in line]
check('linux_provider_artifact_and_upload_digest',artifact['id']==14689307829 and artifact['size_in_bytes']==len(data['actual-main-linux-evidence.zip']) and artifact['digest']=='sha256:'+digest(data['actual-main-linux-evidence.zip']) and artifact['workflow_run']['id']==44856110228 and artifact['workflow_run']['head_sha']==MAIN and bool(upload_lines),{'provider_artifact':artifact,'matching_upload_lines':upload_lines})
scope=parsed('scope-review.json');manifest_rows=[]
for m in scope['manifest_readback']['manifests']:
    b=m['content_utf8'].encode();j=json.loads(b);blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\x00'+b).hexdigest()
    manifest_rows.append({'id':m['id'],'head':m['head'],'hold_false':j['enabled'] is False and j['integration']=='HOLD' and j['id']==m['id'],'bytes_match':len(b)==m['bytes'],'sha256_match':digest(b)==m['sha256'],'git_blob_match':blob==m['expected_blob']==m['computed_git_blob']})
ref_rows=[r for r in scope['ref_and_pr_readback']['observations'] if r['kind']=='ref']
check('frozen_scope_15_actual_manifests_and_23_refs',len(manifest_rows)==15 and all(all(m[k] for k in ['hold_false','bytes_match','sha256_match','git_blob_match']) for m in manifest_rows) and len(ref_rows)==23 and all(r['actual_head']==r['expected_head'] for r in ref_rows) and len(scope['held_ancestry_recheck'])==7 and all(r['ancestor_exit']==1 and r['source_only_commits']>0 for r in scope['held_ancestry_recheck']),{'summary':scope['summary'],'manifest_rechecks':manifest_rows,'refs_observed_at_utc':scope['ref_and_pr_readback']['completed_at_utc'],'manifests_completed_at_utc':scope['manifest_readback']['completed_at_utc']})
score=json.loads(qual['actual-main-review/native-and-scorecard/result.json'])['scorecard']
check('scorecard_findings_qualified_limit',score['score']==5.9 and len(score['checks'])==18 and score['repo']['commit']==MAIN,{'score':score['score'],'criteria':len(score['checks']),'criteria_scores':[{'name':c['name'],'score':c['score']} for c in score['checks']]})
rootraw=json.loads(archived['provider-and-reconciliation.tar.gz']['circula-final-root-provider.json']);rootsum=parsed('root-provider-summary.json');rl=parsed('root-linux-verification.json')
root_matches=rootsum['observed_at_utc']==rootraw['observed_at_utc'] and rootsum['main']==rootraw['main_ref']['object']['sha']==MAIN and rootsum['tree']==rootraw['main_commit']['tree']['sha']==TREE and rootsum['parents']==[p['sha'] for p in rootraw['main_commit']['parents']]==PARENTS
for w in rootsum['workflows']:
    rid=w['id'];r=rootraw['run_'+str(rid)];js=rootraw['jobs_'+str(rid)]['jobs'];root_matches=root_matches and all(w[k]==r[k] for k in ['id','head_sha','event','status','conclusion','run_attempt']) and {j['id'] for j in w['jobs']}=={j['id'] for j in js}
check('root_compact_receipts_correspond',root_matches and rl['main']==MAIN and rl['archive_sha256']==zipresults['sha256'] and rl['archive_bytes']==zipresults['bytes'] and rl['source_digest']==ev['source_digest'] and rl['all_terminal_counts']=={k:terminal[k] for k in ['pass','skip']} and rl['named_counts']=={k:named[k] for k in ['pass','skip']} and all(e in events and e['Action']=='pass' for e in rl['reconciliation_relevant_test_results']),{'provider_observed_at_utc':rootraw['observed_at_utc'],'root_relevant_tests':rl['reconciliation_relevant_test_results']})
def unwrap(v):
    for _ in range(10):
        if isinstance(v,dict) and v.get('structuredContent') is not None:v=v['structuredContent'];continue
        if isinstance(v,dict) and isinstance(v.get('content'),str):
            try:v=json.loads(v['content']);continue
            except json.JSONDecodeError:pass
        return v
fresh=json.loads((OUT/'fresh-provider-readback.json').read_text());fresh_data={r['value']['name']:unwrap(r['value']['response']) for r in fresh['results'] if r['status']=='fulfilled'};expected_open={r['number']:r['head'] for r in parsed('reconciliation-result.json')['remaining_open_prs']}
check('fresh_main_and_five_open_drafts',fresh_data['main']['object']['sha']==MAIN and {p['number']:p['head']['sha'] for p in fresh_data['open_prs']}==expected_open and len(expected_open)==5 and all(p['state']=='open' and p['draft'] is True and p['merged_at'] is None and p['closed_at'] is None for p in fresh_data['open_prs']),{'started_at':fresh['began'],'completed_at':fresh['finished'],'main':fresh_data['main']['object']['sha'],'open_prs':[{'number':p['number'],'head':p['head']['sha'],'state':p['state'],'draft':p['draft'],'merged_at':p['merged_at'],'closed_at':p['closed_at']} for p in fresh_data['open_prs']]})
changed=git('diff','--cached','--name-status',BASE).splitlines();paths=[s.split('\t')[-1] for s in changed]
check('staged_documentary_scope',all(p.startswith('docs/consolidation/evidence/core-main-qualified-20261120/') or p=='docs/consolidation/CORE_POSTMERGE_CONTINUATION_20261120.md' for p in paths),{'base':git('rev-parse','HEAD'),'staged_tree':git('write-tree'),'path_count':len(paths),'paths':changed,'unstaged_diff':git('diff','--name-only')})
linkresults=[]
for p in [PKG/'README.md',REPO/'docs/consolidation/CORE_POSTMERGE_CONTINUATION_20261120.md',PKG/'qualification-review.md',PKG/'scope-review.md']:
    for _,target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',p.read_text()):
        if re.match(r'^(https?:|mailto:|#)',target):continue
        linkresults.append({'source':str(p.relative_to(REPO)),'target':target,'exists':(p.parent/target.split('#')[0]).exists()})
check('relative_markdown_links',all(x['exists'] for x in linkresults),linkresults)
result={'schema_version':1,'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC'),'main':MAIN,'base':BASE,'staged_tree':git('write-tree'),'checks':checks,'failures':[x['check'] for x in checks if not x['pass']],'scope':'Documentary integrity verification only; no product suite execution, shared worktree edits, or remote mutation.'}
(OUT/'integrity-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'failures':result['failures'],'staged_tree':result['staged_tree'],'archives':{n:{k:v for k,v in a.items() if k!='original_source_checks'} for n,a in archive_results.items()},'counts':{k:v for k,v in zipresults.items() if k.endswith('counts')},'relative_links':len(linkresults)},indent=2))
