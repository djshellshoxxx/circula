from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,sys,time
ROOT=Path("/workspace/scratch/bfba682cba37/circula")
EVIDENCE=Path("/workspace/scratch/bfba682cba37/validation-core-static-20261120")
PUBLISHED="be9a5731bc93dcbf7b57301a8d2538a13af360bd"
TREE="7ba56914025bccada81f90a326e05233c45189a7"
GO="/tmp/circula-runtime-4d30/go/bin/go"
BIN="/tmp/circula-runtime-4d30/bin/"
def git(*args):
 return subprocess.check_output(["git",*args],cwd=ROOT,text=True).strip()
def sha(data): return hashlib.sha256(data).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def mem():
 return {x.split(":",1)[0]:x.split(":",1)[1].strip() for x in Path("/proc/meminfo").read_text().splitlines() if x.startswith(("MemTotal:","MemAvailable:","SwapTotal:"))}
def hashes():
 paths=subprocess.check_output(["git","ls-files","-z"],cwd=ROOT).decode().split("\0")
 return {p:sha((ROOT/p).read_bytes()) for p in paths if p}
def source():
 return {"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"status":git("status","--porcelain"),"sha256":hashes()}
env=os.environ.copy()
env.update(PATH="/tmp/circula-runtime-4d30/go/bin:"+BIN+env.get("PATH",""),GOROOT="/tmp/circula-runtime-4d30/go",GOPATH="/tmp/circula-runtime-4d30/gopath",GOCACHE="/tmp/circula-runtime-4d30/gocache",GOTOOLCHAIN="local",GOWORK="off",GOFLAGS="-mod=readonly -p=1",GOMAXPROCS="1",GOGC="20",GOMEMLIMIT="1536MiB",CGO_ENABLED="1",GOVULNDB="https://vuln.go.dev")
phase=sys.argv[1]
if phase=="init":
 s=source()
 assert s["tree"]==TREE and not s["status"]
 assert git("rev-parse",PUBLISHED+"^{tree}")==TREE
 (EVIDENCE/"source-sha256.json").write_text(json.dumps(s["sha256"],indent=2)+"\n")
 versions=[]
 for name,command in [("go-version",[GO,"version"]),("golangci-version",[BIN+"golangci-lint","version"]),("golangci-buildinfo",[GO,"version","-m",BIN+"golangci-lint"]),("govulncheck-buildinfo",[GO,"version","-m",BIN+"govulncheck"])]:
  t=time.monotonic();p=subprocess.run(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
  (EVIDENCE/(name+".log")).write_bytes(p.stdout)
  versions.append({"name":name,"command":command,"exit_code":p.returncode,"elapsed_seconds":round(time.monotonic()-t,3),"log":name+".log","log_sha256":sha(p.stdout)})
  assert p.returncode==0
 assert b"go1.26.11" in (EVIDENCE/"go-version.log").read_bytes()
 assert b"version 2.15.0" in (EVIDENCE/"golangci-version.log").read_bytes()
 assert b"v1.1.4" in (EVIDENCE/"govulncheck-buildinfo.log").read_bytes()
 init={"observed_utc":utc(),"published_commit":PUBLISHED,"published_tree":TREE,"local_head":s["head"],"local_tree":s["tree"],"tracked_file_count":len(s["sha256"]),"source_sha256_file":"source-sha256.json","source_sha256_file_hash":sha((EVIDENCE/"source-sha256.json").read_bytes()),"environment":{k:env[k] for k in ["GOROOT","GOPATH","GOCACHE","GOTOOLCHAIN","GOWORK","GOFLAGS","GOMAXPROCS","GOGC","GOMEMLIMIT","CGO_ENABLED","GOVULNDB"]},"versions":versions,"tool_binary_sha256":{x:sha(Path(BIN+x).read_bytes()) for x in ["golangci-lint","govulncheck"]},"lint_configuration_sha256":sha((ROOT/".golangci.yml").read_bytes()),"memory":mem(),"scope":"Full root-module source with unchanged repository configuration; nested future modules are independently scoped. No changed-file lint filter, analyzer override, dependency change, tool replacement or scanner database substitute."}
 (EVIDENCE/"preflight.json").write_text(json.dumps(init,indent=2)+"\n")
 print(json.dumps({k:init[k] for k in ["observed_utc","published_commit","published_tree","local_head","tracked_file_count","memory"]}),flush=True)
 sys.exit(0)
settings={"lint":([BIN+"golangci-lint","run","--concurrency","1","--timeout","10m","--verbose","./..."],660),"govulncheck":([BIN+"govulncheck","-json","-db","https://vuln.go.dev","./..."],600),"mod-verify":([GO,"mod","verify"],180)}
command,limit=settings[phase]
if (EVIDENCE/(phase+".json")).exists() or (EVIDENCE/(phase+".log")).exists():raise SystemExit("Attempt already exists; never overwrite evidence")
before=source();expected=json.loads((EVIDENCE/"source-sha256.json").read_text());assert before["sha256"]==expected and before["tree"]==TREE and not before["status"]
record={"phase":phase,"published_commit":PUBLISHED,"published_tree":TREE,"local_head":before["head"],"command":command,"cwd":str(ROOT),"started_utc":utc(),"outer_timeout_seconds":limit,"memory_before":mem(),"source_sha256_file":"source-sha256.json","source_before_matches":True,"environment":json.loads((EVIDENCE/"preflight.json").read_text())["environment"]}
print(json.dumps({"phase":phase,"started_utc":record["started_utc"],"command":command}),flush=True)
(EVIDENCE/(phase+"-running.json")).write_text(json.dumps(record,indent=2)+"\n")
start=time.monotonic();timed_out=False
with (EVIDENCE/(phase+".log")).open("wb") as log:
 p=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:rc=p.wait(timeout=limit)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGTERM)
  try:rc=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
record.update(completed_utc=utc(),elapsed_seconds=round(time.monotonic()-start,3),exit_code=rc,outer_timed_out=timed_out,memory_after=mem())
after=source();record.update(source_after_matches=after["sha256"]==expected,local_head_after=after["head"],local_tree_after=after["tree"],git_status_after=after["status"])
record["source_changed_paths"]=[p for p in sorted(set(expected)|set(after["sha256"])) if expected.get(p)!=after["sha256"].get(p)]
data=(EVIDENCE/(phase+".log")).read_bytes();record.update(log=phase+".log",log_sha256=sha(data),log_bytes=len(data))
record["executed_successfully"]=rc==0 and not timed_out and record["source_after_matches"] and not after["status"]
(EVIDENCE/(phase+".json")).write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,indent=2),flush=True)
print("LOG TAIL\n"+"\n".join(data.decode(errors="replace").splitlines()[-18:]),flush=True)
sys.exit(0 if record["executed_successfully"] else 1)
