# Fresh recovered-module qualification — 2026-11-19

All fifteen exact archived module heads now have passing existing Linux race, vet, formatting, checksum and source-integrity checks with their genuine original dependencies. The previous 14-of-15 result remains preserved as a dated snapshot. A single later bounded notifications retry completed the remaining race gate; no earlier failed command was changed into a pass. These results do not approve known source defects or qualify later repairs.

| Module | Exact recovered head | Latest race | Test pass events | Latest vet | Source unchanged |
|---|---|---|---:|---|---|
| analytics | `ef4bdf87d2bc915b26d84e548ea4e6a478079006` | pass | 19 | pass | True |
| matching | `1a514bdff29ee3f1f0282a9833e64ab6cda51cd5` | pass | 49 | pass | True |
| receipts | `91529c5a3a4268ecf3a919e099ab9aca779aab2d` | pass | 87 | pass | True |
| areas | `999dcbf12ffcf2bdcd1764393c5f470fe3c6fbc3` | pass | 59 | pass | True |
| governance | `6a5af100877aa0117bb43a35eb625dab38ee67f2` | pass | 49 | pass | True |
| messaging | `5375bdf6ad5c48d2913c0581c4f8755b7c0f573a` | pass | 74 | pass | True |
| federation | `dc59d9b8349cebefb35278bd37ae5e4f207dd833` | pass | 46 | pass | True |
| pwa | `de148c469bf3c5b0c15dcedd7499be946f4eb09e` | pass | 37 | pass | True |
| discovery | `204dc2691f3a8c914ff2623b714f96e6d8b82968` | pass | 57 | pass | True |
| onboarding | `d91c66e8f4285944f2c780ea21801ca819c3b5eb` | pass | 43 | pass | True |
| qr | `08a09b2bb196403b26e87de32e3b0ac167cfa75e` | pass | 58 | pass | True |
| notifications | `ba454e1c14d35bdd90dca8379e890f2bca6281d7` | pass | 58 | pass | True |
| favorites | `47cef5958b7fcdd5d3cbfb5878d74b38b327ce68` | pass | 76 | pass | True |
| recurring | `a755732a02dfe0eaa884691d59a6f748f96039e7` | pass | 42 | pass | True |
| feed | `4340c712a2ef19eb5dbde32f7cd0d35b061a7ee7` | pass | 62 | pass | True |

Test pass events include subtests and fuzz seeds; they are not a count of independent requirements or a new fuzz campaign. PWA also passed 33 Node tests and QR 20 Node tests in the preserved first attempt.

Notifications at `ba454e1c14d35bdd90dca8379e890f2bca6281d7`, module tree `be42783f6bbb7cc1fdc443cbcff15fa54e540fc3`, completed its full real-driver race suite in 176.503 seconds wall time: 35 top-level tests, 58 passing test events, no failures or skips. The library reported 71.0% statement coverage and its CLI 83.8%. All 89 archived files were verified against their Git blobs before and after. The exact original `x/sys v0.49.0`, SQLite v1.60.1 and libc v1.77.1 graph was used. The low-memory serial retry adds only linker `-ldflags=-w` to omit DWARF metadata, uses the warmed private cache and monitors disk thresholds. It neither substitutes a driver/version nor filters assertions. No resource stop or compiler diagnostic occurred.

`ARCHIVE_MODULE_QUALIFICATION-attempt3.json` and `qualification-summary-14-of-15.json` preserve the earlier complete 14-of-15 observation. Attempts 1 and 2 retain their low-resource, temporary-directory, compiler and vet failures; the attempt-3 warm matching vet and three x/sys0.48 race completions remain intact. The current aggregate appends attempt 4 and keeps every old check and historical summary. All 952 recovered source blobs and dependency manifests remain unchanged through their recorded checks.

The aggregate records exact commands, toolchain, per-command logs, exit codes, timings and source checks. Tests used Go 1.26.11, CGO enabled and package parallelism 1 with existing real SQLite imports. Only Linux/amd64 was executed. Passing archive tests do not make the separately identified recurring/notification source defects correct, qualify repaired compositions, resolve active feed ownership, or bypass disabled/HOLD, Core integration, native/provider and external/manual gates.
