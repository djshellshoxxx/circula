// Extract selected production declarations for an isolated boundary probe.
package main

import (
	"bytes"
	"crypto/sha256"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"os"
	"strings"
)

func main() {
	if len(os.Args) != 3 {
		panic("extract <refusal.go> <output.go>")
	}
	raw, err := os.ReadFile(os.Args[1])
	if err != nil {
		panic(err)
	}
	fs := token.NewFileSet()
	f, err := parser.ParseFile(fs, os.Args[1], raw, 0)
	if err != nil {
		panic(err)
	}
	var b bytes.Buffer
	b.WriteString("package probe\nimport (\"regexp\"; \"strings\")\n")
	found := 0
	for _, d := range f.Decls {
		keep := false
		switch n := d.(type) {
		case *ast.FuncDecl:
			keep = n.Name.Name == "fieldDetail"
		case *ast.GenDecl:
			for _, s := range n.Specs {
				if v, ok := s.(*ast.ValueSpec); ok {
					for _, name := range v.Names {
						if name.Name == "choiceFixes" || name.Name == "machineChoices" {
							keep = true
						}
					}
				}
			}
		}
		if keep {
			if err := format.Node(&b, fs, d); err != nil {
				panic(err)
			}
			b.WriteByte('\n')
			found++
		}
	}
	if found != 3 {
		panic("production declarations changed; review extraction")
	}
	s := strings.ReplaceAll(b.String(), "messages.Text", "catalogueText")
	s = strings.ReplaceAll(s, "domain.FieldError", "fieldError")
	formatted, err := format.Source([]byte(s))
	if err != nil {
		panic(err)
	}
	if err := os.WriteFile(os.Args[2], formatted, 0600); err != nil {
		panic(err)
	}
	fmt.Printf("refusal.go SHA256 %x; 3 declarations; substitutions: messages.Text -> catalogueText, domain.FieldError -> fieldError\n", sha256.Sum256(raw))
}
