# Isolated validation catalogue-boundary proof

Source: djshellshoxxx/circula main 3faeed76c41467a75b09bc75e7185a98a92f8219.
This is not a production-web, service, HTTP, real-locale or full-CI test.

With the official Go 1.26.11 SDK, from this directory:

```
go build -o extract extract.go
./extract refusal.go extracted.go
go test -json -count=1 extracted.go probe_test.go
```

The last command is EXPECTED TO FAIL on this source: two controls pass and the
known listing-title detail bypasses the synthetic catalogue printer. The probe
extracts three production AST declarations. Only messages.Text and the field-error
type are substituted, as documented in extract.go. Test execution resets printer
calls after package-level choice-label initialization. Unknown literal data is
preserved and escaped by a real html/template in its control.

The first attempted `go run extract.go <source.go> <output.go>` failed Go argument
parsing (named files in multiple directories), before any probe ran. Building the
extractor and running its executable succeeded. No SQLite compile was attempted.
The archived result.jsonl is from the subsequent actual named-files test; exit 1.
No fixed/green implementation or full-web/HTTP acceptance is claimed.
