package probe

import (
	"regexp"
	"strings"
)

var choiceFixes = map[string]string{
	"counterparty_id":         catalogueText("validation.choice.counterparty_id"),
	"member_id":               catalogueText("validation.choice.member_id"),
	"related_transaction_id":  catalogueText("validation.choice.related_transaction_id"),
	"direction":               catalogueText("validation.choice.direction"),
	"category":                catalogueText("validation.choice.category"),
	"outcome":                 catalogueText("validation.choice.outcome"),
	"type":                    catalogueText("validation.choice.type"),
	"status":                  catalogueText("validation.choice.status"),
	"format":                  catalogueText("validation.choice.format"),
	"listing_id":              catalogueText("validation.choice.listing_id"),
	"terms_version":           catalogueText("validation.choice.terms_version"),
	"reason_code":             catalogueText("validation.choice.reason_code"),
	"confirm_open_grant_risk": catalogueText("validation.choice.confirm_open_grant_risk"),
}
var machineChoices = regexp.MustCompile(`^(required, )?(must be )?(one of )?[a-z_]+((, | or )[a-z_]+)+$`)

func fieldDetail(f fieldError) string {
	if _, choice := choiceFixes[f.Field]; choice && machineChoices.MatchString(f.Detail) {
		if strings.HasPrefix(f.Detail, "required") {
			return catalogueText("validation.detail.choice_required")
		}
		return catalogueText("validation.detail.choice_invalid")
	}
	return f.Detail
}
