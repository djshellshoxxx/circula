# Independent UX-047 validation-detail boundary assessment

Reviewed 2026-11-28 Pacific against private worktree main
`3faeed76c41467a75b09bc75e7185a98a92f8219` (`git rev-parse HEAD`).
No product change, Go/HTTP/browser execution, SQLite compilation or future-module
inspection was performed by this reviewer.

## Confirmed mechanism

`internal/service/listings.go:validateListing` trims the title and emits the exact
domain field detail `must be 1 to 120 characters` for an empty/whitespace title or
one longer than 120 runes. It does not emit a title `required` detail or a 100
character title limit. A nonempty title containing forbidden controls emits
`must not contain control or invisible formatting characters` through
`cleanListingText`.

`h_home.go:listingCreate` invokes `CreateListing` and sends its error to
`formFail`, which calls `c.refuse`. The listing form uses `novalidate`, so an empty
title is an ordinary reachable server validation case, subject to normal network
authentication/authorization and idempotency middleware. `refuse` inserts
`fieldDetail(f)` into the catalogue-owned `validation.field.message` wrapper.

`refusal.go:fieldDetail` only translates a machine-choice detail when its field
is in `choiceFixes`. Title is not in that map. It therefore returns the generated
English title detail unchanged. The current shared catalogue contains no matching
complete title-length detail message. A translated wrapper or correction cannot
translate this raw inner detail. This is a structural externalization gap under
UX-046/047, not a claim of incorrect current-English wording or an API bug.

## Minimal honest proof

A lightweight source-extracted pure-function probe is appropriate given the
known SQLite compilation memory limits. Extract `fieldDetail`, `choiceFixes` and
`machineChoices` from the exact production AST rather than copying their logic.
Instrument only the `messages.Text` selector with a probe printer. Check the exact
producer detail above, and include an already-catalogued fixed-choice positive
control plus an arbitrary unknown-detail passthrough control. The known generated
title detail must cross the catalogue boundary; it currently does not. Retain the
unmodified production-source digest and extraction/instrumentation description.

Such a probe can establish the pure presentation boundary and fail the proposed
externalization contract. It is not production-web compilation, a normal service
call, authenticated HTTP execution, whole-catalogue translation support, or CI
qualification. Source tracing establishes reachability; the probe alone does not
execute that whole route. Avoid naming an unimplemented catalogue key as though it
already exists or claiming a real translated locale was used.

## Repair/ownership boundary

A future repair should map only known generated field/detail combinations to
complete catalogue-owned messages. Preserve unknown, historical and arbitrary
details as escaped literal data; do not translate user-authored values or change
domain/API/audit details. Keep the existing field association, correction,
summary and contextual template escaping. Native real-web/HTTP regressions remain
required for implementation acceptance.

New message entries would modify shared `en.json`, explicitly excluded by #142's
current ownership instruction. This reviewer does not grant that coordination or
owner merge approval. Recording a proven boundary without changing that path is
appropriate; introducing a new loader solely to bypass the restriction is not.

#142/#143 source qualifications were not re-reviewed. No whole UX-047 completion,
manual screen-reader acceptance or external security acceptance is claimed.

## Follow-up: executed probe evidence review

Independently inspected `ux047-validation-proof/{extract.go,extracted.go,
probe_test.go,result.jsonl}` after the coordinator's native execution.
The generator selects exactly the three intended production declarations and
performs the two disclosed substitutions. The copied control flow and map/regex
match the reviewed source; the map's initialization-time synthetic printer calls
are reset before each test, so they do not contaminate the boundary assertions.

The original JSONL records two passing controls and one failing known-title
contract. The failure reports the exact raw service detail and an empty catalogue
call list. The unknown-detail control separately renders through ordinary
`html/template` and checks exact escaping. There are no skipped tests. The package
result is FAIL, not a passing qualification.

This supports the bounded structural gap and nothing broader. The probe uses a
synthetic printer, a same-shaped local field-error type and named-file compilation.
It does not execute actual `messages.Text`, `CreateListing`, the real web package,
HTTP middleware or a translated locale. Actual `validateListing` producer and route
reachability remain source-traced evidence. The initial malformed `go run`
generator invocation was a setup failure before tests, distinct from the later
successfully generated probe and its intentional failing contract.

Evidence review approved with no blocker under those precise limits. I did not
rerun tests or mutate product code. Implementation remains gated by shared
catalogue ownership, and real web/native qualification remains required later.
