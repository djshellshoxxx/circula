package probe

import (
	"bytes"
	"html/template"
	"strings"
	"testing"
)

type fieldError struct{ Field, Detail string }

var catalogueCalls []string

// Synthetic printer exposes catalogue use; it selects no supported locale.
func catalogueText(key string, args ...any) string {
	catalogueCalls = append(catalogueCalls, key)
	return "CATALOGUE[" + key + "]"
}
func TestExistingChoiceUsesCatalogue(t *testing.T) {
	catalogueCalls = nil
	got := fieldDetail(fieldError{"type", "must be offer or request"})
	if len(catalogueCalls) != 1 || !strings.HasPrefix(got, "CATALOGUE[") {
		t.Fatalf("choice control failed: %q calls=%v", got, catalogueCalls)
	}
}
func TestUnknownDetailRemainsLiteralAndEscaped(t *testing.T) {
	catalogueCalls = nil
	want := "authored 100% %! & <policy>"
	got := fieldDetail(fieldError{"future_field", want})
	if got != want || len(catalogueCalls) != 0 {
		t.Fatalf("fallback changed: %q", got)
	}
	var b bytes.Buffer
	if err := template.Must(template.New("escaped").Parse("<p>{{.}}</p>")).Execute(&b, got); err != nil {
		t.Fatal(err)
	}
	if b.String() != "<p>authored 100% %! &amp; &lt;policy&gt;</p>" {
		t.Fatalf("escaping changed: %s", &b)
	}
}
func TestKnownListingTitleDetailUsesCatalogue(t *testing.T) {
	catalogueCalls = nil
	// Exact service.validateListing detail for blank/overlong titles.
	got := fieldDetail(fieldError{"title", "must be 1 to 120 characters"})
	if len(catalogueCalls) == 0 || !strings.HasPrefix(got, "CATALOGUE[") {
		t.Fatalf("known application-authored listing detail bypasses catalogue: got %q calls=%v", got, catalogueCalls)
	}
}
