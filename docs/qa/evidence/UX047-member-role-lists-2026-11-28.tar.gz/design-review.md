# Independent UX-047 role-list design review

Reviewed 2026-11-28 Pacific against main
`3faeed76c41467a75b09bc75e7185a98a92f8219` in the fresh isolated worktree.
This reviewer made no product edits and ran no Go/browser/HTTP tests. No future
module or held policy was inspected.

## Finding and repair scope

`h_admin.go:newMemberRow` maps each domain role through the existing catalogue
labels and then flattens those labels with `strings.Join(roles, ", ")`.
`admin_members.html` prints that string. Current English labels/order are correct;
the structural issue is application-owned list composition rather than a wrong
role translation or authorization behavior.

A semantic unordered list is a coherent minimal independent repair. Each role is
an independent labelled item, not a sentence, so a `ul`/`li` structure removes the
language-specific punctuation without adding any catalogue entry or new loader.
Use the existing `memberRoleLabel` results as ordinary strings and render each
item through html/template's normal escaping. Preserve their input order, any
unknown historical role labels and duplicates if supplied; do not infer a domain
role policy from this presentation change. An empty role slice must retain the
existing catalogue-backed `admin.members.member_role` fallback.

The internal `memberRow.Roles` field can become `[]string`; source searches show
the only production builder/consumer are `newMemberRow` and this table template.
The embedded `Member` and `actionsFor(m)` must remain unchanged. No domain,
service, API, audit or permission field needs alteration.

## Semantics and layout

`ul` containing `li` is valid inside a table `td`, exposes the multiple items to
assistive technology, and needs no new ARIA role or label because the table column
already supplies the Roles heading. List semantics are evidence from source,
not a manual screen-reader pass. Do not claim that review occurred.

Existing `ul.rows` styling is unsuitable: it adds a border and 0.75rem vertical
padding to every role. A small scoped `ul.role-list` rule with zero margin and
`padding-inline-start:1.25rem` avoids large default margins/indent and remains
direction-aware. Do not hide list markers merely for inline comma-style layout;
visible markers and ordinary ul/li semantics are sufficient. Current responsive
table cells stack below 40rem, so verify this cell at the existing narrow/zoom
browser coverage rather than infer a browser pass from the CSS. No additional
interactive controls are introduced.

## Required proof

Write a failing lightweight test against the actual admin-members template before
the product change. A two-item role row must produce two escaped list items in
order, not a flattened string. Include zero roles (existing member fallback), one
role, reversed two-role order and an unknown hostile literal role. Preserve the
full web test's member-state/action-set assertions while converting the exact
`admin, reviewer` expectation to the exact label slice, and the hostile-role cell
assertion to escaped list markup. This is not weakening an assertion: it verifies
the new semantic structure and retains all data/permission contracts.

A lightweight real-template test can run within the existing messages package
without importing SQLite. It does not execute the member handler or service.
Full native web/HTTP/browser/CI checks remain necessary for acceptance; no result
is inferred here. Existing #142/#143 ownership and merge gates remain untouched.

## Verdict

No design blocker for the bounded semantic-role-list repair, conditional on the
red/green tests, escaping/state/action checks, focused CSS and required native
qualification. This review grants no merge authorization or whole UX-047
completion and does not re-review #142/#143.

## Implemented proposal source review

Independently inspected the actual local proposal on
`fix/ux047-semantic-member-roles-20261128`: `h_admin.go`,
`templates/admin_members.html`, `static/style.css`, the updated existing
`member_invitation_catalog_test.go`, and new
`messages/member_role_list_test.go`. No action