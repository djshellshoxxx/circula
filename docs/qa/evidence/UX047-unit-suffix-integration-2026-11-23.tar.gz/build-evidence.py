from pathlib import Path
import collections, gzip, hashlib, io, json, shutil, tarfile, zipfile

work = Path('ux047-unit-work')
root = Path('ux047-unit-evidence')
source = '980609562395bea7234474ba4359acc1ca145f51'
main = 'a1e424c7a4d16b1592f1b5ac978a22ffc09c1d5f'

def read(name):
    return json.loads((work / 'provider' / name).read_text())

main_jobs = {'vet, gofmt, golangci-lint, govulncheck','API contract and load smoke','reproducible build (two builds, same sha256)','test (windows-2022)','build release targets','e2e (Playwright, axe, keyboard)','test (ubuntu-24.04)','fuzz smoke (RB-017)','test (macos-15-intel)'}
source_jobs = main_jobs - {'test (windows-2022)','test (macos-15-intel)'}

for prefix, run_id, head, passed, skipped in [('pr',45272948641,source,7,1),('main',45278925063,main,9,0)]:
    run, jobs = read(prefix+'-run.json'), read(prefix+'-jobs.json')['jobs']
    assert (run['id'],run['head_sha'],run['status'],run['conclusion']) == (run_id,head,'completed','success')
    assert len(jobs) == passed+skipped and len({j['name'] for j in jobs}) == len(jobs)
    assert collections.Counter(j['conclusion'] for j in jobs) == ({'success':passed,'skipped':skipped} if skipped else {'success':passed})
    assert all(j['status']=='completed' and j['head_sha']==head and j['run_id']==run_id for j in jobs)
    if prefix == 'main':
        assert {j['name'] for j in jobs} == main_jobs
    else:
        assert {j['name'] for j in jobs if j['conclusion']=='success'} == source_jobs
        assert [j['name'] for j in jobs if j['conclusion']=='skipped'] == ['test (${{ matrix.os }})']
scorecard=read('main-scorecard-run.json')
assert (scorecard['id'],scorecard['head_sha'],scorecard['status'],scorecard['conclusion'])==(45278925544,main,'completed','success')
for prefix, head in [('pr','c456418a43314d8d89e9f0e52df6ae2172155028'),('main',main)]:
    p=work/'provider'/(prefix+'-test-evidence.zip'); data=p.read_bytes()
    artifacts=read(prefix+'-artifacts.json')['artifacts']; a=next(a for a in artifacts if a['name']=='test-evidence-ubuntu-24.04')
    assert a['digest']=='sha256:'+hashlib.sha256(data).hexdigest() and a['size_in_bytes']==len(data)
    with zipfile.ZipFile(p) as z:
        assert set(z.namelist())=={'traceability-results.json','TRACEABILITY-results.md'}
        result=json.loads(z.read('traceability-results.json'))
    assert result['head']==head and result['dirty'] is False and result['exit_code']==0
    assert result['source_digest']=='8ff2362a89abdbd6b4fc7ba61dfdda59a2e66d9b27b2a69cf2ab07f01c665fcb'
    assert collections.Counter(r['Action'] for r in result['results'] if r.get('Test'))=={'pass':3279,'skip':6}
    assert collections.Counter(r['Action'] for r in result['results'] if not r.get('Test'))=={'pass':16,'skip':2}

assert not root.exists(), 'Freeze directory already exists; inspect before rebuilding.'
root.mkdir()
shutil.copytree(work/'provider',root/'provider',ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.pyo'))
for p in list((root/'provider').rglob('*')):
    if p.is_dir() and p.name.endswith('-test-evidence'):
        shutil.rmtree(p)
shutil.copytree(work/'green',root/'source')
shutil.copyfile(work/'review.md',root/'unit-source-review.md')
shutil.copyfile('ux047-browser-investigation/REVIEW.md',root/'browser-investigation.md')
for name in ['red-native.log','merge-receipt.json','CONTINUATION.json','final-acceptance-review.md','build-evidence.py','validate-archive.py']:
    shutil.copyfile(work/name,root/name)
(root/'README.md').write_text('''# UX-047 existing currency suffix integration evidence

The external qualification report identifies exact source/main revisions and outcomes.
Checkpoint and red records preserve historical states; they are not current success claims.
CONTINUATION.json is a pre-publication assembly checkpoint; the external report and maintained PR define the final outcome.
The source/ folder holds pinned candidate files.
Original Linux ZIPs retain provider JSON/Markdown unchanged. Extracted duplicates are omitted.
Assistant-worker reviews are not external security or manual screen-reader qualification.
The new unit regression is one named subtest; the unit table has nineteen unnamed cases.
Six explicit named skips and all policy/locale/licence/manual/external/storage limits remain open.
No compiled release targets are included. MANIFEST.json hashes every payload by exact bytes.
''')
items=[]
for path in sorted(root.rglob('*')):
    if not path.is_file(): continue
    assert not path.is_symlink()
    data=path.read_bytes(); name=str(path.relative_to(root))
    assert path.suffix.lower() not in {'.exe','.dll','.so','.dylib','.o','.a','.wasm','.pyc','.pyo'}
    assert not data.startswith((b'\x7fELF',b'MZ'))
    items.append((name,data))
manifest={'version':1,'source':source,'main':main,'files':[{'path':n,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in items]}
manifest_bytes=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
output=Path('UX047-unit-suffix-integration-2026-11-23.tar.gz')
with output.open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0,compresslevel=9) as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as archive:
        for name,data in items+[('MANIFEST.json',manifest_bytes)]:
            entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0
            archive.addfile(entry,io.BytesIO(data))
data=output.read_bytes()
receipt={'file':str(output),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'payload_count':len(items),'git_blob_sha':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'manifest_sha256':hashlib.sha256(manifest_bytes).hexdigest()}
(work/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
