# Independent final acceptance and evidence review

Review checkpoint: 2026-11-23 Pacific. This read-only assistant-worker review
is outside the frozen payload directory. It is not an external security
assessment or a manual accessibility pass. macOS actual-main execution was
still pending at this checkpoint; complete-main qualification is not inferred.

## Product and acceptance

Zero bounded product/acceptance blockers. The actual prepared production diff
contains one helper-line replacement and a three-line `unit.plural` catalogue
entry. Existing exact fixed-point one/negative-one and case-insensitive
existing-s branches are unchanged. `%[1]ss` formats the name as string data
followed by the existing suffix. It introduces no amount conversion, artificial
CLDR quantity, new locale, irregular-noun decision or trusted-HTML value.
Names, amounts, ledger/storage behavior, mutation, authentication and tenant
selection remain unchanged. This is an existing English suffix externalization,
not a demonstrated wrong-English defect or complete unit/whole-UI localization.

The nineteen-case table is inside one existing parent test. One named catalogue
subtest is added under an existing parent; neither the table nor repeated runs
should be counted as nineteen new named events or additional unique coverage.
The focused regex retains every original selection and full race recorder.
No generated traceability inventory is manually changed; its native freshness
gate passed. The corrected catalogue and plain-text tests are meaningful
regressions for resource ownership, literal interpolation and template escaping.

## Independently recounted evidence

- Source run `45272948641` is completed/success, attempt 1, exact source
  `980609562395bea7234474ba4359acc1ca145f51`: seven applicable successes and
  one expected conditional native-matrix skip.
- PR ZIP artifact `14867144686`: 139,282 bytes, SHA-256
  `7f891b2c403dc4652c6b07cd05d7a7fed35df49e048866bebb9a8bae0be0eba9`.
  Its clean head is the exact synthetic checkout `c456418a43314d8d89e9f0e52df6ae2172155028`.
- Main ZIP artifact `14870930568`: 138,290 bytes, SHA-256
  `040cf62b3a411450a19368a462abe6246c724fb42c1cf9f4ef259ed57093dde0`.
  Its clean head is exact actual main `a1e424c7a4d16b1592f1b5ac978a22ffc09c1d5f`.
- Both original ZIP digests and sizes match their raw provider metadata. Both
  JSON records exit zero, share source digest
  `8ff2362a89abdbd6b4fc7ba61dfdda59a2e66d9b27b2a69cf2ab07f01c665fcb`,
  and independently recount 3,279 named passes, six named skips, sixteen
  package passes and two no-test package skips. The new unit subtest and all
  three affected parents passed in each record.
- Raw actual-main Windows log confirms full uncached non-race
  `go test -count=1 -timeout=20m ./...`: sixteen passing packages and two
  no-test packages. Raw actual-main browser log records 597 passed (9.2m).
- Actual-main Scorecard raw JSON identifies the exact main above and reports
  5.9 across eighteen checks. Its execution success does not resolve findings.
- The original red missing-key failure, subsequent overall cancellation,
  source PR success and actual-main integration are kept distinct. No failed
  result is promoted to green or erased.

## Archive and remaining final gates

The builder refuses incomplete final source/main/Scorecard run inputs and
checks exact heads, provider ZIP digests, source fingerprint and recorded counts
before freezing. It constructs deterministic regular-file payloads with exact
path/size/SHA-256 manifest entries and excludes compiled/cache outputs.
The separately authored validator additionally checks safe unique paths,
complete manifest inventory, byte hashes, provider run/head identities, exact
six skip names, new subtest/parent events, command, receipt/Git-blob identity
and optional full frozen-directory equality. Neither script authenticates a
fabricated provider input by itself; fresh provider reads and remote readback
remain necessary and are tracked separately.

Recommended hardening before freeze: pin exact source job-name membership and
the exact expected native skip; pin the now-known main ZIP ID/size/digest as
independent constants; reject Python bytecode extensions in the validator too.
These are validation-strength nits, not product blockers. Refresh the assembly
CONTINUATION checkpoint before freezing so its current CI state is accurate.

Final macOS result, all-nine exact-main status, final report placeholder
resolution, finished archive validation and remote two-file publication/readback
remain required. The final evidence-only commit must have qualified main as its
sole parent and add exactly the report and unchanged archive; it must not be
presented as separately executed product qualification.

UX-047 remains partial. Six named skips, bounded fuzz/load and packaging/smoke,
manual screen-reader, external security, locale/policy/licence decisions and
remaining storage read/fsync/truncate/uncertain-commit limits remain explicit.
No held policy PR or future module was inspected or changed in this review.

## Subsequent hardening review — before final macOS result

The original checkpoint above remains historical. The reviewer re-read the
updated builder, validator, CONTINUATION and report. The previously recommended
hardening is now present: both scripts pin the exact seven source job names and
literal expected native-matrix skip; the validator pins main artifact 14870930568,
138,290 bytes and SHA-256 040cf62b3a411450a19368a462abe6246c724fb42c1cf9f4ef259ed57093dde0;
compiled Python bytecode/cache outputs are excluded/rejected. CONTINUATION now
correctly records eight successful actual-main jobs and macOS as the sole
remaining gate. The source/main Linux fingerprint, artifact and Scorecard facts
are filled accurately in the report; placeholders remain for genuinely pending
qualification/publication values. Topic-preservation wording now describes
verified work rather than asserting every unrelated branch's live state.

Zero new acceptance or validation-design blockers. Include this review in the
payload before freeze if the final report identifies it as archived. Actual
macOS completion, all-nine completed-main metadata, frozen archive execution
and post-publication readback still remain gates; no final approval of those
unobserved outcomes is implied by this hardening review.

## Completed actual-main review — 2026-11-23 Pacific

The pending-macOS checkpoints above are historical. A fresh independent set of
connected GitHub reads now confirms actual main remains
`a1e424c7a4d16b1592f1b5ac978a22ffc09c1d5f`. Core run `45278925063` completed
successfully on attempt 1 with all nine exact-head job records completed/success.
Scorecard run `45278925544` also completed successfully on attempt 1 at the same
exact main; its reported 5.9 across eighteen checks remains an execution result,
not approval or closure of its findings.

The reviewer independently fetched raw macOS job `138057917597` logs. The full
command was `go test -race -count=1 -p 2 -timeout=45m ./...`; all sixteen
test-bearing packages passed, with two no-test packages and no cached test
results. Service 1683.577s, store 959.140s, web 636.410s and messages 1.323s.
This is the actual-main execution, not inference from source or another run.
The full workload and existing package/job limits were retained; no rerun was
needed for either corrected source qualification or actual-main qualification.

Together with the independently checked original Linux artifacts, native
Windows and browser results above, this closes applicable CI qualification for
this bounded suffix migration. Zero product, acceptance or provider-evidence
blockers remain. The final report must replace remaining result placeholders
with these observed values and continue to distinguish the one new named unit
subtest from the nineteen table cases, six named skips from passes, and source
versus actual-main executions. UX-047 remains partial.

Approved to freeze the reviewed payload and execute the independent archive
validator. Final archive inventory/hash validation, report placeholder readback
and remote two-file publication/ref/tree/commit/report/binary verification are
still subsequent gates. The evidence-only commit must not be claimed as a
separate product execution, and no owner, manual/external, future-module,
release, licence or history-change gate is closed by this review.
