# Independent unit-suffix correction review

Reviewed 2026-11-23 Pacific against the prepared green candidate and pinned base
9cb4cc0250db487d6fd4760227ce906c4ea5f58f. This is an assistant-worker source and
evidence review, not an external security or manual accessibility assessment.

Approved for publishing the correction candidate; zero source/security blockers.
Required exact-head CI and separate actual-main qualification remain outstanding.

The only product changes are the final unitFor return expression and the new
three-line unit.plural catalogue entry. The existing fixed-point exact-one and
negative-one comparison, case-insensitive existing-s handling, sign, amounts,
names, authentication, tenant selection and all stored state remain unchanged.
The pattern %[1]ss formats a string argument and then a literal English suffix;
arbitrary percent/dollar/Unicode/HTML-sensitive names remain argument data.
Text returns an ordinary string; no trusted-HTML conversion is introduced.
This is externalization of an existing suffix, not an irregular-noun correction,
additional-locale decision or completion of unit/whole-UI localization.

The nineteen-case TestUnitForPlural matrix preserves exact-one behavior at
precisions 0/1/2/4, both signs, zero, fractional and large integer amounts,
existing-s names with uppercase variants, and Unicode/percent/dollar/HTML text.
TestProposalMessageIsPlainText adds the catalogue-owned unit contract and
contextual html/template escaping; TestEveryCatalogueEntryFormats supplies the
new key's string argument. Existing imports suffice; the large constant fits
the explicitly int64-typed field. No new dependency or test symbol is added.

The raw native red log records the expected unknown-key panic in
TestProposalMessageIsPlainText/currency_unit_inflection_stays_catalogue_plain_text
under the extended early focused selection. No green result is inferred from
that failed job or the red workflow's eventual overall state. The corrected
workflow changes only the focused regex, retaining the full existing suite.

Catalogue JSON independently parses with duplicate-key rejection: 1,460 keys,
unit.plural exactly {"other":"%[1]ss"}. The no-index whitespace check emitted
no whitespace diagnostics (exit 1 reflects differing files). Go/compiler and
gofmt execution are unavailable here; compile and formatting conclusions are
source inspection only and native CI remains authoritative.

The source handoff, TODO, message guide and acceptance note accurately preserve
completed #130/#131/#132, the new bounded #133 scope, real red proof, outstanding
corrected-head/integration gates, held owner policies and explicit manual/fault
limits. Optional documentation clarity: label the superseded #132 paragraph
in TODO as historical and update MESSAGES' top current-record link to this new
unit-suffix record. Neither changes product acceptance or requires a policy choice.

No future module or held policy PR was inspected or changed. No publication,
merge, deployment, release, licence choice or branch/history mutation was
performed by this reviewer.
