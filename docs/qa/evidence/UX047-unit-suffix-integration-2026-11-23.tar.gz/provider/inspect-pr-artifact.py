from pathlib import Path
import collections
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parent
metadata = json.loads((root / 'pr-artifacts.json').read_text())
artifacts = [a for a in metadata['artifacts'] if a['name'] == 'test-evidence-ubuntu-24.04']
assert len(artifacts) == 1
artifact = artifacts[0]
assert artifact['workflow_run']['id'] == 45272948641
assert artifact['workflow_run']['head_sha'] == '980609562395bea7234474ba4359acc1ca145f51'
path = root / 'pr-test-evidence.zip'
raw = path.read_bytes()
checksum = hashlib.sha256(raw).hexdigest()
assert artifact['digest'] == 'sha256:' + checksum
assert artifact['size_in_bytes'] == len(raw)
with zipfile.ZipFile(path) as archive:
    assert len(archive.infolist()) == 2
    assert set(archive.namelist()) == {'traceability-results.json', 'TRACEABILITY-results.md'}
    record = json.loads(archive.read('traceability-results.json'))
assert record['head'] == 'c456418a43314d8d89e9f0e52df6ae2172155028'
assert record['dirty'] is False and record['exit_code'] == 0
assert '-race' in record['command'] and '-count=1' in record['command']
assert './...' in record['command']
named = collections.Counter(e['Action'] for e in record['results'] if e.get('Test'))
packages = collections.Counter(e['Action'] for e in record['results'] if not e.get('Test'))
assert named['fail'] == 0 and named['skip'] == 6
assert packages == {'pass': 16, 'skip': 2}
assert all(e['Action'] in {'pass', 'skip'} for e in record['results'])
added = [e for e in record['results'] if e.get('Test') == 'TestProposalMessageIsPlainText/currency_unit_inflection_stays_catalogue_plain_text']
assert len(added) == 1 and added[0]['Action'] == 'pass'
for test in ['TestUnitForPlural', 'TestProposalMessageIsPlainText', 'TestEveryCatalogueEntryFormats']:
    assert any(e.get('Test') == test and e['Action'] == 'pass' for e in record['results'])
summary = {'artifact_id': artifact['id'], 'zip_bytes': len(raw), 'zip_sha256': checksum,
           'head': record['head'], 'dirty': record['dirty'], 'exit_code': record['exit_code'],
           'source_digest': record['source_digest'], 'command': record['command'],
           'named': dict(named), 'packages': dict(packages), 'added_regression': added,
           'explicit_skips': [e['Test'] for e in record['results'] if e.get('Test') and e['Action'] == 'skip']}
(root / 'pr-test-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
