# Independent UX-047 unit-suffix source/provider review

Reviewed 2026-11-23 Pacific. This native assistant-worker review is not an
external security assessment or manual accessibility qualification.

Fresh provider reads confirm PR #133 source
`980609562395bea7234474ba4359acc1ca145f51`, base
`9cb4cc0250db487d6fd4760227ce906c4ea5f58f`, synthetic checkout
`c456418a43314d8d89e9f0e52df6ae2172155028`. The synthetic parents are that
base and source; its tree `14ad0769187147e6988045b0629ef2218d0a81ff` matches
the source tree. No stale red synthetic checkout was used for qualification.

Fresh compare shows nine changed files. Production changes are only the one
`unitFor` fallback call and the `unit.plural` entry `%[1]ss`. The existing exact
minor-unit singular/negative-one condition and case-insensitive already-s rule
remain intact. The string argument enters ordinary catalogue formatting, not
a second format-string interpretation. No amount float, surrogate plural
count, irregular-noun policy, locale selection, HTML trust or privacy/storage/
mutation/authorization change is introduced. Existing html/template escaping
still owns the markup boundary. No product acceptance blocker was found.

The expanded existing unit table covers precisions 0/1/2/4, sign, exact one,
fraction/zero/large values and arbitrary visible names. The existing message
test adds the missing-key and literal/escaping contract; completeness receives
the correct string argument. Source review independently confirms the helper
actually calls that key, rather than leaving an unused new catalogue entry.
The four documentation changes are explicitly dated source checkpoints, not
claims that pending current-head/main checks have already passed.

Independent red provider records confirm run 45272197441 is overall cancelled
after Linux job 138034623179 completed failure. Its preserved log shows exactly
the new TestProposalMessageIsPlainText subtest panicking on unknown unit.plural;
full race recording was skipped after that focused failure. The original failed
job and later overall cancellation are distinct facts.

Current green run 45272948641 is being qualified separately. Its focused
catalogue race step passed; full current-head Linux race/browser execution and
the final artifact/status review remain required. No local Go execution is
claimed. The catalogue seam is unfinished localization wiring, not a newly
demonstrated wrong-English output or whole-UI completion. Held policy work,
all fifteen future modules and owner/manual/external gates remain untouched.
