"""Independent read-only verification of the completed #133 evidence archive."""
import argparse
from collections import Counter
from hashlib import sha1, sha256
from io import BytesIO
import json
from pathlib import Path, PurePosixPath
import tarfile
import zipfile
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--archive',default='UX047-unit-suffix-integration-2026-11-23.tar.gz')
p.add_argument('--receipt',default='ux047-unit-work/archive-receipt.json')
p.add_argument('--output',default='ux047-unit-work/archive-validation.json')
p.add_argument('--payload-root')
a=p.parse_args()
MAIN='a1e424c7a4d16b1592f1b5ac978a22ffc09c1d5f'
SOURCE='980609562395bea7234474ba4359acc1ca145f51'
SYNTHETIC='c456418a43314d8d89e9f0e52df6ae2172155028'
DIGEST='8ff2362a89abdbd6b4fc7ba61dfdda59a2e66d9b27b2a69cf2ab07f01c665fcb'
UNIT='TestProposalMessageIsPlainText/currency_unit_inflection_stays_catalogue_plain_text'
PARENTS={'TestUnitForPlural','TestProposalMessageIsPlainText','TestEveryCatalogueEntryFormats'}
SKIPS={'TestBackupStagingRefusesForeignOwnedParent','TestBackupWorkLeaseChild','TestRestoreSwapCrashChild','TestLoadConcurrentTrades','TestLoginTimingStatistical','TestQA010CrashChild'}
MAIN_JOBS={'vet, gofmt, golangci-lint, govulncheck','API contract and load smoke','reproducible build (two builds, same sha256)','test (windows-2022)','build release targets','e2e (Playwright, axe, keyboard)','test (ubuntu-24.04)','fuzz smoke (RB-017)','test (macos-15-intel)'}
raw=Path(a.archive).read_bytes(); payload={}
with tarfile.open(fileobj=BytesIO(raw),mode='r:gz') as archive:
 for m in archive:
  path=PurePosixPath(m.name)
  assert m.isfile() and not m.issym() and not m.islnk()
  assert m.name==str(path) and not path.is_absolute() and '..' not in path.parts
  assert m.name not in payload and m.mode&0o111==0
  data=archive.extractfile(m).read(); assert len(data)==m.size
  assert path.suffix.lower() not in {'.exe','.dll','.so','.dylib','.o','.a','.wasm','.pyc','.pyo'}
  assert not data.startswith((b'\x7fELF',b'MZ',b'\xfe\xed\xfa\xce',b'\xce\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\xcf\xfa\xed\xfe',b'\xca\xfe\xba\xbe'))
  payload[m.name]=data
manifest_bytes=payload.pop('MANIFEST.json'); manifest=json.loads(manifest_bytes)
assert manifest['version']==1 and manifest['main']==MAIN and manifest['source']==SOURCE
files=manifest['files']
assert len(files)==len({f['path'] for f in files})==len(payload)
assert {f['path'] for f in files}==set(payload)
for f in files:
 data=payload[f['path']]; assert len(data)==f['bytes'] and sha256(data).hexdigest()==f['sha256'],f['path']
if a.payload_root:
 root=Path(a.payload_root); disk={}
 for path in root.rglob('*'):
  if not path.is_file() or path.name=='MANIFEST.json': continue
  relative=path.relative_to(root)
  if any(part.endswith('-test-evidence') for part in relative.parts[:-1]): continue
  assert not path.is_symlink(); disk[str(relative)]=path.read_bytes()
 assert disk==payload,'Frozen payload inventory/content mismatch'
def record(name): return json.loads(payload['provider/'+name])
runs=[]
for prefix,run_id,head,count in [('pr',45272948641,SOURCE,8),('main',45278925063,MAIN,9)]:
 run=record(prefix+'-run.json'); jobs=record(prefix+'-jobs.json')['jobs']
 assert (run['id'],run['head_sha'],run['status'],run['conclusion'])==(run_id,head,'completed','success')
 assert len(jobs)==count and len({j['name'] for j in jobs})==count
 assert all(j['run_id']==run_id and j['head_sha']==head and j['status']=='completed' for j in jobs)
 if prefix=='main':
  assert {j['name'] for j in jobs}==MAIN_JOBS and all(j['conclusion']=='success' for j in jobs)
 else:
  assert run['run_attempt']==1 and Counter(j['conclusion'] for j in jobs)=={'success':7,'skipped':1}
  assert {j['name'] for j in jobs if j['conclusion']=='success'}==MAIN_JOBS-{'test (windows-2022)','test (macos-15-intel)'}
  assert {j['name'] for j in jobs if j['conclusion']=='skipped'}=={'test (${{ matrix.os }})'}
 runs.append({'run':run_id,'head':head,'attempt':run['run_attempt'],'jobs':dict(Counter(j['conclusion'] for j in jobs))})
score=record('main-scorecard-run.json')
assert (score['id'],score['head_sha'],score['status'],score['conclusion'])==(45278925544,MAIN,'completed','success')
zips=[]
for prefix,head in [('pr',SYNTHETIC),('main',MAIN)]:
 path='provider/'+prefix+'-test-evidence.zip'; data=payload[path]; checksum=sha256(data).hexdigest()
 candidates=[x for x in record(prefix+'-artifacts.json')['artifacts'] if x['name']=='test-evidence-ubuntu-24.04']; assert len(candidates)==1
 item=candidates[0]
 assert item['digest']=='sha256:'+checksum and item['size_in_bytes']==len(data)
 assert item['workflow_run']['id']==(45272948641 if prefix=='pr' else 45278925063)
 assert item['workflow_run']['head_sha']==(SOURCE if prefix=='pr' else MAIN)
 if prefix=='pr': assert item['id']==14867144686 and len(data)==139282 and checksum=='7f891b2c403dc4652c6b07cd05d7a7fed35df49e048866bebb9a8bae0be0eba9'
 else: assert item['id']==14870930568 and len(data)==138290 and checksum=='040cf62b3a411450a19368a462abe6246c724fb42c1cf9f4ef259ed57093dde0'
 with zipfile.ZipFile(BytesIO(data)) as archive:
  assert len(archive.infolist())==2 and set(archive.namelist())=={'traceability-results.json','TRACEABILITY-results.md'}
  result=json.loads(archive.read('traceability-results.json'))
 assert result['head']==head and result['source_digest']==DIGEST and result['dirty'] is False and result['exit_code']==0
 assert result['command']==['go','test','-json','-count=1','-race','-timeout','30m','./...']
 named=[r for r in result['results'] if r.get('Test')]
 assert Counter(r['Action'] for r in named)=={'pass':3279,'skip':6}
 assert Counter(r['Action'] for r in result['results'] if not r.get('Test'))=={'pass':16,'skip':2}
 assert {r['Test'] for r in named if r['Action']=='skip'}==SKIPS
 unit=[r for r in named if r['Test']==UNIT]; assert len(unit)==1 and unit[0]['Action']=='pass'
 parents=[r for r in named if r['Test'] in PARENTS]; assert len(parents)==3 and {r['Test'] for r in parents}==PARENTS and all(r['Action']=='pass' for r in parents)
 zips.append({'path':path,'artifact':item['id'],'bytes':len(data),'sha256':checksum,'head':head,'source_digest':DIGEST,'named_pass':3279,'named_skip':6,'package_pass':16,'package_no_test':2,'new_named_subtest_pass':1,'affected_parent_pass':3,'boundary':'19 table cases are not 19 new named events'})
receipt=json.loads(Path(a.receipt).read_text())
assert receipt['sha256']==sha256(raw).hexdigest() and receipt['bytes']==len(raw) and receipt['payload_count']==len(payload)
assert receipt['git_blob_sha']==sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
assert receipt['manifest_sha256']==sha256(manifest_bytes).hexdigest()
output={'result':'passed','archive':a.archive,'sha256':sha256(raw).hexdigest(),'bytes':len(raw),'payload_count':len(payload),'main':MAIN,'source':SOURCE,'runs':runs,'linux_artifacts':zips,'boundary':'Archive integrity/provider records only; not remote publication, external security or manual accessibility qualification'}
Path(a.output).write_text(json.dumps(output,indent=2)+'\n'); print(json.dumps(output))
