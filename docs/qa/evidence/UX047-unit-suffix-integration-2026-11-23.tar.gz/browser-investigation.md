# Fresh bounded UX-047 browser-message investigation

Reviewed 2026-11-23 Pacific at actual main `9cb4cc0250db487d6fd4760227ce906c4ea5f58f`.
Read the current HANDOFF/TODO/MESSAGES/spec 08 and maintained PR handoff 7109225318;
completed #130/#131/#132 work is not selected for rework.

No confirmed current English UX-047 defect was found in this bounded path.
The shared base template supplies complete catalogue sentences for page loading,
offline/restored-history feedback and all four session-warning states. Production
app.js uses those supplied attributes and textContent. Both snapshot and time
substitution use replacement callbacks, preserving literal dollar sequences.
No live sentence is constructed by concatenating translated text fragments.
The internal `Error('status ' + r.status)` is never presented: the catch handler
uses the catalogue failure sentence. URL and attribute-name concatenation is not
user-facing prose.

The live English catalogue contains exactly one relevant string argument in each
snapshot/time sentence. A speculative future translation repeating a placeholder
does not establish a current-source defect or justify changing this path now.
The known session browser-clock/member-zone mismatch belongs to UX-024 and was
excluded from implementation and qualification in this UX-047 investigation.

Executed the production script's existing native Node suite from exact pinned
copies: sixteen passed, zero failures/cancellations/skips. Verified Git blob
identities: app.js `c74fa68ad3e597389e6c28b76f3a169917c466d2`, test harness
`feb386621e477c7d65c8f246f1d8c805ee53472e`. These are mock-DOM Node checks,
not a real browser, Go/runtime HTTP or screen-reader pass.

No product changes, GitHub mutations, locale decisions, future-module inspection
or held-policy work occurred. This negative finding qualifies only this bounded
browser-message seam; it does not complete UX-047 or whole-UI localization.
