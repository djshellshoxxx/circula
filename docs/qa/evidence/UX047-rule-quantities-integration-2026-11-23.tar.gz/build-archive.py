from pathlib import Path
import collections
import gzip
import hashlib
import io
import json
import tarfile
import zipfile

root = Path('ux047-evidence')
def read(name):
    return json.loads((root / 'provider' / name).read_text())

expected_runs = {
    'pr132': (45241575868, 'ae4f369b5f8e506e804bebc386d010cb66a189c7'),
    'main132': (45259862932, '9cb4cc0250db487d6fd4760227ce906c4ea5f58f'),
}
for prefix, (run_id, head) in expected_runs.items():
    run, jobs = read(prefix + '-run.json'), read(prefix + '-jobs.json')['jobs']
    assert run['id'] == run_id and run['head_sha'] == head
    assert run['status'] == 'completed' and run['conclusion'] == 'success'
    assert len(jobs) == 9 and len({j['name'] for j in jobs}) == 9
    assert all(j['status'] == 'completed' and j['conclusion'] == 'success'
               and j['run_id'] == run_id and j['head_sha'] == head for j in jobs)
assert read('pr132-run.json')['head_sha'] == 'ae4f369b5f8e506e804bebc386d010cb66a189c7'
scorecard = read('main132-scorecard-run.json')
assert scorecard['id'] == 45259862745
assert scorecard['status'] == 'completed' and scorecard['conclusion'] == 'success'
assert scorecard['head_sha'] == read('main132-run.json')['head_sha']

expected = {
    'pr-test-evidence.zip': '7f775778c728d6cbc7c5b79f65be19309e78cf6f',
    'main131-test-evidence.zip': 'd3c5ce67a252a9111e98729c7b967ecb9cc7cdc8',
    'pr132-test-evidence.zip': '701780d8ea0aa2c21ff24c0627001567edc2ba0a',
    'main132-test-evidence.zip': read('main132-run.json')['head_sha'],
}
artifacts = []
for name, head in expected.items():
    path = root / 'provider' / name
    with zipfile.ZipFile(path) as archive:
        assert set(archive.namelist()) == {'traceability-results.json', 'TRACEABILITY-results.md'}
        record = json.loads(archive.read('traceability-results.json'))
    assert record['head'] == head and not record['dirty'] and record['exit_code'] == 0
    named = collections.Counter(r['Action'] for r in record['results'] if r.get('Test'))
    assert named == {'pass': 3278, 'skip': 6}
    packages = collections.Counter(r['Action'] for r in record['results'] if not r.get('Test'))
    assert packages == {'pass': 16, 'skip': 2}
    added = [r for r in record['results'] if r.get('Test', '').startswith(
        ('TestTermsRulesLeaveMessages/rules.quantity',
         'TestRulesCatalogueRowsAndStates/policy_quantities_use_catalogue_formatting'))]
    assert len(added) == 6 and all(r['Action'] == 'pass' for r in added)
    expected_digest = ('d6287cc6a4d99735fb105cc9d8aea880706a8e5171537645a2a7177ed0b59886'
                       if name.startswith(('pr132-', 'main132-')) else
                       'ee83674270aa1313e75f7a298f36ce9a76fd3e4f0cf0f810fd9c5e4d92dc6534')
    assert record['source_digest'] == expected_digest
    if name.startswith(('pr132-', 'main132-')):
        provider_prefix = name.split('-')[0]
        candidates = [a for a in read(provider_prefix + '-artifacts.json')['artifacts']
                      if a['name'] == 'test-evidence-ubuntu-24.04']
        assert len(candidates) == 1
        artifact = candidates[0]
        assert artifact['workflow_run']['id'] == expected_runs[provider_prefix][0]
        assert artifact['workflow_run']['head_sha'] == expected_runs[provider_prefix][1]
        assert artifact['digest'] == 'sha256:' + hashlib.sha256(path.read_bytes()).hexdigest()
        assert artifact['size_in_bytes'] == path.stat().st_size
    artifacts.append({'path': str(path.relative_to(root)), 'head': head,
                      'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                      'bytes': path.stat().st_size, 'source_digest': record['source_digest'],
                      'named_results': dict(named)})

payloads = []
for path in sorted(root.rglob('*')):
    if not path.is_file() or path.name == 'MANIFEST.json':
        continue
    assert not path.is_symlink()
    relative = path.relative_to(root)
    if any(part.endswith('-test-evidence') for part in relative.parts[:-1]):
        continue  # Exact provider ZIPs already retain both extracted files.
    assert path.suffix.lower() not in {'.exe', '.dll', '.so', '.dylib', '.o', '.a', '.wasm'}
    data = path.read_bytes()
    assert not data.startswith((b'\x7fELF', b'MZ'))
    payloads.append((str(relative), data))
manifest = {'version': 1, 'date': '2026-11-23 Pacific',
            'source': read('pr132-run.json')['head_sha'],
            'main': read('main132-run.json')['head_sha'], 'linux_artifacts': artifacts,
            'files': [{'path': name, 'bytes': len(data),
                       'sha256': hashlib.sha256(data).hexdigest()} for name, data in payloads]}
manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
output = Path('UX047-rule-quantities-integration-2026-11-23.tar.gz')
with output.open('wb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0, compresslevel=9) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as archive:
        for name, data in payloads + [('MANIFEST.json', manifest_bytes)]:
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
data = output.read_bytes()
receipt = {'file': str(output), 'sha256': hashlib.sha256(data).hexdigest(),
           'bytes': len(data), 'payload_count': len(payloads),
           'git_blob_sha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
           'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest()}
Path('ux047-evidence-archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
