# Independent macOS cancellation/retry assessment

Final132 sourceae4f369b remained unchanged. Job137927587457 ran18:45:00 to
19:45:27, with test step18:46:57 to19:45:13. It logged no test assertion or
Go45m package alarm. Active service/store processes were terminated at job
cancellation. This is consistent with the60m job cap; explicit cause was not logged.

The same macOS15.7.9/image20260824.0482.1/Go1.26.11 and exact command previously
passed16 test-bearing packages plus2 no-test packages in40m46s. Completed CLI,
API and contract packages on the cancelled runner were2.535x/2.857x/5.077x slower.
Both original logs were independently inspected, not only summaries.

Recommendation: ONE full uncached retry of only the cancelled job, unchanged
head, -count=1, race, -p2, package45m and job60m. Preserve original attempt1 and
report successful retry as attempt2 with the other eight same-head gate results.
Do not merge before all nine current-head gates succeed. Raising a90m job limit
now is less diagnostic and could still hit the package limit. If the retry fails,
investigate progress/I/O/scheduling before further budget changes. This review
does not establish a definitive infrastructure cause or make timing guarantees.
