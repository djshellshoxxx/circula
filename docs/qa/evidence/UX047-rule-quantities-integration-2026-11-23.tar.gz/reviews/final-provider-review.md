# Independent final actual-main provider review

Reviewed 2026-11-23 Pacific using fresh connected GitHub GETs and raw provider logs/artifacts. This is a native assistant-worker evidence review, not an external independent security assessment or manual accessibility qualification.

## Exact integration and status

- Actual main remains `9cb4cc0250db487d6fd4760227ce906c4ea5f58f`; tree `38b6ed1aefc9d83fbd73581dc047d7b8ebc1e1ba`, parents `d3c5ce67a252a9111e98729c7b967ecb9cc7cdc8` and `ae4f369b5f8e506e804bebc386d010cb66a189c7`.
- Preserved #131 topic remains `a2b4229031cb18ff3517ad429b86e54c9edc329a`; #132 topic remains `ae4f369b5f8e506e804bebc386d010cb66a189c7`.
- Final actual-main Core run `45259862932` is completed/success on attempt 1, exact main above. All nine configured job records are success on attempt 1; no current-main rerun was requested in this review.
- Scorecard run `45259862745` is completed/success on attempt 1 at the same actual main. Preserved results report 5.9 across eighteen checks. Execution success does not resolve its policy, review, licence or other findings.

## Native executed results

- Linux job `137991442952` passed its focused catalogue step, full race recorder, traceability matching and artifact upload. Artifact `14860918103` contains exactly `traceability-results.json` and `TRACEABILITY-results.md`: 138,714 bytes, SHA-256 `c19a245b3527d26fdaa559cb447092c25e43230331549a6e221185dd542555c9`, independently matched to fresh provider metadata. The clean JSON head is exact actual main, exit zero, source digest `d6287cc6a4d99735fb105cc9d8aea880706a8e5171537645a2a7177ed0b59886` (identical to #132 synthetic qualification). It records 3,278 named passes, six named skips and zero failures; sixteen package passes plus two no-test package skips. All five `rules.quantity` subtest events and the rendered policy-quantity subtest passed.
- Native macOS Intel job `137991443023` passed full `go test -race -count=1 -p 2 -timeout=45m ./...`: sixteen test-bearing packages plus two no-test packages, no cached test results. Service 1401.507s, store 758.408s, web 558.034s, messages 1.313s. This is a successful new actual-main execution, separate from the earlier PR-only retry.
- Native Windows job `137991442902` passed full `go test -count=1 -timeout=20m ./...`: sixteen test-bearing packages plus two no-test packages, no cached test results. Service 418.169s, store 378.039s, web 136.100s, messages 0.127s. Windows is non-race, as explicitly configured.
- Browser job `137991442931` raw log records 597 passed (9.8m).
- The other five configured gates (lint/vet/vulnerability checks, API contract/load smoke, reproducible build, build targets and fuzz smoke) all completed successfully in this same exact-head main run. Their provider status and logs remain in the archive; these bounded results do not imply exhaustive load, fuzz, packaging or deployment qualification.

## Historical evidence remains distinct

The original #131-main Windows default-ten-minute cleanup timeout remains a failed run (`45237650449`), not a nine-platform pass. The #132 PR Mac attempt-1 cancellation (`137927587457`) and the unchanged-source full Mac retry (`137968031442`) remain preserved. PR run `45241575868` has nine latest successful records at attempt 2, consisting of eight retained same-head physical successes plus the one full Mac retry. It is not nine new executions or a clean attempt-1 PR pass. Fresh #132 artifact metadata independently confirms artifact `14854415433`, 138,164 bytes and provider digest `0a330ee5dde77c29d499dd56f6db161396537e2fe4ecaa39242a9d5b25c38927`.

## Outcome and boundaries

Approved final actual-main integration qualification for this bounded UX-047 correction and native Windows CI-budget follow-up; zero provider-evidence blockers. No configured applicable CI finalizer remains for this slice. This review does not qualify any future module, make owner decisions, establish arbitrary-I/O timing guarantees, close storage fault/uncertain-commit qualification, or convert six named skips into passes. UX-047 remains partial, with whole-UI/locale scope, manual screen-reader and external security work separately open. No code, workflow, rerun, branch, merge, release or deployment mutation was performed by this reviewer.
