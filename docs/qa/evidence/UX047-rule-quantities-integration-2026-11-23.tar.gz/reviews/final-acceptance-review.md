# Independent final acceptance/evidence review

Review checkpoint: 2026-11-23 Pacific. This is an assistant-worker source and
evidence review, not an external security assessment or manual accessibility
pass. Final actual-main Linux/macOS execution was still in progress when this
checkpoint was written; no completed-main pass is inferred.

## Acceptance finding

No product blocker found in the bounded rules-log quantity correction. The
reviewed diff changes the int/int64 presentation seam to `rules.quantity`.
Strings and Booleans retain their previous paths. The three monetary keys
continue bypassing the seam through exact domain fixed-point formatting;
version identifiers take a separate ungrouped path. The regression covers
int/int64 zero, one, 1000 and 3650, rendered change and initial-value rows,
ungrouped version 1000, all three monetary keys, numeric-looking text and an
exact int64 above 2^53. Existing private-threshold filtering remains in both
public policy-log read paths. No mutation, ledger, authentication, tenant,
balance or durability implementation is changed by the two PRs.

The follow-up diff contains only the Windows package budget/comment and three
source-checkpoint documents. Every package/test and `-count=1` is retained,
as are the thirty-minute Windows job cap and existing non-race limitation.
The original timeout and macOS cancellation are preserved rather than erased.

## Independently checked existing evidence

- PR #131 run 45233048885: completed success, attempt 1, exact source
  a2b4229031cb18ff3517ad429b86e54c9edc329a; seven successful job records plus
  the conditional native-matrix skip.
- Original actual-main run 45237650449: completed failure, attempt 1, exact
  d3c5ce67a252a9111e98729c7b967ecb9cc7cdc8; eight successful jobs and the
  Windows failure. It must not be called an all-platform qualified main pass.
- PR #132 run 45241575868: completed success, latest attempt 2, exact source
  ae4f369b5f8e506e804bebc386d010cb66a189c7; nine successful current records.
  Retry lineage explicitly distinguishes eight retained original executions
  from the one full unchanged-head macOS retry. No nine-new-executions claim
  is supported or needed.
- All three existing original Linux ZIPs independently parse as 3,278 named
  passes, six named skips, zero named failures; sixteen package passes and
  two separate no-test package skips. Their exact clean heads and source
  digests match the existing summaries. Six new regression subtest events
  are present in the follow-up summary.
- Product equality evidence consists of direct pinned UTF-8 reads at both
  source heads, corroborated by the follow-up's four-file CI/documentation
  diff. Generated traceability has no new top-level requirement/test symbol;
  the final report must retain the actual freshness-gate evidence rather
  than claim generated output was manually revised.

## Required final report corrections before publication

1. Replace the prospective statement “If the retry fails” with the observed
   successful unchanged-head retry, while retaining the original cancelled
   attempt and the explicit inference boundary around its cause.
2. Scope “all seven applicable PR jobs before merge” to #131; separately
   state #132's nine current-head successful gate records and attempt lineage.
3. Resolve every report placeholder only from completed exact-head evidence.
   Final actual main is 9cb4cc0250db487d6fd4760227ce906c4ea5f58f, Core run
   45259862932; Scorecard run 45259862745 execution success remains distinct
   from its open findings. Do not qualify a later main automatically.
4. Add normal spaces to compressed attempt/timing phrases. Keep the fresh
   continuation conditional in checked-in source checkpoints; those links
   deliberately avoid creating a stale pending-result finalizer.

## Final archive/publication checks still required

The builder provides deterministic payload hashes/sizes and refuses incomplete
final run/job inputs. Its assertions alone do not authenticate those inputs.
The final independent validation should additionally pin the actual-main SHA,
run IDs, completed job statuses/head identities, source digest, provider ZIP
digest/size, package counts and all six added regression events. Parse the
finished tar archive and independently verify its complete manifest, exact
payload inventory, four unchanged original ZIPs and absence of executable
payloads. Verify remote evidence ref/commit/tree, exactly two added files over
qualified main, exact report bytes, archive Git-blob identity and binary
readback where available. Re-read the maintained handoff after publication.

The report correctly leaves UX-047 partial and retains six named skips,
manual/screen-reader and external-review gaps, bounded fuzz/load and packaging
qualification limits, unresolved policy/locale/licence decisions and remaining
storage-fault qualification. No future module or held policy PR was reviewed
or changed in this task. Approval of final integration/publication remains
conditional on the outstanding final actual-main evidence and readback above.

## Completed actual-main review — supersedes the pending checkpoint above

Final actual-main Core run 45259862932 is now completed/success on attempt 1
at exact 9cb4cc0250db487d6fd4760227ce906c4ea5f58f. All nine distinct configured
jobs have completed-success records for that run/head. Same-head Scorecard
run 45259862745 also completed successfully; its findings remain open.

The reviewer independently re-parsed the final original Linux ZIP and matched
138,714 bytes and SHA-256
c19a245b3527d26fdaa559cb447092c25e43230331549a6e221185dd542555c9.
Its clean exact-main record has exit zero and source digest
d6287cc6a4d99735fb105cc9d8aea880706a8e5171537645a2a7177ed0b59886.
Counts independently reproduce 3,278 named passes, six named skips, sixteen
package passes, two no-test packages and all six added subtest passes.

Raw final native Windows and macOS logs independently show sixteen passing
packages plus two no-test packages each, with no cached test results. The
Windows command retains the full suite, count one and twenty-minute package
limit. The macOS command retains the full race suite, count one, parallelism
two and forty-five-minute package limit. Final macOS service/store/web/messages
times are 1401.507/758.408/558.034/1.313 seconds. The raw browser log records
597 passed. Provider review and root independently corroborate exact-head
status and execution; no final-main retry was needed.

The updated integration draft resolves the stale macOS conditional, clearly
separates #131's seven applicable gates from #132's nine, retains the original
Windows failure and PR-only Mac cancellation/retry lineage, and keeps UX-047
partial. It correctly leaves only final archive values/review text to fill and
publication/readback to perform. The hardened builder now pins final run/head
identities, completed same-head job statuses, package/new-event/source counts
and provider ZIP metadata rather than relying only on broad success fields.

Approved to freeze the evidence inputs and build the final archive: zero
acceptance/documentation blockers for this bounded integration. This approval
does not assert that the not-yet-built archive or not-yet-published remote files
have passed readback. Run the separate independent archive validator and verify
the exact published tree/report/binary before releasing the slice's ownership.
