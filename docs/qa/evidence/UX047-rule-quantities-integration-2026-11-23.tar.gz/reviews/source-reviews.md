# Independent source reviews

These are native assistant-worker source/evidence reviews, not an external security assessment or manual accessibility pass.

## Number/type investigation

policyMap and policyDiff contain numeric quantities rather than identifiers. Public PolicyLog and PolicyLogPage remove dual_control_threshold. The three visible monetary keys bypass fmtAny and use domain.FormatAmount. Version labels take separate ungrouped string paths. Approved catalogue integer formatting at this seam; requested exact int64-above-2^53 coverage.

## Browser investigation and diff review

All nine current dynamic loading/freshness/session sentences are catalogue-backed; 16 Node tests passed. No new UX047 browser defect was confirmed. The proposed quantity correction preserves amount formatting, version identifiers, string/Boolean behavior and template escaping. No auth, tenant, storage, audit or balance changes. Approved conditional on CI.

Adjacent source-only observation (not implemented or runtime-qualified here): app.js clock() uses browser-local hours/minutes rather than the saved profile zone or an abbreviation. Treat this as a separate UX024 investigation; it does not expand this UX047 slice.

## Fresh acceptance/documentation review

The redundant int casts were removed after review. A malformed JavaScript replacement inserted a duplicated workflow tail; reviewer blocked the candidate before qualification. Rebuilt workflow uses a replacement callback, remote comparison verifies exactly two added lines, and the full original race step remains unchanged. No job, permissions or trigger was weakened. Final source/documentation a2b4229031cb18ff3517ad429b86e54c9edc329a approved pending its required CI. Reviewer independently confirmed red job137895869325's four integer mismatches and two missing rendered rows. Fresh synthetic7f775778 shares final tree004ff13c; a temporarily stale provider merge SHA belonged to red and was correctly rejected as green-equivalence evidence.
