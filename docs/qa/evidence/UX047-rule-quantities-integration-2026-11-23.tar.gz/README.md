# UX-047 bounded integration evidence

The external qualification record identifies the exact final qualified source
and main revisions. This bundle preserves prior failures and checkpoints as
historical evidence; a filename containing checkpoint or attempt1 is not a claim
that that intermediate workflow qualified.

- pr-* / pr-test-* record #131's seven successful applicable jobs and exact Linux artifact.
- main131-* / main-* retain #131's original main integration, including the Windows default10m alarm and passing Linux/macOS/browser results.
- pr132-* / followup132.diff record the bounded Windows20m package correction and source-identical product files.
- pr132-macos-attempt1.log and retry-lineage record the cancelled Mac attempt and the unchanged-head Mac-only retry. The eight retained successes retain their original execution timestamps even where GitHub gives their carried-forward records new attempt2 IDs.
- main132-* record the subsequent final actual-main integration; absence or failure of those records must not be promoted to a pass.

Original Linux ZIPs retain both provider files unchanged. Extracted copies are
omitted from the outer archive to avoid duplication; checksums cover each exact
ZIP, and summaries retain named/package results and source fingerprints.
The six explicit named skips remain skips. Native non-verbose package success
does not create per-test event evidence or a manual screen-reader result.

MANIFEST.json covers each included payload by SHA-256 and size. The archive
builder refuses publication inputs unless the final #132 and actual-main runs
show all nine jobs successful and the final Scorecard execution matches main.
Reviews are native assistant-worker source/evidence reviews, not an external
security assessment. Whole-UI, policy, language/licence, manual and release gates
are not closed by this bounded record.
