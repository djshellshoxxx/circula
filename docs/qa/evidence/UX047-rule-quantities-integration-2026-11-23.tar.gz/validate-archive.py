"""Independent read-only verification of the completed UX-047 evidence archive."""
from collections import Counter
from hashlib import sha1, sha256
from io import BytesIO
import json
from pathlib import Path, PurePosixPath
import re
import tarfile
import zipfile

ARCHIVE = Path('UX047-rule-quantities-integration-2026-11-23.tar.gz')
MAIN = '9cb4cc0250db487d6fd4760227ce906c4ea5f58f'
SOURCE = 'ae4f369b5f8e506e804bebc386d010cb66a189c7'
DIGEST_131 = 'ee83674270aa1313e75f7a298f36ce9a76fd3e4f0cf0f810fd9c5e4d92dc6534'
DIGEST_132 = 'd6287cc6a4d99735fb105cc9d8aea880706a8e5171537645a2a7177ed0b59886'
ZIPS = {
    'pr-test-evidence.zip': ('7f775778c728d6cbc7c5b79f65be19309e78cf6f', DIGEST_131, 138776,
                             'ca29bdc3c92f44fd17f5c0196b9ae3c079a55263a35f82b346bfb951e55a5f23'),
    'main131-test-evidence.zip': ('d3c5ce67a252a9111e98729c7b967ecb9cc7cdc8', DIGEST_131, 138602,
                                  '5757f3a544c66cabae9c6f986628dde65f552c16814934e140c9042b7df7cfa8'),
    'pr132-test-evidence.zip': ('701780d8ea0aa2c21ff24c0627001567edc2ba0a', DIGEST_132, 138164,
                                '0a330ee5dde77c29d499dd56f6db161396537e2fe4ecaa39242a9d5b25c38927'),
    'main132-test-evidence.zip': (MAIN, DIGEST_132, 138714,
                                  'c19a245b3527d26fdaa559cb447092c25e43230331549a6e221185dd542555c9'),
}
ADDED = {'TestRulesCatalogueRowsAndStates/policy_quantities_use_catalogue_formatting',
         'TestTermsRulesLeaveMessages/rules.quantity',
         *('TestTermsRulesLeaveMessages/rules.quantity#%02d' % n for n in range(1, 5))}
SKIPPED = {'TestBackupStagingRefusesForeignOwnedParent', 'TestBackupWorkLeaseChild',
           'TestRestoreSwapCrashChild', 'TestLoadConcurrentTrades',
           'TestLoginTimingStatistical', 'TestQA010CrashChild'}
EXPECTED_JOBS = {'vet, gofmt, golangci-lint, govulncheck', 'API contract and load smoke',
                 'reproducible build (two builds, same sha256)', 'test (windows-2022)',
                 'build release targets', 'e2e (Playwright, axe, keyboard)',
                 'test (ubuntu-24.04)', 'fuzz smoke (RB-017)', 'test (macos-15-intel)'}

raw = ARCHIVE.read_bytes()
payload = {}
with tarfile.open(fileobj=BytesIO(raw), mode='r:gz') as tar:
    for member in tar:
        path = PurePosixPath(member.name)
        assert member.isfile() and not member.issym() and not member.islnk(), member.name
        assert member.name == str(path) and not path.is_absolute() and '..' not in path.parts
        assert member.name not in payload, 'duplicate archive path: ' + member.name
        assert member.mode & 0o111 == 0, 'executable mode: ' + member.name
        data = tar.extractfile(member).read()
        assert len(data) == member.size
        assert path.suffix.lower() not in {'.exe', '.dll', '.so', '.dylib', '.o', '.a', '.wasm'}
        assert not data.startswith((b'\x7fELF', b'MZ', b'\xfe\xed\xfa\xce',
                                    b'\xce\xfa\xed\xfe', b'\xfe\xed\xfa\xcf',
                                    b'\xcf\xfa\xed\xfe', b'\xca\xfe\xba\xbe'))
        payload[member.name] = data

manifest_bytes = payload.pop('MANIFEST.json')
manifest = json.loads(manifest_bytes)
assert manifest['version'] == 1 and manifest['main'] == MAIN and manifest['source'] == SOURCE
listed = manifest['files']
assert len(listed) == len({f['path'] for f in listed}) == len(payload)
assert {f['path'] for f in listed} == set(payload)
for entry in listed:
    data = payload[entry['path']]
    assert len(data) == entry['bytes'] and sha256(data).hexdigest() == entry['sha256'], entry['path']

def record(name):
    return json.loads(payload['provider/' + name])

for prefix, run_id, head in [('pr132', 45241575868, SOURCE), ('main132', 45259862932, MAIN)]:
    run = record(prefix + '-run.json')
    assert (run['id'], run['head_sha'], run['status'], run['conclusion']) == (run_id, head, 'completed', 'success')
    jobs = record(prefix + '-jobs.json')['jobs']
    assert len(jobs) == 9 and {job['name'] for job in jobs} == EXPECTED_JOBS
    for job in jobs:
        assert (job['run_id'], job['head_sha'], job['status'], job['conclusion']) == (run_id, head, 'completed', 'success')
scorecard = record('main132-scorecard-run.json')
assert (scorecard['id'], scorecard['head_sha'], scorecard['status'], scorecard['conclusion']) == (45259862745, MAIN, 'completed', 'success')
assert record('pr132-run.json')['run_attempt'] == 2
assert record('main132-run.json')['run_attempt'] == 1

zip_results = []
assert len(manifest['linux_artifacts']) == 4
for name, (head, digest, size, checksum) in ZIPS.items():
    path = 'provider/' + name
    data = payload[path]
    assert len(data) == size and sha256(data).hexdigest() == checksum
    with zipfile.ZipFile(BytesIO(data)) as archive:
        assert len(archive.infolist()) == 2
        assert set(archive.namelist()) == {'traceability-results.json', 'TRACEABILITY-results.md'}
        result = json.loads(archive.read('traceability-results.json'))
    assert result['head'] == head and result['source_digest'] == digest
    assert result['dirty'] is False and result['exit_code'] == 0
    named = [r for r in result['results'] if r.get('Test')]
    assert Counter(r['Action'] for r in named) == {'pass': 3278, 'skip': 6}
    assert Counter(r['Action'] for r in result['results'] if not r.get('Test')) == {'pass': 16, 'skip': 2}
    assert {r['Test'] for r in named if r['Action'] == 'skip'} == SKIPPED
    added = [r for r in named if r['Test'] in ADDED]
    assert len(added) == 6 and {r['Test'] for r in added} == ADDED
    assert all(r['Action'] == 'pass' for r in added)
    indexed = [a for a in manifest['linux_artifacts'] if a['path'] == path]
    assert len(indexed) == 1
    assert (indexed[0]['head'], indexed[0]['source_digest'], indexed[0]['sha256'], indexed[0]['bytes']) == (head, digest, checksum, size)
    if name.startswith(('pr132-', 'main132-')):
        provider = record(name.split('-')[0] + '-artifacts.json')['artifacts']
        matching = [a for a in provider if a['name'] == 'test-evidence-ubuntu-24.04']
        assert len(matching) == 1
        assert matching[0]['digest'] == 'sha256:' + checksum
        assert matching[0]['size_in_bytes'] == size
    zip_results.append({'path': path, 'sha256': checksum, 'bytes': size,
                        'head': head, 'named_pass': 3278, 'named_skip': 6,
                        'package_pass': 16, 'package_no_test': 2, 'added_pass': 6})

receipt = json.loads(Path('ux047-evidence-archive-receipt.json').read_text())
assert receipt['sha256'] == sha256(raw).hexdigest() and receipt['bytes'] == len(raw)
assert receipt['payload_count'] == len(payload)
assert receipt['git_blob_sha'] == sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
assert receipt['manifest_sha256'] == sha256(manifest_bytes).hexdigest()

output = {'result': 'passed', 'archive': str(ARCHIVE), 'sha256': sha256(raw).hexdigest(),
          'bytes': len(raw), 'payload_count': len(payload), 'main': MAIN,
          'main_run': 45259862932, 'main_jobs': 9, 'linux_artifacts': zip_results,
          'boundary': 'archive integrity and exact provider records; not external security or manual accessibility qualification'}
Path('ux047-independent-archive-validation.json').write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps(output))
