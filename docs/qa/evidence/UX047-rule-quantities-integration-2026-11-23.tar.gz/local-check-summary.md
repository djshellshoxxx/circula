# Local check summary

The host has no Go compiler. No local Go test/vet/race/build or browser/screen-reader execution is claimed.

Node command: node --test scripts/test_app_messages.cjs
Result:16 passed, zero failed/cancelled/skipped/todo.

Tested browser/source files were matched to the fetched main/current-PR blobs using git hash-object:
- internal/web/static/app.js: c74fa68ad3e597389e6c28b76f3a169917c466d2
- scripts/test_app_messages.cjs: feb386621e477c7d65c8f246f1d8c805ee53472e

Catalogue JSON validation found1459 unique entries with rules.quantity exactly {"other":"%[1]d"}. Whitespace diff check passed. Local files were reconstructed from pinned GitHub files for bounded inspection, not treated as a full repository checkout.
