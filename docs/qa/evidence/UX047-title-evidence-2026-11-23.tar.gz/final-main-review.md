# PR #137 independent final actual-main qualification review

Reviewed 2026-11-24 05:43 UTC (November 23 Pacific). **No blocker found for the bounded title-format integration. Actual-main Core qualification is complete.** This is not whole UX-047 acceptance.

## Fresh provider qualification

Independent connected GitHub reads confirmed main `418d2ed4b289c183d1fbd087b8f7b7ee6451169e`.
[Core 45321695163](https://github.com/djshellshoxxx/circula/actions/runs/45321695163)
completed successfully on attempt 1 at exactly that head. All nine applicable jobs were completed/success:
Linux race, macOS Intel race, Windows non-race, lint/vet/gofmt/govulncheck, browser, fuzz smoke,
reproducible build, build targets and API/load smoke.
[Scorecard 45321695017](https://github.com/djshellshoxxx/circula/actions/runs/45321695017)
also completed successfully on attempt 1 at the same head.

## Original Linux evidence independently parsed

Fresh provider artifact metadata for `14890858220` matched the original downloaded ZIP:
138,532 bytes; SHA-256 `d56d0646d9e05c15625a85d893c08a97fc1eda054c0c93c97426d61e7d08f54f`.
Archive contains exactly `traceability-results.json` and `TRACEABILITY-results.md`.
The recorder identifies clean head `418d2ed4b289c183d1fbd087b8f7b7ee6451169e`, dirty false, exit 0,
and `go test -json -count=1 -race -timeout 30m ./...`.
Independently counted 3,284 named passes, six named skips, zero failures; 16 passing packages plus two no-test packages.
`TestDocumentTitleCatalogue` and all four public/network English/reordered controls passed.
Recorded source digest `ebfbe9cf9635746bdae3fc68b8924d259d9a8e17750edabcbc1f2015ff27c8f0`
was read from the artifact; I did not recompute it independently.

Six explicit named skips remain:
`TestBackupStagingRefusesForeignOwnedParent`, `TestBackupWorkLeaseChild`,
`TestRestoreSwapCrashChild`, `TestLoadConcurrentTrades`, `TestLoginTimingStatistical`, `TestQA010CrashChild`.

## Native and browser evidence

Independently parsed complete saved provider logs, independently retrieved fresh logs for all three jobs,
and verified that their text matches after line-ending/trailing-newline normalization:

- macOS job `138201504638`: `go test -race -count=1 -p 2 -timeout=45m ./...`, 16 passing packages and two no-test packages; no cached package results. Service 1477.509 s, store 896.722 s, web 525.733 s.
- Windows job `138201504445`: `go test -count=1 -timeout=20m ./...`, 16 passing packages and two no-test packages; no cached package results. This gate is non-race.
- Browser job `138201504074`: `597 passed (6.9m)`.

The saved raw Scorecard log records score 5.9 and 18 checks on the exact actual-main revision.
Execution success does not close those findings or decide licence/policy questions.

## Limits and boundary

No local Go/compiler/browser rerun was performed by this reviewer. Findings come from fresh provider state,
original recorder ZIP parsing and complete provider logs. Author-provided red/green and Chromium observations
remain separate evidence; earlier local resource/setup failures are not recast as passes.
The six skips, bounded fuzz/load/reproducibility/packaging scope, manual screen-reader and independent
external security review limits remain explicit. UX-047 is partial; translation/locale scope and owner policy gates remain open.

No GitHub mutations, product/source edits, unrelated PR review, policy work or future-module inspection/execution
were performed. Root retains final documentation/archive publication and exact remote readback.
Stop this bounded integration at its completed handoff; a fresh run may take the next authorized investigation.
