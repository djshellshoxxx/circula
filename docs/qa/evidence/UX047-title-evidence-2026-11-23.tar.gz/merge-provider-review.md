# PR #137 independent merge/provider qualification review

Reviewed 2026-11-24 03:46 UTC (November 23 Pacific). **No blocker found in the source-CI artifact or normal-merge proof. Actual-main qualification remains pending and is not certified here.**

## Live revision and provider checks

Fresh connected GitHub reads confirm PR #137 merged as `418d2ed4b289c183d1fbd087b8f7b7ee6451169e`. Its parents are qualified base `73b98ec2c5a0ca2a94e79661aa7c005c15cdf52d` and reviewed source `73c5afb0eeebb54c3cf7645c0300fee12cd1d733`. Actual main points to that merge. Topic `fix/catalogue-page-titles` is preserved at the reviewed source.

The source, tested synthetic candidate `9fddaf265dc706c8d63de046f60c1021a55abeb6`, and actual merge independently returned identical tree `ac2c359216d12c46965c84b45b971025daae5993`. Synthetic parents also match base/source. This verifies composition identity and normal two-parent integration; it does not substitute for actual-main execution.

[Source Core run 45312460743](https://github.com/djshellshoxxx/circula/actions/runs/45312460743) completed successfully on attempt 1 at the reviewed source. Fresh jobs read returned all seven applicable jobs successful: fuzz smoke, Linux test, reproducible build, lint/vet/gofmt/govulncheck, release-target build, browser, and API/load smoke. The conditional native-matrix placeholder is the one explicit skipped job. Native Windows/macOS are actual-main gates.

## Independently checked original test artifact

I independently parsed the original local ZIP and compared it with freshly fetched provider artifact collection metadata:

- Artifact `14886516616`, `test-evidence-ubuntu-24.04`, run `45312460743`, source `73c5afb0eeebb54c3cf7645c0300fee12cd1d733`.
- 138,614 bytes; SHA-256 `86f4050e29d8f88734c5a506455bd39186d3ed8466e955c66c5845abfb10fefc`; both match live provider metadata.
- Exactly `traceability-results.json` and `TRACEABILITY-results.md`.
- Recorded clean tested head `9fddaf265dc706c8d63de046f60c1021a55abeb6`, dirty false, exit code 0.
- Recorded command `go test -json -count=1 -race -timeout 30m ./...`.
- 3,284 named passes, six named skips, zero failures; 16 passing packages and two no-test package skips.
- `TestDocumentTitleCatalogue` and all four controls (public/network English and public/network reordered) passed.
- Recorded source digest `ebfbe9cf9635746bdae3fc68b8924d259d9a8e17750edabcbc1f2015ff27c8f0`. I read this recorded value; I did not recompute the source digest.

The saved raw browser provider log records `597 passed (7.1m)`, consistent with the fresh successful browser job. This reviewer did not rerun Go or browser tests locally.

## Actual-main status and limits

At the final live main-run collection read, [Scorecard 45321695017](https://github.com/djshellshoxxx/circula/actions/runs/45321695017) was queued on `418d2ed4b289c183d1fbd087b8f7b7ee6451169e`; no new Core run was yet visible in that collection. This is an observation of provider visibility, not a claim that Core will not run or has passed. Root retains follow-up for the actual-main Core run and all applicable native jobs.

No main pass is inferred from tree equality. Source-CI evidence does not qualify a future composition, manual screen-reader work, independent security audit, exhaustive fuzz/load, all packaging targets, or whole UX-047 completion. I made no GitHub mutations or source edits and did not inspect unrelated owned PRs, held policy work or future modules.
