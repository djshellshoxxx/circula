# PR #137 independent source review

Reviewed 2026-11-24 02:47 UTC. Verdict: **no source-review blockers found** for this bounded UX-047 title-format slice. Merge remains conditional on the coordinator's live current-head CI and base qualification; this review does not certify a merge or a full feature completion.

## Revisions and scope

- Repository: `djshellshoxxx/circula`; PR #137 remained open and unmerged in this review's final live read.
- Head: `73c5afb0eeebb54c3cf7645c0300fee12cd1d733` (`fix/catalogue-page-titles`).
- Current PR base: `73b98ec2c5a0ca2a94e79661aa7c005c15cdf52d`.
- Head and synthetic PR candidate `9fddaf265dc706c8d63de046f60c1021a55abeb6` independently returned identical tree `ac2c359216d12c46965c84b45b971025daae5993`.
- Independently read the live PR description, exact five-file provider diff, title regression, catalogue plumbing, shell template and fresh template loader. No patches, branches, PRs or public comments were changed by this reviewer.

The five changed paths are `docs/dev/MESSAGES.md`, `internal/web/messages/en.json`, `internal/web/messages/messages_test.go`, `internal/web/shared_pages_catalog_test.go` and `internal/web/templates/base.html`.

## Findings

The shell selects two static catalogue keys using the existing public/network condition. Default English retains `Screen - Circula` and `Screen - Network - Circula`; the catalogue now owns the entire order and separators. `%` inside either name is an argument value, not a format string.

`messages.Text` returns ordinary `string`. Neither this patch nor its new call crosses a trusted-HTML boundary. `html/template` remains responsible for contextual escaping inside `<title>`. The test values include literal percent signs, ampersands, angle brackets and `</title>`, and compare the rendered title to the fully escaped expected text.

The four controls cover public/network English output and public/network reordered output. Both reorder controls specifically distinguish the fixed implementation from the former hardcoded order. `mustLoadTemplates()` constructs a new map and freshly parsed templates on every call. Each subtest obtains its own template before overriding `msg`; other keys delegate to the real catalogue and no global catalogue or production server template is mutated. No test isolation flaw was found.

The two new catalogue keys have matching formatting fixtures in `TestEveryCatalogueEntryFormats`. Documentation states argument positions and limits and explicitly leaves UX-047 partial. Existing handlers, authorization, tenant context, routes, ledger operations and persisted values are unaffected by this five-file diff. No new privacy or balance behavior is introduced.

## Independently executed checks

The workflow's exact helper command was executed with Node `v24.22.3`:

```text
node --test scripts/test_app_messages.cjs scripts/test_e2e_kbd.cjs
tests 24; pass 24; fail 0; cancelled 0; skipped 0; todo 0
```

The four source inputs were fetched at the reviewed head and their local Git blob hashes were checked against provider values before the recorded exact-byte test run:

| File | Verified Git blob |
| --- | --- |
| `scripts/test_app_messages.cjs` | `feb386621e477c7d65c8f246f1d8c805ee53472e` |
| `scripts/test_e2e_kbd.cjs` | `d2bdc26d2a64bcc45c300e6edc83d14b824c7f7a` |
| `internal/web/static/app.js` | `c74fa68ad3e597389e6c28b76f3a169917c466d2` |
| `e2e/kbd.js` | `f05c8311a89593a807812e543a680d306101095a` |

This is mock-DOM/helper evidence, not browser or new-title Go execution.

GitHub compare independently returned common ancestor `80543191ebb150448ee9e5ed616625a37e7e0678` for the reviewed source and #136 source `efea7f99a8b6e353c5222ec5a1210f48e41a683f`. Local `git merge-file -p` on all five #137 changed paths against those pinned text snapshots returned zero conflicts. The resulting catalogue parsed with duplicate-key detection and retained both title formats with no duplicate keys. This is bounded three-way text compatibility, not integrated build, migration, browser or behavioral proof. #136 remains owned by its coordinator.

## Provenance and limits

This reviewer did not execute a Go compiler, race suite, Go vet, actual browser, screen reader, or full repository qualification. The local executable named Go is GNU Go rather than the required compiler. No unavailable runtime result is claimed.

The PR author reports both reorder regressions failing on regression-only `ba5d566`, all four passing with the fix, both whole local web packages passing, a build and traceability passing, and exact public/network document titles verified through normal setup in Chromium 153.0.8010.12. Those remain author-provided observations. Their broader local Go attempt passed 15 test-bearing packages before resource failures in service compilation and SQLite dependency vet; the larger accessibility fixture crashed in setup. These must not be recast as full Go/vet/browser success.

Hosted Core run `45312460743` was still awaiting native execution when this review began. The root coordinator owns final live check/run inspection, normal merge when all applicable checks pass, and actual-main CI verification. This source review supplies no substitute for those gates.

No policy approval, licence choice, release/deployment, future-module inspection/execution, or whole-UI localization completion is implied.
