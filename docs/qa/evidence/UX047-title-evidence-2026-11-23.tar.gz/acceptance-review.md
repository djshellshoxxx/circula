# PR #137 independent acceptance review

Reviewed 2026-11-24 02:57 UTC (2026-11-23 Pacific). **No acceptance/source blockers found for this bounded title-format slice.** Hosted current-head CI and actual-main qualification remain mandatory and unfinished.

## Exact scope and revisions

Independently read the live PR description, all five provider diff entries, the source template, catalogue implementation, fresh template loader, regression test and normative UX-044/UX-046/UX-047 clauses. Formed the findings below before reading the other source-review report. This reviewer made no GitHub changes and no source edits.

- PR #137 was open, ready and unmerged on final read.
- Source: `73c5afb0eeebb54c3cf7645c0300fee12cd1d733`.
- Current base: `73b98ec2c5a0ca2a94e79661aa7c005c15cdf52d`.
- Synthetic candidate: `9fddaf265dc706c8d63de046f60c1021a55abeb6`, parents current base and source.
- Independently fetched source and synthetic commit objects returned identical tree `ac2c359216d12c46965c84b45b971025daae5993`.
- Changed paths: `docs/dev/MESSAGES.md`, `internal/web/messages/en.json`, `internal/web/messages/messages_test.go`, `internal/web/shared_pages_catalog_test.go`, `internal/web/templates/base.html`.

## Acceptance findings

UX-044 requires a screen/network title. The two English messages preserve the existing public and network output and the existing empty/nonempty network-name condition. The screen heading and page data remain unchanged.

UX-046 retains document language `en`; this patch selects no additional locale. UX-047 requires text externalization without concatenated sentences and catalogue formatting. The complete title format, separators, brand and positional argument order now live in two catalogue entries. Screen and network names enter as string arguments. The new formatting fixtures cover the exact key signatures. This completes only the shared title-format externalization, not whole-UI localization, plural/number/date scope or translation product decisions.

`messages.Text` returns plain `string`, and the template helper is registered directly to it. No trusted-HTML conversion was introduced. Title content therefore retains contextual escaping by `html/template`. Literal percent characters in names are values rather than format directives. Both names are string fields, and no new privacy, route, persistence, tenant or ledger operation appears in the diff.

The four regression controls render the real shared template, cover public/network English and both reordered formats, and compare the complete escaped title. Inputs include percent characters, ampersands, angle brackets and a closing title tag. Reordered controls specifically discriminate the old hardcoded concatenation from catalogue-owned order. `mustLoadTemplates` creates a fresh output map and new parsed templates per call; each subtest obtains one fresh template before replacing its local `msg` function. The replacement delegates unrelated keys to production messages. No global template/catalogue leakage was found.

## Execution and provenance limits

This is an independent source/acceptance assessment, not a new runtime execution. I did not run Go tests, a compiler, race, vet, browser or screen reader. The author's regression-red/green, complete web-package and Chromium observations remain author-provided evidence; their broader local compilation/vet and larger accessibility fixture had explicitly recorded resource/setup failures.

At final live read, run `45312460743` attempt 1 had successful fuzz-smoke and reproducible-build jobs, Linux race in progress, four other applicable jobs queued, and the expected conditional native-matrix skip. This review does not convert pending checks into passes. Merge must await all applicable checks, fresh head/base/candidate verification and a qualified current base; a changed base requires current composition qualification. Post-merge actual-main native checks remain separate.

The other review's 24 Node helper passes and bounded text composition with #136 were read afterward and are consistent with these findings, but I did not rerun or independently certify those execution results. #135/#136 ownership is unchanged. Held policy PRs, future modules, release/deployment/licence decisions and manual/external review gates remain outside this assessment.
