# PR #137 actual-main native/provider review

Reviewed 2026-11-24 04:43 UTC (November 23 Pacific). **The completed Windows/browser/Scorecard evidence is consistent; full actual-main qualification remains pending Linux and macOS race jobs.**

Fresh connected GitHub reads confirm main `418d2ed4b289c183d1fbd087b8f7b7ee6451169e`, tree `ac2c359216d12c46965c84b45b971025daae5993`, parents qualified base `73b98ec2c5a0ca2a94e79661aa7c005c15cdf52d` and source `73c5afb0eeebb54c3cf7645c0300fee12cd1d733`. Core run `45321695163` attempt 1 is on that actual-main SHA. Fresh job metadata returned seven successes and two running jobs: Linux `138201504373`, macOS Intel `138201504638`. No pending pass is inferred from tree identity or prior source CI.

## Completed actual-main execution

I independently fetched decoded Windows and browser provider logs and byte-compared them with the root's saved logs. Each pair matched exactly as stored locally. Both logs explicitly checkout actual main.

- Windows job `138201504445`: success; command `go test -count=1 -timeout=20m ./...`, 16 passing test-bearing packages, two no-test packages, no cached results. This is native Windows **non-race** coverage. Service 388.767 s, store 354.394 s, web 122.327 s, messages 0.096 s. The locally stored normalized log is 21,806 bytes, SHA-256 `86c0ea3ba2ce374d28a533cc946ff475832aa8663d4438c35b8160c3e7123d2d`.
- Browser job `138201504074`: success; provider log records `597 passed (6.9m)`. The locally stored log is 130,073 bytes, SHA-256 `01607c739cab5f2aa371ecccc816532e06738ad82de826597fe32c0685b42acd`.
- Scorecard run `45321695017`, job `138201503240`: success, attempt 1, exact actual-main SHA. I parsed the emitted JSON: Scorecard v5.6.0, score 5.9, 18 checks. Successful execution does not close its policy/licence/review findings or any owner decisions.

The log hashes describe saved decoded text, including local LF normalization, not original compressed provider-download checksums. Original fetched Unicode string lengths differ from UTF-8 byte lengths; no binary artifact identity is inferred from these log hashes.

## Pending boundaries

Linux race and macOS Intel race were still running in the final fresh job read at 04:43 UTC. I did not claim package/test counts for either pending job, inspect a nonexistent final artifact, or rerun jobs. Root retains their completion/artifact verification and durable final qualification.

This is independent provider evidence inspection, not a new local Go/browser execution, manual screen-reader exercise, external security audit, exhaustive fuzz/load or general packaging qualification. UX-047 remains partial. I made no GitHub mutations or source edits and did not inspect other owned PRs, held policy work or future modules.
