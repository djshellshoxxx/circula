from pathlib import Path
import hashlib, io, gzip, tarfile, json, base64
r=Path(__file__).resolve().parent
required=['final-main-review.md','final-documentation-review.md']
assert all((r/p).exists() for p in required), 'Final reviews must exist before packaging'
files={}
for sub in ['provider','pinned','threeway','source']:
    for p in (r/sub).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:
            files[p.relative_to(r).as_posix()]=p.read_bytes()
for p in r.glob('*review.md'):
    files[p.name]=p.read_bytes()
files['package-evidence.py']=Path(__file__).read_bytes()
manifest=''.join(hashlib.sha256(b).hexdigest()+'  '+p+'\n' for p,b in sorted(files.items()))
files['SHA256SUMS']=manifest.encode()
out=io.BytesIO()
with gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as gz:
    with tarfile.open(fileobj=gz,mode='w') as t:
        for p,b in sorted(files.items()):
            ti=tarfile.TarInfo(p);ti.size=len(b);ti.mtime=0;ti.mode=0o644;t.addfile(ti,io.BytesIO(b))
raw=out.getvalue()
path=r/'UX047-title-evidence-2026-11-23.tar.gz';path.write_bytes(raw)
with tarfile.open(path,'r:gz') as t:
    assert set(t.getnames())==set(files)
    for line in t.extractfile('SHA256SUMS').read().decode().splitlines():
        sha,p=line.split('  ',1);assert hashlib.sha256(t.extractfile(p).read()).hexdigest()==sha
encoded=base64.b64encode(raw);(r/'evidence.b64').write_bytes(encoded)
meta={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'payloads':len(files)-1,'manifest':'SHA256SUMS','base64_bytes':len(encoded)}
(r/'archive-metadata.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
