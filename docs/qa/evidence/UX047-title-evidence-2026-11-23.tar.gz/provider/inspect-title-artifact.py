from pathlib import Path
import collections
import hashlib
import json
import sys
import zipfile

root = Path(__file__).resolve().parent
prefix, run_id, source, tested = sys.argv[1:]
metadata = json.loads((root / (prefix + '-artifacts.json')).read_text())
artifacts = [a for a in metadata['artifacts'] if a['name'] == 'test-evidence-ubuntu-24.04']
assert len(artifacts) == 1
artifact = artifacts[0]
assert artifact['workflow_run']['id'] == int(run_id)
assert artifact['workflow_run']['head_sha'] == source
raw = (root / (prefix + '-test-evidence.zip')).read_bytes()
checksum = hashlib.sha256(raw).hexdigest()
assert artifact['digest'] == 'sha256:' + checksum
assert artifact['size_in_bytes'] == len(raw)
with zipfile.ZipFile(root / (prefix + '-test-evidence.zip')) as archive:
    assert len(archive.infolist()) == 2
    assert set(archive.namelist()) == {'traceability-results.json', 'TRACEABILITY-results.md'}
    record = json.loads(archive.read('traceability-results.json'))
assert record['head'] == tested
assert record['dirty'] is False and record['exit_code'] == 0
assert all(x in record['command'] for x in ['-race', '-count=1', './...'])
named = collections.Counter(e['Action'] for e in record['results'] if e.get('Test'))
packages = collections.Counter(e['Action'] for e in record['results'] if not e.get('Test'))
assert named['fail'] == 0 and named['skip'] == 6
assert packages == {'pass': 16, 'skip': 2}
assert all(e['Action'] in {'pass', 'skip'} for e in record['results'])
title = [e for e in record['results'] if e.get('Test', '').split('/')[0] == 'TestDocumentTitleCatalogue']
assert len(title) == 5 and all(e['Action'] == 'pass' for e in title)
for name in ['TestPageStructure', 'TestEveryCatalogueEntryFormats']:
    assert any(e.get('Test') == name and e['Action'] == 'pass' for e in record['results'])
summary = {'artifact_id': artifact['id'], 'zip_bytes': len(raw), 'zip_sha256': checksum,
           'head': record['head'], 'dirty': record['dirty'], 'exit_code': record['exit_code'],
           'source_digest': record['source_digest'], 'command': record['command'],
           'named': dict(named), 'packages': dict(packages), 'title_regression': title,
           'explicit_skips': [e['Test'] for e in record['results'] if e.get('Test') and e['Action'] == 'skip']}
(root / (prefix + '-test-summary.json')).write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
