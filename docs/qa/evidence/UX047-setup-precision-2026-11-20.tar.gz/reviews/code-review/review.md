# Circula UX-047 setup precision — independent code review

**Verdict: APPROVED for this bounded source change. No blocking issues or actionable review findings.**

This is source-review approval, with build/test acceptance owned by the coordinator. It does not close UX-047 globally or approve a release.

## Reviewed snapshot

- Worktree: `/workspace/scratch/56ccc19d5666/circula-ux047-precision`
- Branch: `codex/ux047-setup-precision-20261120`
- Base and current HEAD: `87651d36558a8e421e41fbd76c514045d88c74ed`
- Five uncommitted files: `internal/web/h_auth.go`, `internal/web/messages/en.json`, `internal/web/messages/messages_test.go`, `internal/web/messages/onboarding_test.go`, `internal/web/setup_decimals_test.go`.
- Patch: 92 additions, 5 deletions. SHA-256 of `git diff --no-ext-diff BASE --` those files: `f5078e1b03843cac7ab1944abb4456274d7be743381a653912e2fdaf68431a00`.

## Standards

**0 documented-standard violations; 0 actionable maintainability findings.** An independent standards subreview reached the same conclusion.

- `internal/web/h_auth.go:203` follows the first-integer plural argument contract documented in `internal/web/messages/messages.go:50`. Precision is argument 1, the localized label argument 2, and the exact example string argument 3. All references to the setup key in `internal/web` use the updated order.
- `internal/web/messages/en.json:1946` keeps the complete correction sentence in the catalogue and matches the existing `admin.policy.amount_invalid` convention. No sentence-building logic, shared formatter change, dependency, or abstraction is introduced.
- Amounts remain integer minor units, and `domain.FormatAmount(1250, dec)` still supplies a string. This preserves the no-floating-point rule in `CONTRIBUTING.md` and LED-7 in `docs/specs/00-conventions.md`.
- Unit and HTTP regressions satisfy the contribution requirement for tests accompanying a behavior change. Independent expected strings in both layers are useful assertions, not an extraction opportunity.

## Spec and correctness

**0 missing or incorrect requirements for this slice; 0 scope-expansion findings.**

`docs/specs/08-ux-accessibility.md:237` requires plural and number formatting through message catalogues. The patch fixes the reachable precision-1 correction for both Default credit limit and Sign-up grant. Precision 0, 2, and 4 retain their plural wording and exact examples. English remains the only supported catalogue; no translation or policy choice is made.

The precision bound remains checked before formatting (`internal/web/h_auth.go:192`). Both fields still use the existing parse closure, and the error branch still returns 422 before `CreateNetwork` (`internal/web/h_auth.go:208`). Submitted values, error field identifiers, contextual template escaping, and the successful creation path are untouched.

The added HTTP cases (`internal/web/setup_decimals_test.go:39`) use the real HTTP server, authentication, CSRF form submission, and database-backed service. They assert both full correction sentences, selected precision, summary links, inline error identifiers, escaped retained values, ARIA associations, status 422, and absence of the submitted network slug. Catalogue tests cover both labels at precisions 0/1/2/4. The existing malformed/out-of-range precision test remains intact.

## Evidence and limits

I inspected the coordinator's `red-metadata.json`, `red-tests.jsonl`, and stderr log under `/workspace/scratch/56ccc19d5666/circula-ux047-evidence`. Their recorded execution fails only the precision-1 unit and HTTP cases; precision 0/2/4 and malformed-precision controls pass. This supports regression specificity.

I ran no product tests, build, vet, formatter, linter, or race checks and made no repository edits. Green/race/vet/build results are separate coordinator evidence, not inferred here. Review covered the five changed files, applicable contribution/spec rules, and directly relevant helpers/templates/domain formatting contracts. No future modules, policy selection, remote writes, automation changes, or external services were involved.

**Totals: Standards 0 findings; Spec/correctness 0 findings. Approval is limited to the recorded five-file snapshot.**
