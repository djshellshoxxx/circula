# Independent PR #144 corrected-delta source review

Reviewed 2026-11-28 Pacific. **No actionable source blocker found** in the bounded
delta from `8c3ea2d91783dfcd4e951a92ab867fa0b3a9292a` to
`9f7d98d4917bb7243ea7cefc79033e34053d8e3a`.

Read connected GitHub comparison and exact-head `e2e/fixtures.js`,
`e2e/playwright.config.js`, `e2e/global-setup.js`, stylesheet and added browser
test. No local checkout or prior worker runtime claim was used as current test
execution. No product changes, tests, browser execution or CI rerun were made.

## Fixture and browser assertions

The normal global seed creates Dana Admin as network founder/administrator,
Carol Member as a normal member then explicitly grants her dispute-reviewer
role, and Alice Member as an ordinary member. These match the new test's exact
name and role expectations. `as('admin')` opens the real admin storage state in
a fresh browser context using the seeded base URL. The test explicitly selects
a 320 by 850 CSS-pixel viewport before visiting the member table.

The row locator combines the native row role with an exact row-header name and
selects that row's role cell. It requires single role list items for Dana/Carol,
the literal ordinary-member catalogue fallback for Alice, and no empty list in
that fallback. This is a useful actual-page regression for list semantics; it
does not itself cover a member with two simultaneous roles. The original pure
template regression provides that separately, and the author reports additional
runtime checks. Do not describe those separate results as this test's coverage.

The action locator measures every actual link in member action cells. The
nonempty assertion prevents a vacuous pass, and the width/height filter requires
both dimensions to reach 24 CSS pixels. The axe helper runs WCAG 2.0/2.1 A/AA and
2.2 AA tags in both light and dark schemes and restores light afterward. The
suite is serial with no retries; this test reads seeded state rather than
mutating roles.

## CSS and markup

The new class is scoped to member-action table cells. Inline-block sizing makes
minimum logical inline/block sizes effective; `max-inline-size:100%` permits
the element to fit a narrow cell. Inherited body wrapping remains available for
long labels. The rule neither removes link semantics nor changes action URLs,
accessible names, role labels, authorization or escaping. Existing table stacked
layout still applies below 40rem. The unchanged role-list rule retains visible
list markers and logical indentation.

The dimension assertion runs in the initial scheme; axe checks both schemes.
Stylesheet scheme rules only change colour variables, not the new sizing rule,
so there is no identified scheme-dependent geometry issue. This is source
reasoning, not a claimed rendering observation.

## Evidence and acceptance limits

The QA addition distinguishes the first source build's completed CI from the
corrected head needing its own qualification, and sends readers to PR #144 for
the latter. The 125 repeated template runs, 240 authenticated reads, eight-client
load, grant/removal round trip and original narrow-screen axe result remain
author-reported observations until independently verified by the coordinator.
I did not reproduce them or inspect their original logs.

Corrected native CI and required exact-head composition checks remain gates.
This source review is not a corrected-head browser pass, full responsive/zoom
qualification, keyboard walkthrough, manual screen-reader pass, independent
external security acceptance or whole UX-047 completion. #142/#143, held policies
and all future modules were not reviewed or changed.
