# UX-047 main receipt review — three additional jobs

**Accepted, with zero blocking findings.** Combined with `interim-review.md`, this qualifies seven completed actual-main receipts: six Core jobs and Scorecard. The Linux race, macOS race and browser receipts remain outside this interim approval. No prior PR execution is substituted for them.

All three new jobs belong to Core push run `44871808943`, attempt 1, and identify actual main `fff81fc7f64cb4858c09d4a3a6f1ff0a55a1a337`. The earlier stable receipt inputs still match their reviewed hashes; that earlier checkpoint is unchanged.

| Additional receipt | Verified result |
| --- | --- |
| Windows, 136747776292 | Native Go 1.26.11 windows/amd64 executes `go test -count=1 ./...`. Raw output has 16 distinct passing packages and two no-test packages, exactly matching the saved Windows summary. |
| Reproducibility/smoke, 136747776303 | Both builds have SHA-256 `f42029371e8aee84115d99d337dad99babcf80b8ac7eb62fbf0f0eb3184a3e07`, followed by `reproducible build: ok`. The separate smoke command reports success. |
| Contract/load, 136747776449 | Contract coverage passes 89 operations and 172 distinct operation/status pairs. QA-008 completes 100 disjoint trades. Load completes 100 of 100 attempted trades, with 200 committed writes, zero unavailable/unexpected errors, retries or abandoned attempts, `ledger_ok=true`, and summed member balances zero. |

## Precise limits

Windows provides native non-race execution. Non-verbose output does not establish named test/skip counts. The macOS-only race step is correctly skipped within the Windows matrix job; every applicable step succeeds. The raw log identifies checkout at lines 94 and 106, toolchain at 157, command at 208–209, and package results at 214–231.

Reproducibility compares configured Linux/amd64 static builds from different directories and caches. Pinned-source inspection confirms the existing explicit-stamp and `-buildvcs=false` design; this is not cross-target reproducibility. The raw log records equal hashes at 226–227 and success at 228. The separate smoke script checks unit command/environment compatibility, readiness/health probes, database mode `0600` and clean SIGTERM shutdown, with success at line 235. It runs in a temporary loopback environment; actual systemd operation and deployment remain separate.

Contract coverage is recorded at log lines 228–231; the separate QA-008 case at 245–246; bounded load configuration/results at 248–256. These results do not approve release-performance thresholds. Scorecard findings remain preserved in the initial review.

## Provenance

`interim-addendum.json` records exact job IDs, results, source anchors, limits and all new input hashes. `interim-addendum-jobs.json` freezes the exact inspected jobs snapshot while coordinator polling continues. Windows raw log: 22,119 bytes, SHA-256 `ae17521ba26c5bf2190b4603598cb332535342eb75b1ba979aa9a36d3c60989a`. Reproducibility/smoke: 19,933 bytes, SHA-256 `fa8140e1e194114bb9a41c677495bc64788d96d8c3b5004b79c2b0c3d808934f`. Contract/load: 22,829 bytes, SHA-256 `26e91c63b60ab89ad2e26889033edc5d2fa46caae17587291447063791229a8b`.

An independent subreview checked reproducibility/smoke and contract/load, including their pinned scripts. Review activity comprised read-only saved-receipt and pinned-source inspection, JSON/hash comparisons and review-artifact writing. No product tests, product binaries, browser, provider calls/polling, repository edits or remote mutations were performed. Held policy PRs and future modules were excluded.
