# UX-047 actual-main interim receipt review

**Accepted for the four completed receipts reviewed; zero blocking findings.** This is not full main-branch qualification. Six other Core jobs remain outside this interim review, and prior PR results are not substituted for them.

## Source linkage

The saved merge receipt and local Git object agree on main `fff81fc7f64cb4858c09d4a3a6f1ff0a55a1a337`, tree `1f96de30d05b7886736315d07bf5820b6d37d995`, and ordered parents `87651d36558a8e421e41fbd76c514045d88c74ed` and `81f6bf5d0e073d4be78118f5baf3d8946b8347d5`. PR #130 is recorded as merged at `2026-11-21T05:38:15Z`. The merge delta contains exactly the 12 intended source/document/evidence paths. The recorded Core jobs belong to push run `44871808943` at the actual merge commit. All three completed Core jobs reviewed here succeeded on attempt 1, and their raw logs identify that exact checkout.

## Completed receipts

| Receipt | Independently confirmed |
| --- | --- |
| Lint, job 136747776055 | All recorded steps succeed. Action pins, hygiene and four migration checks, existing evidence manifest, dependency licences, formatting, vet and traceability freshness pass. Python helper suites pass 49, 4 and 8 tests. Node records 24 passes, zero failures/skips. Lint reports zero issues; govulncheck reports no vulnerabilities; final repository secret scan reports no leaks. |
| Fuzz, job 136747776287 | Configured internal seed selection passes. The five targeted campaigns each record one PASS after exactly their configured budgets: 1,000,000 executions for FuzzParseAmount and 100,000 each for FuzzStrictUnmarshal, FuzzOpenCursor, FuzzSessionPosition and FuzzSessionSelector. |
| Packaging, job 136747776222 | Windows/amd64, Linux/amd64, Linux/arm64, Darwin/amd64 and Darwin/arm64 packages build, scan and verify. Upload artifact 14694227930 succeeds, reported size 35,699,820 bytes and digest `1b86a14a7533480d4ca052b1f665d3b60e85c8fe95dcbab7d63dc9c4c9554dae`. |
| Scorecard, job 136747775287 | Push run 44871808928 succeeds on attempt 1 at actual main. Analysis and SARIF upload/processing succeed. The compact raw-log JSON exactly matches the saved results report. Its findings remain separate from execution success. |

The lint log records checkout at lines 108 and 120 and Go 1.26.11 at line 173. The scanner-control findings at lines 274–283 are deliberate controls, followed by the clean repository scan at line 286. The linter retains its existing `verify: false` for optional remote schema verification; the actual linter runs and reports zero issues. No `continue-on-error` appears in the lint job.

The fuzz log records actual main at lines 107 and 119, Go 1.26.11 at line 169, and the five terminal execution/PASS pairs at lines 253–254, 268–269, 282–283, 295–296 and 308–309. These are bounded fuzz campaigns, not exhaustive input-space proof.

The packaging log records actual main at lines 108 and 120; all five archive scans and complete-set verification succeed at lines 237–239. Upload digest and artifact identity appear at lines 276–279. The artifact was not downloaded or independently rehashed in this review. Packaging/cross-compilation does not qualify native runtime behavior or release publication.

## Scorecard findings preserved

The report uses Scorecard v5.6.0, records overall score **5.9**, and contains **18 checks**: seven scores of 10, six scores of 0, three partial scores (3, 4 and 8), and two unscored (-1). The zero-score entries are Maintained, Code-Review, CII-Best-Practices, SAST, Branch-Protection and License. Partial entries are Contributors, Security-Policy and Pinned-Dependencies; Packaging and Signed-Releases are unscored. Successful execution does not close these findings or supply owner decisions. The Maintained result specifically cites the repository being younger than 90 days.

Scorecard raw-log lines 1254 and 1257 confirm successful SARIF upload and completed code-scanning processing; the compact report is at line 1226. The configured action requests publication of results, but this review did not separately query the public Scorecard API. An independent narrow subreview confirmed the Scorecard and packaging receipts and their integrity anchors.

## Scope and integrity

The companion `interim-review.json` records each inspected input's SHA-256 and size, exact reviewed jobs, source anchors, fuzz counts, packaging receipt, Scorecard findings and the six Core job IDs outside this review. Full Linux/native runtime, browser, contract/load and reproducibility qualification require their own completed actual-main receipts.

Reviewer activity was limited to read-only source/Git metadata, log inspection and JSON/hash comparisons, plus writing these review artifacts. No product tests, product binaries, browser sessions, repository changes, provider calls/polling or remote mutations were performed. Held policy PRs and all 15 future modules were excluded.
