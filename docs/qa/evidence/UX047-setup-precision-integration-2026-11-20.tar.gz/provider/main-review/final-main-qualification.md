# Circula UX-047 PR130: final actual-main qualification

## Approval

**Approved for the configured actual-main execution receipts: all nine Core jobs plus Scorecard. Zero blocking findings; no CI job remains unqualified in this set.** The approval applies to merge commit **`fff81fc7f64cb4858c09d4a3a6f1ff0a55a1a337`** in `djshellshoxxx/circula`. It preserves the coverage limits, skips, Scorecard findings and partial UX-047 status documented below.

| Workflow | Run | Event / attempt | Final result |
| --- | --- | --- | --- |
| Core CI | [44871808943](https://github.com/djshellshoxxx/circula/actions/runs/44871808943) | push to main / 1 | completed, success; nine jobs |
| Scorecard | [44871808928](https://github.com/djshellshoxxx/circula/actions/runs/44871808928) | push to main / 1 | completed, success; one job |

Core's final saved update is **2026-11-21T06:18:18Z**. Every job in both saved run receipts names the same actual main SHA and attempt 1. [Core receipt](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/main-core-run-final.json) · [Scorecard receipt](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/main-scorecard-run-final.json) · [Frozen final jobs](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-main-review/final-main-jobs.json).

## Source and merge identity

The normal merge of PR **#130** is supported by the saved merge receipt and pinned local Git object:

| Identity | Value |
| --- | --- |
| Actual main | `fff81fc7f64cb4858c09d4a3a6f1ff0a55a1a337` |
| Tree | `1f96de30d05b7886736315d07bf5820b6d37d995` |
| First parent | `87651d36558a8e421e41fbd76c514045d88c74ed` |
| Second parent / topic head | `81f6bf5d0e073d4be78118f5baf3d8946b8347d5` |
| Preserved topic ref | `refs/heads/codex/ux047-setup-precision-20261120` |

At the final saved provider checkpoint, main and topic still identify these commits. The main tree equals the reviewed topic-head tree, and the merge differs from its first parent in exactly the twelve intended paths recorded in the JSON report. The Linux execution header records `dirty=false` and source digest `ce4bc23996840a6e10d6e9405ef148e16a0f3d200e67103296d9128b4bd9b1dd`. That digest equals the PR artifact header, consistent with the identical tree; **all execution qualification here uses actual-main receipts**. PR test outcomes were not substituted.

[Merge receipt](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/merge-snapshot.json) · [Frozen final refs](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-main-review/final-main-refs.json).

## Complete job qualification

| Job ID | Job | Execution | Evidence accepted |
| --- | --- | --- | --- |
| 136747776055 | vet, gofmt, golangci-lint, govulncheck | success | Lint/vet/gofmt, dependency and secret controls, Python/Node helpers, and govulncheck passed; 0 lint issues. |
| 136747776222 | build release targets | success | Five release targets built, archive scans/verification passed; artifact 14694227930 uploaded. |
| 136747776287 | fuzz smoke (RB-017) | success | Internal seed selection and five bounded fuzz campaigns passed (1,000,000 / 100,000 / 100,000 / 100,000 / 100,000 executions). |
| 136747776292 | test (windows-2022) | success | Native Windows non-race: 16 passing packages, 2 no-test packages; no named counts emitted. |
| 136747776295 | e2e (Playwright, axe, keyboard) | success | Chromium Playwright/axe/keyboard: 597 of 597 tests passed; no failures, skipped/flaky summaries, or retries. |
| 136747776303 | reproducible build (two builds, same sha256) | success | Two Linux/amd64 build hashes equal; configured loopback smoke passed. |
| 136747776346 | test (ubuntu-24.04) | success | Linux race: 3,272 named passes, 6 skips, 0 failures; 16 package passes and 2 no-test packages. |
| 136747776449 | API contract and load smoke | success | 89 API operations / 172 operation-status pairs; bounded 100-trade load completed with ledger_ok=true. |
| 136747776459 | test (macos-15-intel) | success | Native macOS Intel race: 16 passing packages, 2 no-test packages; no named counts emitted. |
| 136747775287 | scorecard analysis | success | Scorecard execution/upload succeeded; score 5.9 across 18 checks, findings preserved. |

The earlier stage reports remain preserved. All **21 previously reviewed stable input files**, including all **nine earlier job logs**, still match their recorded hashes. The final macOS job supplies the tenth accepted execution receipt.

## Final macOS receipt

Job **136747776459** ran on `macos-15-intel` from **2026-11-21T05:38:23Z** to **2026-11-21T06:18:17Z**. Its checkout log identifies the expected full main SHA at lines **107 and 119**, and line **184** records **Go 1.26.11 darwin/amd64**. The exact command at lines **235–236** is:

```text
go test -race -count=1 -p 2 -timeout=45m ./...
```

The independent raw-log recount finds **16 distinct passing packages** and **two no-test packages** (`internal/storetest`, `internal/testutil`), exactly matching the saved macOS summary. No failure, data-race-warning, or cached-result markers appear. The command emits no named test results, so this report assigns no named pass or skip counts to macOS.

All applicable steps succeeded. The sole skipped step is `test`, which the pinned workflow explicitly limits to Windows. The macOS race step ran successfully; its `-p 2` package concurrency and per-package 45-minute timeout match the checked-in workflow. [macOS log](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/main-job-136747776459.log) · [macOS summary](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/main-macos-summary.json).

## Linux race results and new regressions

The actual-main Linux artifact independently recounts to:

| Terminal event class | Pass | Skip | Fail |
| --- | ---: | ---: | ---: |
| Named tests / subtests | 3,272 | 6 | 0 |
| Packages | 16 | 2 | 0 |

All **3,296 terminal `(Package, Test)` keys are unique**, and all event timestamps fall within Linux job **136747776346**. The JSON and generated report agree on the main SHA, `dirty=false`, exit code **0**, and `go test -json -count=1 -race -timeout 30m ./...`.

The new `TestSetupAmountValidationMessages` and `TestSetupAmountValidationUsesSelectedPrecision` regressions contribute **14 passing parent/subtest events**: two parents plus **12 subtest cases**. They cover the two message field labels and selected precisions **0, 1, 2 and 4**. The full event identities and timestamps are preserved in the JSON report.

Artifact **14695042424**, `test-evidence-ubuntu-24.04`, is **138,293 bytes**, SHA-256 **`3de1693d800f8148f44a91ea637785737feafd7d0d774838ead44ab9ee41fe7e`**. It matches both provider and upload digests. CRC verification passes; its exactly two safe, unique members are byte-identical to the saved **712,564-byte** execution JSON and **319,454-byte** generated report. A second reviewer independently confirmed this integrity and source linkage. [Linux artifact](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/main-test-evidence.zip) · [Execution JSON](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/main-traceability-results.json).

### Six explicit named skips

| Named test | Qualification boundary |
| --- | --- |
| `TestBackupStagingRefusesForeignOwnedParent` | Requires root on Unix and usable chown; foreign-ownership fixture remains unqualified in this run. |
| `TestBackupWorkLeaseChild` | Standalone subprocess helper; controlling TestBackupWorkLeaseProtectsOtherProcessAndReclaimsCrash passed. |
| `TestRestoreSwapCrashChild` | Standalone subprocess helper; controlling TestRestoreSwapCrashRefusesStartupAndPreservesFiles passed. |
| `TestLoadConcurrentTrades` | Requires CIRCULA_LOAD=1; default full-race suite does not qualify it. Previously reviewed bounded non-race load job 136747776449 is separate evidence. |
| `TestLoginTimingStatistical` | Requires CIRCULA_TIMING_TEST=1; statistical timing measurement remains unqualified. |
| `TestQA010CrashChild` | Standalone subprocess helper; controlling TestQA010CrashDuringPosting passed. |

The three controlling subprocess-parent tests listed above passed. Standalone helper skips are retained as skips. Classification comes from guards in the pinned source and actual-main terminal events; exact runtime skip text is not retained by this artifact. The separate non-race load job does not replace a skipped race-suite event.

## Supporting receipt detail

The lint job records zero golangci-lint issues, no govulncheck vulnerabilities, a clean final repository secret scan, successful deliberate scanner controls, four hygiene migration tests, Python helper batches of **49, 4 and 8**, and **24 Node passes with zero failures/skips**. Existing optional linter schema verification is disabled, but the linter itself ran.

Packaging covers **windows/amd64, linux/amd64, linux/arm64, darwin/amd64 and darwin/arm64**. Artifact **14694227930** is recorded as **35,699,820 bytes**, uploaded with SHA-256 **`1b86a14a7533480d4ca052b1f665d3b60e85c8fe95dcbab7d63dc9c4c9554dae`**. These are verified upload receipts; reviewers did not download and independently hash that packaging archive.

The reproducibility receipt shows two matching Linux/amd64 static build hashes, **`f42029371e8aee84115d99d337dad99babcf80b8ac7eb62fbf0f0eb3184a3e07`**, from separate directories/caches with the configured stamps. The smoke check covers unit command/environment compatibility, readiness/health, database permissions **0600**, and clean SIGTERM shutdown in a temporary loopback environment.

Contract execution covers **89 operations and 172 distinct operation/status pairs**. QA-008 passes its **100 disjoint trades**. The load smoke uses **4 workers, 20 members, and 25 trades per worker**: **100/100 trades** and **200 committed write operations**, zero unavailable/unexpected errors, retries or abandoned attempts, `ledger_ok=true`, and zero sum of member balances. These are bounded smoke results.

The browser receipt independently contains **597 unique, consecutive passing rows (1–597)** and a **597 passed (6.9m)** summary. It uses one worker and the actual-main binary stamp `fff81fc7f64c`. Its failure-screenshot upload step is expected to skip on success. Browser suite execution does not provide manual or screen-reader acceptance.

## Scorecard execution and findings

Scorecard **v5.6.0** execution, result upload and processing succeeded at actual main. The raw compact JSON matched the saved result, and all five Scorecard receipt files remain byte-identical to their earlier reviewed versions. The public Scorecard API was not separately queried.

The recorded overall score is **5.9 across 18 checks**. These tool findings are preserved independently of the successful job conclusion:

| Check | Score | Recorded finding |
| --- | ---: | --- |
| Maintained | 0 | Repository created within the last 90 days. |
| Dangerous-Workflow | 10 | No dangerous workflow patterns detected. |
| Dependency-Update-Tool | 10 | Update tool detected. |
| Code-Review | 0 | 0 of 3 approved changesets in the tool sample. |
| Security-Policy | 4 | Policy file detected; partial score. |
| Packaging | unscored (-1) | Packaging workflow not detected by this check. |
| Binary-Artifacts | 10 | No binary artifacts detected in the repository. |
| Token-Permissions | 10 | Workflow token permissions passed the check. |
| CII-Best-Practices | 0 | No OpenSSF best-practices badge effort detected. |
| Vulnerabilities | 10 | Zero existing vulnerabilities detected by this check. |
| Pinned-Dependencies | 8 | At least one dependency not pinned by hash. |
| SAST | 0 | Tool reports SAST not run on all commits. |
| Signed-Releases | unscored (-1) | No releases found. |
| Fuzzing | 10 | Project fuzzing detected. |
| Branch-Protection | 0 | Tool reports branch protection not enabled on development/release branches. |
| License | 0 | Project licence file not detected. |
| Contributors | 3 | One contributing company or organisation detected. |
| CI-Tests | 10 | 3 of 3 sampled merged PRs checked by a CI test. |

The `Maintained` score is explicitly attributable to repository age under 90 days. Scorecard's packaging detection does not erase the separately verified package build/upload receipt. The dependency-licence whitelist check does not establish a chosen project licence. No security-policy, branch-protection, project-licence, signing, release or owner-decision closure is asserted. [Scorecard results](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/main-scorecard-results.json).

## Traceability and UX-047 status

The generated report records **531 IDs**, **13 built requirements with no test citation**, **zero unknown IDs**, and **zero duplicate IDs**. Its generator log reports **895 of 906** legacy citations still resolving. Successful generation preserves these inventory/coverage gaps.

**UX-047 remains partial.** Its row names the two new setup amount-validation tests and retains the distinction between source citations, passing test events, and whole-requirement acceptance. Whole-UI localisation, manual/external gates and translation scope remain outside this qualification. [Generated execution-linked report](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/main-TRACEABILITY-results.md).

## Approval boundaries

- Qualification covers the configured actual-main CI receipts for this specific merge commit. UX-047 remains partial; whole-UI localisation and translation scope remain product decisions.
- The six recorded Linux named skips remain skips. Privileged foreign-ownership and statistical timing coverage remain unqualified; opt-in load has only separate bounded non-race evidence.
- Windows evidence is non-race. macOS and Windows logs emit package outcomes but no named-test or named-skip counts; Linux counts are not substituted for either platform.
- The configured Chromium Playwright/axe/keyboard suite passed; manual usability, assistive-technology and screen-reader acceptance are not established by this receipt review.
- Fuzz campaigns and contract/load smoke are bounded. No exhaustive fuzz coverage, capacity claim or release-performance threshold approval is established.
- Five target archives were built, scanned, verified and uploaded. The packaging ZIP was not independently downloaded/rehashed by reviewers; upload digest is receipt evidence. Native runtime coverage does not extend to every cross-build target.
- Reproducibility covers the configured Linux/amd64 static target and toolchain. Smoke uses a temporary loopback environment and does not qualify an actual systemd deployment.
- Scorecard execution success is separate from its score and findings. No policy, branch-protection, project-licence, signing, release, deployment or owner-decision closure is implied.
- Traceability citations and passing cited tests are not whole-requirement acceptance; 13 built requirements have no test citation and only 895 of 906 legacy citations resolve.

## Evidence preservation

The machine-readable [final-main-qualification.json](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-main-review/final-main-qualification.json) contains the complete job mapping, exact detailed results, Linux regression event timestamps, Scorecard checks, input-file sizes/hashes and qualification limits. Final jobs and refs are frozen alongside this report.

### Final metadata hashes

| Receipt | SHA-256 |
| --- | --- |
| `main-core-run-final.json` | `52b621bc2aad5c78afd0e93b5f50352b2f4a9de924b885045ec420579aacb0e6` |
| `main-jobs-latest.json` | `d65b054ebae317b08b11715461f9e62e69ce7682dfeb75bc06f4bcf3f9a1ee5e` |
| `final-refs.json` | `ae5cbb94d64cef244be1d204f761fa6dbeabb19fc95678b1266b0babcdeb7665` |
| `main-macos-summary.json` | `a697c308ea425bf1599e0de7f0dda26a9df2ec316326835c3e74284013165b70` |

### Raw job-log hashes

| Receipt | Bytes | SHA-256 |
| --- | ---: | --- |
| `main-job-136747775287.log` | 152,695 | `ae8af2b9663bd55eacc31495e5f87ee71d84467871ebbfe7ebd490feaf32df75` |
| `main-job-136747776055.log` | 41,391 | `0673103e6f8713298436e3b43cc57e81e13d501e8d167cc372b14bd51f9cbbee` |
| `main-job-136747776222.log` | 24,021 | `73391348d8d39684031a6b3a189a6f664ab1aee09068feca7a7fc0d34eb279e6` |
| `main-job-136747776287.log` | 27,688 | `21b7dcb3e218065aa16c28d8255ddb1e34b9c74ae0074c15cedcae915b7321e7` |
| `main-job-136747776292.log` | 22,119 | `ae17521ba26c5bf2190b4603598cb332535342eb75b1ba979aa9a36d3c60989a` |
| `main-job-136747776295.log` | 129,785 | `bb00e022b2d23940cf6a93a855c84422bf1660b3783ca4595fda54eb3879ba4a` |
| `main-job-136747776303.log` | 19,933 | `fa8140e1e194114bb9a41c677495bc64788d96d8c3b5004b79c2b0c3d808934f` |
| `main-job-136747776346.log` | 23,734 | `686c4cebc25a9f7e4bf1d82b520635483e156c7d5cd794eae8f9b8191eec7382` |
| `main-job-136747776449.log` | 22,829 | `26e91c63b60ab89ad2e26889033edc5d2fa46caae17587291447063791229a8b` |
| `main-job-136747776459.log` | 23,829 | `103f32f08ce78561a078ee31382e14940cfe500b520939a485f3e1a81a16d730` |

### Preserved review chain

| Prior report | SHA-256 |
| --- | --- |
| `interim-review.json` | `3b15b634e8d1c2d167b9d4af0f118a5923d898842744283d5055288a140ae256` |
| `interim-addendum.json` | `a259319227e0c407f5280d9b3c3c82c0d7341a34494b03d9b882c4e5f57ed580` |
| `browser-addendum.json` | `ba43decaa291404f99c1102d88a8fdc5cc87ec0ef3e89386f3c9df8f50479bc4` |
| `linux-addendum.json` | `38dbf2672b69b264f495181657c8c066638be3910f64355b33f1b1b859162eec` |

## Method and review independence

This qualification combines saved provider run/job/ref metadata, raw CI logs, pinned Git/source inspection, explicit result recounts, and hash/CRC/byte comparisons. An independent subreviewer confirmed Scorecard and supporting receipts, Linux artifact integrity/source linkage, and final Core/jobs/refs/Scorecard consistency, with zero blocking findings.

Only review artifacts were written. No product tests or binaries, browser execution, provider requests/polling, repository/source edits, remote mutations, held policy PR inspection or future-module work was performed. Root owns archival and evidence-branch publication.
