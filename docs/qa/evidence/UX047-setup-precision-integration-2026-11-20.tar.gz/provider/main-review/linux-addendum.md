# Circula UX-047: actual-main Linux race addendum

## Decision

**Accepted for nine completed receipts only; zero blocking findings.** This addendum qualifies Linux race job **136747776346** from Core push run **44871808943**, attempt **1**, for actual main **`fff81fc7f64cb4858c09d4a3a6f1ff0a55a1a337`**. Together with the preserved earlier reviews, eight of the nine Core jobs and the separate Scorecard job have accepted execution receipts. **macOS Intel race job 136747776459 remains outside this review.** No full actual-main, whole-UX-047, release, or deployment acceptance is asserted.

The prior report is [browser-addendum.json](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-main-review/browser-addendum.json), SHA-256 `ba43decaa291404f99c1102d88a8fdc5cc87ec0ef3e89386f3c9df8f50479bc4`. All eight previously reviewed job logs still match their recorded hashes. Historical reports are preserved.

## Actual-main source and execution linkage

The pinned Git object has tree `1f96de30d05b7886736315d07bf5820b6d37d995` and parents, in order, `87651d36558a8e421e41fbd76c514045d88c74ed` and `81f6bf5d0e073d4be78118f5baf3d8946b8347d5`. The saved job metadata and raw checkout log identify the full expected main SHA. The log records Go **1.26.11 linux/amd64** and invokes the traceability recorder with the race detector. The JSON execution header and generated report agree on the full main SHA, `dirty=false`, exit code **0**, and source SHA-256 `ce4bc23996840a6e10d6e9405ef148e16a0f3d200e67103296d9128b4bd9b1dd`.

The recorded command is:

```text
go test -json -count=1 -race -timeout 30m ./...
```

All nine recorded job steps completed successfully. The job ran from **2026-11-21T05:44:45Z** to **2026-11-21T06:04:00Z**. All terminal-event timestamps fall within that interval, from **2026-11-21T05:45:38.903812212Z** to **2026-11-21T06:03:56.077800521Z**. These are fresh actual-main results.

The source digest equals the PR artifact header, and main's tree equals PR source head `81f6bf5d0e073d4be78118f5baf3d8946b8347d5`. The PR execution header identifies synthetic merge `733c82965f731f61119e431ea93de2d709361fc0`. Only its source digest was used for this comparison; qualification counts below were recounted exclusively from the actual-main artifact.

Raw log anchors: checkout lines **108/120**; toolchain **171**; recorder command **222–223**; terminal-result count **229**; generated report summary **240**; upload digest **266**; final artifact ID/size **268–269**. [Raw Linux log](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/main-job-136747776346.log).

## Independent result recount

| Result class | Pass | Skip | Fail |
| --- | ---: | ---: | ---: |
| Named test/subtest terminal events | 3,272 | 6 | 0 |
| Package terminal events | 16 | 2 | 0 |

There are **3,296 terminal events** and exactly **3,296 distinct `(Package, Test)` keys**, with no duplicates. The two package skips are the no-test packages `internal/storetest` and `internal/testutil`. The independent recount exactly matches the coordinator summary.

Both new setup-validation regressions passed with all of their subtests: `TestSetupAmountValidationMessages` has two field labels at precisions 0, 1, 2, and 4; `TestSetupAmountValidationUsesSelectedPrecision` has subtests at precisions 0, 1, 2, and 4. This is **14 passing parent/subtest events**, representing **two parent events plus 12 subtest cases**. Full event identities and timestamps are preserved in [linux-addendum.json](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-main-review/linux-addendum.json).

## Explicit skip boundaries

The six named skips remain skips. Classification below comes from the test guards in the pinned main source and the actual-main terminal events. The artifact retains terminal outcomes, so the exact runtime skip text is not available.

| Named test | Qualification boundary | Pinned source guard |
| --- | --- | --- |
| `TestBackupStagingRefusesForeignOwnedParent` | Requires root on Unix and usable chown; foreign-ownership fixture remains unqualified in this run. | `cmd/circula/backup_path_hardening_test.go:210` |
| `TestBackupWorkLeaseChild` | Standalone subprocess helper; controlling TestBackupWorkLeaseProtectsOtherProcessAndReclaimsCrash passed. | `cmd/circula/backup_work_lease_test.go:55` |
| `TestRestoreSwapCrashChild` | Standalone subprocess helper; controlling TestRestoreSwapCrashRefusesStartupAndPreservesFiles passed. | `cmd/circula/restore_swap_crash_test.go:24` |
| `TestLoadConcurrentTrades` | Requires CIRCULA_LOAD=1; default full-race suite does not qualify it. Previously reviewed bounded non-race load job 136747776449 is separate evidence. | `internal/service/loadtest_test.go:34` |
| `TestLoginTimingStatistical` | Requires CIRCULA_TIMING_TEST=1; statistical timing measurement remains unqualified. | `internal/service/enum_timing_test.go:234` |
| `TestQA010CrashChild` | Standalone subprocess helper; controlling TestQA010CrashDuringPosting passed. | `internal/service/qa010_crash_test.go:104` |

The three controlling subprocess-parent events named above passed in this actual-main artifact. Their standalone helper skips are not counted as extra passes. The privileged ownership fixture and opt-in statistical timing measurement remain unqualified. The separately reviewed bounded load smoke is non-race evidence and does not replace the skipped full-suite load event.

## Artifact integrity

Artifact **14695042424**, `test-evidence-ubuntu-24.04`, belongs to run **44871808943** at the expected main SHA. Its **138,293 bytes** hash to **`3de1693d800f8148f44a91ea637785737feafd7d0d774838ead44ab9ee41fe7e`**, matching both saved provider metadata and upload-log digest. ZIP CRC verification passes. Exactly two uniquely named safe-path members are present:

| Member | Uncompressed bytes | CRC-32 | Saved extraction |
| --- | ---: | --- | --- |
| `traceability-results.json` | 712,564 | `bca2aeef` | byte-identical |
| `TRACEABILITY-results.md` | 319,454 | `e9f07ac6` | byte-identical |

A second reviewer independently confirmed the artifact/provider/upload agreement, CRCs, membership, extracted equality, and source/execution headers, with zero blocking findings. [Artifact](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/main-test-evidence.zip) · [Provider metadata](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/main-artifacts.json).

## Traceability and Scorecard limits

The generated report records **531 IDs**, **13 built requirements without any test citation**, **zero unknown IDs**, and **zero duplicate IDs**; the generator log records **895 of 906** legacy citations still resolving. These are retained inventory/coverage limits, not erased by a successful generator step. Passing cited tests do not establish whole-requirement acceptance.

The UX-047 row remains **partial**. It names the two new setup amount-validation tests and leaves whole-UI completion and translation scope outside this qualification. [Generated report](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-evidence/provider/main-TRACEABILITY-results.md).

Scorecard execution success remains separate from its recorded **5.9 score across 18 checks**. The zero, partial, and unscored findings recorded in `interim-review.json` remain open; this addendum makes no security-policy, branch-protection, project-licence, or owner-decision claim.

## Cumulative accepted receipts

| Job | Receipt | Run | Execution |
| --- | --- | --- | --- |
| 136747776055 | vet, gofmt, golangci-lint, govulncheck | 44871808943 | success |
| 136747776222 | build release targets | 44871808943 | success |
| 136747776287 | fuzz smoke (RB-017) | 44871808943 | success |
| 136747775287 | scorecard analysis | 44871808928 | success |
| 136747776292 | test (windows-2022) | 44871808943 | success |
| 136747776303 | reproducible build (two builds, same sha256) | 44871808943 | success |
| 136747776449 | API contract and load smoke | 44871808943 | success |
| 136747776295 | e2e (Playwright, axe, keyboard) | 44871808943 | success |
| 136747776346 | test (ubuntu-24.04) | 44871808943 | success |

The only outstanding actual-main job is **136747776459**, `test (macos-15-intel)`. Its final receipt was not supplied for this review, and its execution is not qualified here. Root owns further monitoring and publication.

## Preserved input hashes

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `main-job-136747776346.log` | 23,734 | `686c4cebc25a9f7e4bf1d82b520635483e156c7d5cd794eae8f9b8191eec7382` |
| `main-jobs-latest.json` | 34,167 | `085b384622016de1f3a97c3be0f905e9f59aa2b3aa250d83e1f40a7dc02bbd65` |
| `main-artifacts.json` | 1,621 | `d8dfb1eb33ae558e41c2d51178462be9c78aed302e89ade902689c59079d676e` |
| `main-test-evidence.zip` | 138,293 | `3de1693d800f8148f44a91ea637785737feafd7d0d774838ead44ab9ee41fe7e` |
| `main-traceability-results.json` | 712,564 | `a6a122f59bdcdcf1239569e9a30509c812c23ac6a63db9716253c680f3f6e560` |
| `main-TRACEABILITY-results.md` | 319,454 | `dcf77a3a822ec9db96baa8c76009b1763ad64f487476acf9b5d4bea34e2ea4f2` |
| `main-test-evidence-summary.json` | 4,603 | `66204c15b7675940f99f2fc19078788001ce4ba6170a02f2a71afdd83316fde5` |
| `pr-traceability-results.json` | 712,545 | `5a5678cc517400d178b71f63796a044b2dd4d71dc1696e2114ae3ce56e7e6733` |

The exact jobs metadata bytes used for the Linux decision are frozen as [linux-addendum-jobs.json](sandbox:/workspace/scratch/56ccc19d5666/circula-ux047-main-review/linux-addendum-jobs.json). The PR JSON input was inspected only for header/source comparison.

## Review method

Read-only saved-receipt inspection, pinned Git/source reads, and JSON/hash/CRC/byte comparisons. Only review artifacts in this folder were written. No product tests or binaries, browser execution, provider requests/polling, source/repository edits, remote mutations, held policy PR review, future-module review, or macOS qualification was performed.
