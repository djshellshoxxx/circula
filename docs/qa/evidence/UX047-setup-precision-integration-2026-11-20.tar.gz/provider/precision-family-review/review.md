# Bounded UX-047 decimal-precision follow-up inspection

**Result: no additional confirmed singular/plural gap in the inspected family.** UX-047 remains partial. No implementation candidate is queued by this report.

## Source and scope

- Integrated Core source: `fff81fc7f64cb4858c09d4a3a6f1ff0a55a1a337`.
- Tree: `1f96de30d05b7886736315d07bf5820b6d37d995`.
- Checkout was clean before and after inspection.
- Scope: decimal-place count messages and their direct current-main web callers, focusing on setup, joining and amount validation. No whole-UI, policy-semantic or language-scope audit.

## Findings

All 12 catalogue entries that render a cardinal decimal-place count provide matching `one`/`other` forms with the precision at `%[1]d`. All 14 direct production call sites pass integer precision as argument 1. This matches the contract at `internal/web/messages/messages.go:42,51-58`.

The corrected setup caller at `internal/web/h_auth.go:203` passes precision, localized label and exact example in that order for both fields. Its precision bound precedes formatting (`h_auth.go:192-195`). Setup and the three join templates introduce no additional count-bearing precision-message caller.

The four template hint keys receive `page.Dec`, which is an `int` (`internal/web/render.go:43`) assigned from the current network precision (`render.go:193`). The shared refusal selector already matches `decimal place`, covering both singular and plural wording (`internal/web/refusal.go:149-150`). No stale plural-only selector was found in these direct paths.

An independent catalogue-only subreview inspected the corresponding singular expectations and found no form/index inconsistency. Those assertions were read, not executed by this investigation.

| Catalogue key | Entry line in `en.json` | Direct production caller(s) | Existing singular assertion in `internal/web/messages/` |
| --- | ---: | --- | --- |
| `validation.fix.decimals` | 1045 | `internal/web/refusal.go:150` | `validation_test.go:20` |
| `listing.price_help` | 1278 | `internal/web/h_home.go:383` | `marketplace_test.go:21` |
| `trade.propose.amount_hint` | 1570 | `internal/web/templates/propose.html:12` | `trade_test.go:26` |
| `trade.propose.amount_help` | 1574 | `internal/web/h_trades.go:126` | `trade_test.go:24` |
| `trade.propose.amount_decimals` | 1578 | `internal/web/h_trades.go:151` | `trade_test.go:28` |
| `setup.amount.invalid` | 1946 | `internal/web/h_auth.go:203` | `onboarding_test.go:37,44` |
| `admin.adjust.amount_hint` | 2378 | `internal/web/templates/admin_adjust.html:12` | `admin_amount_test.go:19` |
| `admin.reverse.amount_help` | 2586 | `internal/web/h_admin_f2.go:202` | `admin_amount_test.go:35` |
| `admin.reverse.amount_hint` | 2641 | `internal/web/templates/admin_reverse.html:16` | `admin_amount_test.go:33` |
| `dispute.amount_hint` | 3041 | `internal/web/templates/dispute_view.html:51`; `internal/web/templates/dispute_view.html:65` | `dispute_test.go precision-one table/assertion` |
| `dispute.amount_invalid` | 3045 | `internal/web/h_disputes.go:390`; `internal/web/h_disputes.go:412` | `dispute_test.go precision-one table/assertion` |
| `admin.policy.amount_invalid` | 3764 | `internal/web/h_admin2.go:70` | `policy_network_test.go:20` |

## Excluded false positives

Generic phrases such as “the network's decimal places,” “number of decimal places,” and “using the decimal places chosen above” do not interpolate a cardinal count. The `Decimal places` setting labels and fixed `0 to 4` range description likewise do not require a singular branch. `admin.policy.current` refers to the setting as `Decimal places (%[2]d)`; its second argument is a labelled setting value, not a misplaced count in a counted plural entry. Fixed millisecond/timestamp precision wording is outside this amount-message inspection.

## Qualification limits and continuation

No product tests, builds, reproduction runs, browser work, remote mutations or repository edits were performed. The inspection does not establish complete UX-047 coverage or approve another locale. All future modules and held policy PRs were excluded.

The continuing Core task should retain UX-047 as partial and choose its next bounded investigation from the current integrated source. This report supplies no additional precision-family repair to implement; do not reopen the historical missing-flow lists as though these already migrated entries were absent.

Machine-readable entry/call-site mapping and inspected-file hashes are retained in `result.json`.
