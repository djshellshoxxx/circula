# PR #130 — completed-gate evidence review

**Accepted the five completed gate receipts. No suppressed gate failure or blocking evidence discrepancy was observed.** This interim review does not qualify the unfinished full Linux race or browser jobs, and it is not actual-main qualification.

Reviewed at 2026-11-21T05:23:29.811808+00:00. Evidence belongs to [run 44869522658, attempt 1](https://github.com/djshellshoxxx/circula/actions/runs/44869522658).

## Source identity

All five provider job records name source `81f6bf5d0e073d4be78118f5baf3d8946b8347d5`. Each raw log independently records checkout `733c82965f731f61119e431ea93de2d709361fc0` and its merge description naming base `87651d36558a8e421e41fbd76c514045d88c74ed` and that source. The earlier applicability review verified that this synthetic merge has tree `1f96de30d05b7886736315d07bf5820b6d37d995`, identical to the reviewed source tree, with the expected two parents. All five logs record Go 1.26.11 on linux/amd64.

Every step in each completed job reports success. The workflow contains no `continue-on-error`. No unexpected Actions error/warning annotation or failing Go test event appears in these receipts. The relevant run commands match the unchanged workflow. Expected shell cleanup/no-match guards do not substitute for the checked build, readiness, health, clean-exit or archive-verification conditions.

## What the receipts establish

| Gate | Observed evidence |
| --- | --- |
| API contract/load | `TestAPIMatchesOpenAPI` passes with 89 operations and 172 distinct operation/status pairs. Both service smoke tests pass. The configured four-worker, 20-member load completes 100 trades with zero unavailable/unexpected errors, zero give-ups, and `ledger_ok=true`; member balances sum to zero. |
| Lint/security/helper checks | Action pins, hygiene/migrations, the existing evidence checksum manifest, dependency licence check, formatting, vet and traceability freshness succeed. Python suites report 49 reader, four property-runner and eight threshold tests passed. Node reports 24 passes, zero failures/skips. golangci-lint reports zero issues; govulncheck reports no vulnerabilities; the configured repository secret scan reports no leaks. |
| Reproducibility/smoke | Two independently cached/directory builds produce SHA-256 `f3ec4fb087e627faf4bba6158f43e0a8ca42afe1547fcf55c6e2bdf3590d6af2`. The script reports reproducibility success. Separate static-binary smoke reports success after readiness/health, database mode and clean SIGTERM-exit checks. |
| Fuzz | Seed invocation succeeds. Five targeted fuzzers report PASS after exactly 1,000,000 amount-parser executions and 100,000 each for strict JSON, signed cursors, session positions and session selectors. |
| Cross-build/package | All five configured targets build: Windows amd64, Linux amd64/arm64, Darwin amd64/arm64. Module verification, scanning of five archives and complete-set verification succeed. Eleven files upload as `ci-dist`, artifact 14693542450, 35,699,836 bytes; reported ZIP SHA-256 `a691f69f8700ff9ac54f2962e2094d4c806a71c6d9d4025a89d78c611a8f9de0`. |

## Qualifications beyond job success

- The reproducibility script intentionally uses `CGO_ENABLED=0`, Linux amd64, trimpath and explicit version/commit/date stamps, disabling automatic VCS stamping for both builds. This is the existing reproducibility design, not a response to the local linked-worktree failure. The separate smoke script performs a normal static build without that stamping override.
- Smoke runs on loopback with temporary state using the service unit's settings, without systemd. It is neither a production deployment nor deployment-environment certification.
- The load and fuzz results cover the configured bounded smoke workloads. They do not approve release thresholds, reference-hardware performance budgets or exhaustive input coverage. `[no tests to run]` package lines in the seed selection are not additional fuzz targets.
- Cross-building all targets does not replace native runtime qualification. The uploaded artifact's bytes were not independently downloaded in this review; the successful scan/verification/upload receipts are the evidence inspected.
- Secret-scanner control cases deliberately produce expected findings to test precise exceptions and synthetic replacements. All ten controls pass; the subsequent configured repository scan reports zero leaks. No scanner exception/configuration is changed by this PR.
- The existing golangci action has `verify: false` for network-dependent schema validation. The actual lint command runs with `only-new-issues: false` and reports zero issues; lint execution was not skipped.

## Receipt fingerprints

| Job ID | Job | Log SHA-256 |
| --- | --- | --- |
| 136740679929 | API contract and load smoke | `a0915cc89db5444d985ad3a08806294a2d899441169475f531093259b065ab7a` |
| 136740680063 | vet, gofmt, golangci-lint, govulncheck | `f4e10d53f67b74c9e0253f18f4f44a8005a567b0c2c836c68d17d43836cd14f4` |
| 136740680127 | reproducible build (two builds, same sha256) | `ce225b2d36fa40720d8279eb9628d3318490bebd83b1c42bd5482d9290b87b8b` |
| 136740680133 | fuzz smoke (RB-017) | `0b58acc93c8a67ef87680142faf1c9ba6264ebf4d8968639ae2c27de92162339` |
| 136740680223 | build release targets | `5d1ca9b96d547cebd9e32db0816a6cdbc46dcec272eae1cf4ae35ebe886e8e5b` |

Machine-readable job snapshots, hashes and metrics are retained in `completed-gates-interim.json`. Only local read-only log/metadata/source inspection and hashing were performed. No product tests/builds, repository edits, remote calls or remaining-job polling. Root retains final integration qualification.
