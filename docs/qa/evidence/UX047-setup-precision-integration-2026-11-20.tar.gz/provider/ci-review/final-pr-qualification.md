# PR #130 — complete CI qualification

**Approved at the recorded source and base, with zero blocking findings.** All seven applicable PR jobs succeeded on attempt 1 of [CI run 44869522658](https://github.com/djshellshoxxx/circula/actions/runs/44869522658). Root retains the guarded merge and subsequent actual-main qualification.

Reviewed at 2026-11-21T05:38:48.710221+00:00.

## Exact source and completed gates

Source: `81f6bf5d0e073d4be78118f5baf3d8946b8347d5`. Base: `87651d36558a8e421e41fbd76c514045d88c74ed`. Actual checkout: synthetic merge `733c82965f731f61119e431ea93de2d709361fc0`, with verified tree `1f96de30d05b7886736315d07bf5820b6d37d995` identical to the source tree. Every applicable job record names the source head. All seven raw logs record the expected synthetic-merge checkout; all use Go 1.26.11.

The five previously reviewed receipts remain byte-identical to their saved hashes; their qualification and limits are preserved in `completed-gates-interim.md`. The final provider run is completed/success on attempt 1. The saved premerge PR snapshot names the same source/base, is mergeable/clean and is still draft at that observation.

The cross-platform pre-matrix placeholder is explicitly skipped because the PR lacks its opt-in label. It is not counted among the seven passes. The browser job's failure-only screenshot upload is skipped after successful tests; all of its applicable steps succeed.

## Full Linux race evidence

Artifact 14694236500 is exactly **138,212 bytes**, SHA-256 `497625b5a948c3a5b6a90bcc9cbaafda7926b16c5f9e9e124fabda3eb6086108`, matching both the provider artifact metadata and upload log. ZIP CRC validation succeeds. Its only two members, `traceability-results.json` and `TRACEABILITY-results.md`, exactly match the extracted files inspected.

The evidence records:

- Head `733c82965f731f61119e431ea93de2d709361fc0`; dirty tree `false`; exit code 0.
- Source digest `ce4bc23996840a6e10d6e9405ef148e16a0f3d200e67103296d9128b4bd9b1dd`.
- Command `go test -json -count=1 -race -timeout 30m ./...`.
- **3,272 named passes, six named skips, zero failures.** Package terminals are 16 passes and two skips, giving 3,296 terminal records in total.
- No duplicate package/test terminal keys.
- All **14 new UX-047 parent/subtest events pass**: both message fields at precisions 0/1/2/4 plus their parent, and the four actual-handler precision cases plus their parent.

Counts were independently recomputed from the raw artifact, rather than copied from the coordinator's summary. The rendered report repeats the same head, digest, clean-tree state, command and exit status. The existing recorder rejects changes to HEAD/source across the run; its report loader rejects a different HEAD/source. This review verified those guards and the recorded linkage; it did not independently recompute the entire repository's source digest.

### Explicit skipped tests

| Named skip | Qualification |
| --- | --- |
| `TestBackupStagingRefusesForeignOwnedParent` | Existing Unix root/usable-chown prerequisite; this ownership scenario remains skipped in this suite. Terminal-only evidence does not distinguish the two prerequisite skip branches. |
| `TestBackupWorkLeaseChild` | Standalone subprocess helper; related parent TestBackupWorkLeaseProtectsOtherProcessAndReclaimsCrash passed. |
| `TestRestoreSwapCrashChild` | Standalone subprocess helper; related parent TestRestoreSwapCrashRefusesStartupAndPreservesFiles passed. |
| `TestLoadConcurrentTrades` | Opt-in CIRCULA_LOAD workload absent from full-suite command; separately passed in contract/load job136740679929. |
| `TestLoginTimingStatistical` | Opt-in CIRCULA_TIMING_TEST statistical measurement; remains unexecuted here. |
| `TestQA010CrashChild` | Standalone subprocess helper; parent TestQA010CrashDuringPosting passed. |

The two package skips are `internal/storetest` and `internal/testutil`, which have no test files. Skipped cases are not reported as passed. The three related subprocess-parent tests named above have passing terminal events in this same artifact. The load smoke's separate pass is already covered by the completed-gate review. The statistical timing and privileged ownership scenarios remain unqualified by this suite.

## Browser evidence

The browser log records a build from the same synthetic merge and execution of the existing `make e2e` target. It contains **597 distinct, consecutively numbered passing test rows, 1 through 597**, followed by **597 passed (6.5m)**. No retry, flaky, failed or skipped test result is observed. The existing Playwright/axe/keyboard job and all applicable steps finish successfully.

This is the existing automated browser suite's qualification. It does not claim a new manual screen-reader examination or completion of all UX-047 criteria.

## Merge and postmerge boundary

The evidence supports normal guarded integration of this exact source against the recorded base, subject to root's final ref check. A changed head or integration base needs renewed qualification. The actual main commit requires its own nine Core job results plus Scorecard for the same delta. Native export-reader path filters still do not match these 12 files. Prior main or PR passes must not be substituted for actual-main evidence.

Machine-readable assertions, result events, skip details and complete input-file hashes are saved in `final-pr-qualification.json`. No product/test execution, repository edits, provider polling or remote mutation was performed. UX-047 remains partial; this review approves no language, policy or release decision.
