# PR #130 CI applicability review

**CI gate mapping verified; no CI pass or merge qualification is claimed by this initial review.** The seven applicable Linux jobs were still queued in the inspected provider snapshot. The cross-platform job was correctly skipped before matrix expansion.

## Exact source

- PR: https://github.com/djshellshoxxx/circula/pull/130
- Source: `81f6bf5d0e073d4be78118f5baf3d8946b8347d5`
- Base: `87651d36558a8e421e41fbd76c514045d88c74ed`
- Source tree: `1f96de30d05b7886736315d07bf5820b6d37d995`
- Synthetic PR merge: `733c82965f731f61119e431ea93de2d709361fc0`
- Synthetic merge parents: base, then source; its tree is identical to the reviewed source tree.
- Local worktree was clean at the source commit. The change contains 12 files, and no workflow definition changes.
- Provider snapshot recorded 2026-11-21 05:11:38 UTC; see `result.json`. This is a historical observation, not an ongoing monitor.

## Applicable PR gates

[CI run 44869522658](https://github.com/djshellshoxxx/circula/actions/runs/44869522658) is a `pull_request` run for exact head `81f6bf5d0e073d4be78118f5baf3d8946b8347d5`.

| Job | Scope |
| --- | --- |
| vet, gofmt, golangci-lint, govulncheck | Action pins, hygiene/migrations, existing evidence manifest, dependency licence check, secret scan, formatting, vet, traceability freshness, Python/Node helper tests, lint and vulnerability scan. |
| test (ubuntu-24.04) | Complete Go suite with race detector and 30-minute package timeout, recorded through the traceability evidence tool. Job timeout 45 minutes. Test evidence upload runs even after failure. |
| build release targets | Cross-build/package all configured targets and upload CI artifacts. This is the existing CI build gate, not a tag or published release. |
| reproducible build (two builds, same sha256) | Compare independent builds and run the existing isolated deployment smoke. |
| fuzz smoke (RB-017) | Seed all fuzz targets; execution budgets for amount, strict JSON, cursor, session-position and session-selector fuzzers. |
| API contract and load smoke | Contract against OpenAPI and bounded service load checks. |
| e2e (Playwright, axe, keyboard) | Pinned Chromium setup and the complete existing e2e target. |

There is no `ci:cross-platform` label. The `test-cross` job condition is false on this PR; GitHub reports one skipped job named `test (${{ matrix.os }})`, rather than expanding two native jobs. That skip is neither a pass nor an unexpected failure.

The workflow's checkouts do not override `ref`. The provider exposes synthetic merge `733c82965f731f61119e431ea93de2d709361fc0`, whose tree and parents were verified. When execution evidence is available, retain the actual checkout SHA from its logs/artifacts as well as the run's source `head_sha`; do not silently treat the two commit identifiers as identical.

## Expected actual-main gates

For a normal merge whose delta remains these same 12 files, the main push triggers:

- The same seven Linux CI jobs.
- `test (macos-15-intel)`: complete race suite, `go test -race -count=1 -p 2 -timeout=45m ./...`, 60-minute job budget.
- `test (windows-2022)`: complete non-race suite, `go test -count=1 ./...`, 30-minute job budget.
- `scorecard analysis`: Scorecard execution and SARIF upload.

This is **nine Core CI jobs plus one Scorecard job: ten applicable jobs**. Actual-main qualification requires the new main SHA and its own successful applicable job results. The previous main's thirteen-job total must not be copied to this change.

## Path-filtered and event-specific workflows

The native export-reader workflow triggers on PR/main push only when one of these exact paths changes:

- `scripts/read-export.py`
- `scripts/test_read_export.py`
- `.github/workflows/export-reader.yml`

None appears in this change. Thus its three-platform matrix is not applicable to this PR or a merge preserving the same delta. The normal Linux lint job still runs the export-reader unit tests. If the actual merge contains additional changes, reevaluate the path filter from that actual delta.

Scorecard has main-push, scheduled, branch-protection-rule and manual triggers, but no PR trigger. A successful Scorecard job proves execution/upload succeeded; the workflow defines no score threshold or assertion that every reported security practice passes. Findings remain a separate matter.

The release workflow requires a `v*` tag. The QA-001 investigation workflow requires manual dispatch. Neither is triggered by this PR or a normal main merge.

## Sources and limits

Workflow definitions inspected at the immutable source:

- [Core CI](https://github.com/djshellshoxxx/circula/blob/81f6bf5d0e073d4be78118f5baf3d8946b8347d5/.github/workflows/ci.yml)
- [Native reader](https://github.com/djshellshoxxx/circula/blob/81f6bf5d0e073d4be78118f5baf3d8946b8347d5/.github/workflows/export-reader.yml)
- [Scorecard](https://github.com/djshellshoxxx/circula/blob/81f6bf5d0e073d4be78118f5baf3d8946b8347d5/.github/workflows/scorecard.yml)
- [Release triggers](https://github.com/djshellshoxxx/circula/blob/81f6bf5d0e073d4be78118f5baf3d8946b8347d5/.github/workflows/release.yml)
- [Manual QA-001 triggers](https://github.com/djshellshoxxx/circula/blob/81f6bf5d0e073d4be78118f5baf3d8946b8347d5/.github/workflows/qa001-manual.yml)

Read-only local Git/workflow inspection and native GitHub GETs only. No product tests, repository edits, remote mutations or long polling. Excluded modules and held policy PRs were not inspected. Root retains integration ownership.
