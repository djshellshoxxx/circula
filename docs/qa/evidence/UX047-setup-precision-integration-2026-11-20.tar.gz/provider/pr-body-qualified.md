## Why

Selecting one decimal place in setup could produce “1 decimal places” when the default credit limit or sign-up grant was invalid. The wording appeared in both the linked error summary and the inline field correction.

## What changes

- Give the existing `setup.amount.invalid` catalogue entry singular and plural forms, with integer precision as the first formatter argument.
- Add message and authenticated HTTP regressions for both amount fields at precisions 0, 1, 2 and 4. The handler checks preserve exact examples, retained and escaped values, summary links, inline errors, ARIA associations and HTTP 422 before network creation.
- Refresh the current Core handoff and stale UX-047 missing-flow descriptions, regenerate traceability, and retain the complete local evidence and independent reviews.

The production change is one caller argument reorder and one existing catalogue entry. Amount parsing, precision bounds, setup authorization, CSRF and setup-secret behavior are unchanged. UX-047 remains partial.

## Validation at this source

Source commit: [`81f6bf5d0e073d4be78118f5baf3d8946b8347d5`](https://github.com/djshellshoxxx/circula/commit/81f6bf5d0e073d4be78118f5baf3d8946b8347d5)  
Base: `87651d36558a8e421e41fbd76c514045d88c74ed`  
Tree: `1f96de30d05b7886736315d07bf5820b6d37d995`

| Check | Result |
| --- | --- |
| Baseline red | Only the two precision-one message cases and precision-one HTTP case fail; other precisions and the existing invalid-precision guards pass. |
| Focused green | 23 named pass events, zero failures/skips. |
| Complete messages race suite | 49 top-level tests / 351 named pass events, zero failures/skips. |
| Setup/onboarding race selection | Seven top-level tests / 17 named pass events, zero failures/skips. |
| Affected-package vet and executable build | Passed. |
| gofmt, diff check, repository hygiene, traceability generation/freshness | Passed. |
| Independent code/standards, acceptance/security and documentation/evidence reviews | Approved with zero blocking findings. |

The first local build failed because Go selected the workspace parent for Git metadata in a linked worktree. An identical full Git checkout built successfully with default VCS stamping enabled; both attempts are retained.

[Qualification note](https://github.com/djshellshoxxx/circula/blob/81f6bf5d0e073d4be78118f5baf3d8946b8347d5/docs/qa/UX047-setup-precision-2026-11-20.md) · [Raw evidence and reviews](https://github.com/djshellshoxxx/circula/blob/81f6bf5d0e073d4be78118f5baf3d8946b8347d5/docs/qa/evidence/UX047-setup-precision-2026-11-20.tar.gz)

## PR CI qualification

[Run 44869522658](https://github.com/djshellshoxxx/circula/actions/runs/44869522658) passed all seven applicable Linux jobs on attempt 1 at source `81f6bf5d0e073d4be78118f5baf3d8946b8347d5`. Its actual checkout was synthetic merge `733c82965f731f61119e431ea93de2d709361fc0`, whose parent and tree checks match the reviewed base/source.

- Full Linux race artifact: 3,272 named passes, six explicit named skips, zero failures; exit 0 and a clean recorded checkout. All 14 new regression/parent/subtest events pass.
- Browser/accessibility/keyboard suite: 597 passed.
- Lint/vet/vulnerability checks, API contract/load smoke, reproducibility, fuzz and all five packaged targets pass.
- PR cross-platform execution is conditionally skipped by the unchanged workflow and is not counted as a pass. The native-reader workflow is inapplicable because none of its path filters changed.
- Test artifact `14694236500` is verified against SHA-256 `497625b5a948c3a5b6a90bcc9cbaafda7926b16c5f9e9e124fabda3eb6086108`.

Actual-main qualification remains a separate gate after normal integration. UX-047 remains partial; translation and locale scope remain product decisions.
