# Selected-zone session-warning source review

Reviewed November 27, 2026 Pacific. **No remaining actionable product-source blockers found in the current bounded patch. Native Go/HTTP/browser qualification remains required.**

## Scope and source

Fresh connected GitHub main remains `3faeed76c41467a75b09bc75e7185a98a92f8219`. Reviewed the pinned base and staged changes under `ux047-next/green`: `internal/web/render.go`, `internal/web/h_account.go`, `internal/web/templates/base.html`, `internal/web/static/app.js`, and `scripts/test_app_messages.cjs`. Also inspected existing authentication/display-zone loading and the production catalogue date formatter. No unrelated feature, held-policy or future-module work was inspected or changed.

The confirmed defect is a display-zone inconsistency, touching UX-024 and the existing UX-047 catalogue-owned date/time presentation. The old browser `clock()` uses browser-local hours/minutes rather than the person's saved display zone. The patch supplies an already-formatted plain-text expiry while retaining the Unix timestamp for scheduling. The visible value now includes the catalogue's existing date, clock and zone abbreviation; it selects no new language or locale policy.

## Blocker found and resolved during review

The first staged extension implementation formatted `c.at(...)` without loading the person's preference. `s.auth` creates an `rc` with `loc == nil`; only `netH` and rendering otherwise load the zone. Therefore `/session/extend` would have returned UTC for a person with a non-UTC preference. I reported this to the coordinator and test builder. The current `sessionExtend` explicitly calls `c.loadDisplayZone()`, resolving that dataflow defect. The new authenticated-endpoint regression should exercise a persisted preference through the real wrapper rather than pre-populating `rc.loc`.

## Current findings

- Initial page text uses `page.SessionExpiryText()`, `page.localTime()` and `messages.DateTime()`. Existing render paths assign `page.displayZone` from the request context; absent context/preference falls back to UTC as before.
- The extension endpoint loads the current preference and formats the same numeric expiry through `messages.DateTime(c.at(time.Unix(at, 0)))`. Its new `expires_text` string is additive; existing `expires` and `extendable` values and service authentication/expiry behavior are unchanged.
- The shared template keeps ordinary contextual attribute escaping. The browser inserts the supplied string through function-based placeholder replacement and `textContent`, retaining literal dollar sequences and markup-like text without HTML interpretation.
- Numeric expiry, warning lead time, timeout scheduling, extension request URL/method/credentials/CSRF, dismissal, navigation and draft retention logic are unchanged.
- Older cached pages or old responses lacking presentation text deliberately retain the existing browser-clock fallback. On extension the previous label is cleared when the new response omits it, preventing stale expiry text. This compatibility fallback is not a guarantee that old server/page combinations honor the saved zone.
- Some existing authenticated/public render paths pass nil viewer context. This slice retains their explicit UTC fallback rather than re-authenticating or expanding many handlers. Where no context is available the new text labels UTC; it does not falsely certify that every authenticated shared-shell page honors the preference. Broader nil-context wiring remains a separate UX-024 assessment.
- The endpoint remains authenticated and wrapped by existing request/CSRF/cache controls. The patch adds no network/tenant selection, ledger write, session-authority rule, storage migration or raw API notification change.

## Independently executed verification

Executed `node --test scripts/test_app_messages.cjs` from the staged green directory: **18 passed, zero failures/skips/cancellations**. This is mock-DOM/helper execution, not an actual browser. The two new controls cover literal server-formatted initial text in both extendable/fixed modes and replacement text after extension while preserving timer/draft assertions. Existing fallback and request-contract controls continue to pass.

The coordinator's saved regression-only log records 16 passes and two expected failures before the product changes. I read that evidence but did not independently rerun the red source.

No Go compiler, Go tests, vet, race suite, real HTTP server or browser was executed by this reviewer. The local command named `go` is GNU Go rather than the required compiler. The builder's new Go template/authenticated-endpoint regressions were still being prepared when this review was written; their source and native execution need follow-up before integration. Required exact-head CI and later actual-main checks are separate gates. Manual screen-reader, external security review and whole UX-047/UX-024/locale completion are not certified here.

I made no product edits or GitHub mutations.
