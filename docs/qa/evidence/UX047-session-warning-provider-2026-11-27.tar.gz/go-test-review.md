# PR #143 final Go regression source review

Reviewed November 27, 2026 Pacific. **No actionable blockers found in the final committed regression source. This is source review, not local Go execution or full CI qualification.**

## Exact source and scope

Fresh connected GitHub PR #143 returned head `5523f848aab15e1d7eb8090b36e56019f5c81a63`, base `3faeed76c41467a75b09bc75e7185a98a92f8219`, still draft. Independently fetched `internal/web/session_warning_zone_test.go` at that exact head: provider Git blob `01cf7c25384efedc68edee576d60f939856a9822`. Local `git hash-object` on the staged green test file returned the identical blob. Also read exact-head `h_account.go`, `session.go`, `web.go`, service timezone implementation and deterministic test environment helpers.

## Findings

`TestSessionWarningTemplateUsesDisplayZone` renders the real freshly loaded shared shell with existing page data. Six cases distinguish absent/explicit UTC, a half-hour zone, local date rollover, and Berlin winter/summer offsets. Exact `data-expires-text`, numeric `data-expires`, and extendable attributes are asserted. It does not merely call the new formatting helper and repeat its implementation. The selected-zone cases would fail a UTC-only implementation, and every case would fail the old template lacking the new presentation attribute.

`TestSessionWarningHTTPUsesSavedDisplayZone` uses fresh SQLite/service environments, persisted `SetTimeZone`, ordinary `Login` and the actual wrapped server mux. It does not manually populate `rc.loc`. The clock is set before account creation and sign-in; each request remains at the same deterministic instant, so the expected one-hour advisory expiry is exact. The test environment's `Advance` supports the supplied durations, including the winter fixture before its default March clock. Embedded timezone data supports the named zones independent of host files.

The account sessions GET must return 200 with the exact saved-zone attribute. POST `/session/extend` passes through production request wrapping, authentication and CSRF validation, and must return 200 with unchanged Unix expiry/extendability and the expected selected-zone text. These assertions cover the review-discovered need for `sessionExtend` to call `c.loadDisplayZone()`; the exact committed handler now does so. The generated session-bound CSRF token matches existing middleware binding, and a separate request omitting that token must receive 403.

The password-page control deliberately retains the documented nil-viewer-context UTC fallback. It prevents the bounded slice from silently claiming that all authenticated shared-shell handlers already carry a selected zone. It is a compatibility assertion, not proof that the broader nil-context UX-024 work is complete.

The tests exercise presentation and retain numeric scheduling contracts. They add no production service, storage, authorization, policy, inbox or ledger behavior. Expected strings are independent fixed English values; the template test escapes them for the attribute context. The existing JavaScript controls separately cover literal dollar/markup text, initial fixed/extendable warnings and updated text after extension.

## Limits

I did not execute Go compilation/tests, vet, race, browser or a live HTTP listener. The local `go` command is GNU Go rather than the required compiler. These Go tests were reviewed as source against the real helper/handler contracts; native CI must supply their execution results. The root coordinator retains current-head Core run `46090029432`, complete artifact inspection and any failure repair. No pending job is counted as a pass here.

The previous independent review's 18 Node helper passes remain mock-DOM evidence, separate from Go/HTTP/browser qualification. Nil-context UTC and old-cache browser-clock fallbacks, manual screen-reader work, external security review and whole UX-024/UX-047/locale completion remain explicit limits. I made no code edits or GitHub mutations and did not inspect held policies, future modules or #142 inbox work.
