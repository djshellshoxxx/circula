# Current-source UX-047 investigation — shared session expiry presentation

Source reviewed: `djshellshoxxx/circula@3faeed76c41467a75b09bc75e7185a98a92f8219`.
No product/source edits or GitHub mutations. All #142 inbox/notification paths, policy-held work and future modules excluded.

## Result

A concrete **selected-time-zone inconsistency** remains in the shared session-expiry warning. This directly concerns UX-024 display time zones and the shared date/time presentation used by UX-047. It should not be described as proof of a new untranslated English sentence or as whole-UI localization incompleteness by itself.

The inspected `format.go` financial/status rows already use catalogue text. `render.go` already delegates dates and month order to `messages.Date`/`DateTime`; those completed migrations must not be repeated. The shared document-title catalogue is also already integrated.

## Exact mechanism

- `internal/web/session.go`: `rc.loc` is documented as the person's display time zone; `loadDisplayZone` obtains it from the service, and network handlers load it.
- `internal/web/render.go`: `page.displayZone` receives `c.loc`; server `when` renders timestamps in it.
- `internal/web/messages/en.json`: `time_zone.display` says “Pages show times in your time zone.” Its display-only API/audit UTC boundary is explicit.
- `internal/web/templates/base.html`: the session warning passes only `data-expires` (epoch seconds), extendability and complete catalogue sentences with a `{time}` placeholder. It sends neither chosen zone nor preformatted display time.
- `internal/web/static/app.js`: `clock(ms)` constructs `HH:mm` using `new Date(ms).getHours()` and `getMinutes()`, which use the browser's zone. The saved account zone is absent.
- Both initial warning and post-extension warning call this same function. The actual expiry scheduling remains epoch based, so the evidenced defect is display only, not an authentication/expiry enforcement change.

## Independently executed bounded proof

Fetched exact source app.js (provider blob `c74fa68ad3e597389e6c28b76f3a169917c466d2`) and saved the unmodified text as `ux047-next/pinned-app.js`.
Executed the extracted production `clock(ms)` in Node `v24.22.3` with an explicit UTC runtime-zone fixture:

```text
expiry: 2026-11-28T00:00:00Z
browser-zone fixture: UTC
account zone: Asia/Kolkata
production clock: 00:00
selected-account-zone control: 05:30
```

The control used `Intl.DateTimeFormat('en-GB', {timeZone:'Asia/Kolkata', hour:'2-digit', minute:'2-digit', hourCycle:'h23'})` on the same epoch. This is native JavaScript logic evidence, not an actual browser run, full application fixture or new test-suite pass. Go is GNU Go here; no compiler/Go/race/vet/browser execution claimed.

## Existing regression gap and bounded recommendation

`scripts/test_app_messages.cjs` covers initial/fixed/extended warning text but accepts no account display-zone fixture. Its expected `clock(time)` helper also uses `getHours/getMinutes`, reproducing the same browser-zone assumption. `TestProgressiveCatalogueTemplate` checks catalogue message attributes and exact epoch but no selected zone. Those tests therefore do not detect this discrepancy.

If selected by the coordinator, add a failing deterministic regression to the existing mock-DOM warning suite with browser UTC and selected Asia/Kolkata, verifying both initial and post-extension text use the selected display zone while the epoch warning/expiry boundaries remain unchanged. Include UTC/default control and a daylight-saving zone spanning an expiry/extension boundary. Extend the real-template/handler check to prove the selected display context reaches JavaScript; do not prove only an isolated helper.

Small coherent repair choices:
1. Supply server catalogue-formatted expiry text for initial render and successful extension response, avoiding a second formatting policy; or
2. Supply the validated IANA display-zone attribute and use deterministic English clock formatting in that zone, preserving the existing language and keeping all visible sentence text in the catalogue.

The coordinator should choose based on the current session-extension handler contract. Preserve route, CSRF, session lifetime, actual expiry arithmetic and unsent-form behavior. Changing a warning's display zone must not claim timezone enforcement/expiry policy changes. Keep #142 source/ownership and separate owner merge gate untouched.

## Not a recommended new gap

The header brand still writes literal product name `Circula` plus network name. That is a proper-name/accessibility-label composition question and weaker evidence than the concrete session-clock discrepancy; do not manufacture a localization defect from a product name.
