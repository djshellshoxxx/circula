# PR #142 independent Core source review

Reviewed November 27, 2026 Pacific against fresh connected GitHub source. **No actionable source-review blockers found for the bounded UX-047 platform-suspension inbox change.** This is an engineering review, not owner merge approval or external security acceptance.

## Exact scope

- PR #142 is open and draft at source `78e254f4f1b8283c124274e0a6a1ba2b82959a0f`, base `3faeed76c41467a75b09bc75e7185a98a92f8219`.
- Reviewed the complete provider diff, new integration regressions, source qualification note, notification producer, inbox handler/template, messages implementation, existing category-label helper, service notification scoping, API DTO and relevant decision-log text.
- Production changes are limited to the HTML inbox presentation helper/caller and two English catalogue entries. Tests and documentation are additional changes. No service, API, storage, schema, suspension enforcement or policy implementation changed.

## Findings

The recognizer requires the existing suspension kind and exact platform title, empty link, absent event-date context, known category prefix, complete producer suffix and nonempty already-trimmed reason. These conditions match the current PlatformSuspendNetwork producer, which validates the category and trims the reason before storage. Four fixed domain values reuse networkSuspensionCategory and its existing English labels.

CutPrefix and CutSuffix remove only the outer stored envelope. Reason text, including repeated envelope text, category codes, Unicode, percent signs and markup-like strings, passes unchanged as a string argument to a complete catalogue sentence. messages.Text returns ordinary string, and the unchanged inbox template renders Body with html/template escaping. No trusted-markup conversion was introduced.

The helper uses only the notification record, not the network's current suspension state. Later replacement or resumption therefore cannot reclassify old notices. Unknown, modified, redacted, linked or event-dated records return their stored title/body. Existing dated-body handling remains separate and unchanged.

The renderer creates row-local strings without mutating notification records. API toNotification still returns stored title/body directly. The service ListNotifications path still selects the caller's membership and network; the diff changes no query, authorization, recipient selection, pagination or route. No additional tenant disclosure surface or automatic blocking behavior appears in this bounded change.

## Regression assessment

TestPlatformSuspensionInboxPreservesHistoryAndAPI exercises real service producers, SQLite, normal login/authentication middleware, the HTML template and JSON API through in-process HTTP recorders. Four platform categories are checked after each replacement and resumption, with adversarial literal reasons; administrator notices remain separate. Stored notifications and API bytes are compared before and after inbox reads, and API values are checked against the stored originals.

TestPlatformSuspensionInboxKeepsUnrecognizedRecords covers 13 precise fallback cases, including other kind/title, unknown category, malformed envelopes, empty/noncanonical reason, redaction, link and future event context. Rendered fallback title/body are checked for contextual escaping. Catalogue tests cover both key signatures and the full formatted sentence. These are meaningful end-to-end presentation regressions rather than merely mirroring the helper implementation.

The reported regression-only red/green source and local test counts remain author-provided evidence. I did not re-execute Go, race, vet or browser locally; the executable called go in this environment is GNU Go, not the required compiler.

## Fresh provider and gate observations

Fresh native CI jobs read for run 45836478829 returned all seven applicable jobs successful: fuzz smoke, API/load smoke, Linux race tests, release-target build, browser, reproducible build and lint/vet/gofmt/govulncheck. The conditional native PR matrix is skipped as configured. This reviewer checked job conclusions, not the full Linux ZIP or browser log/count; the coordinator owns artifact qualification.

The source qualification and draft PR explicitly retain separate owner merge authorization. This review does not remove that gate, mark the draft ready, change branches or certify actual-main integration. Whole UX-047 remains partial; manual screen-reader, independent external security review, locale/product decisions and bounded qualification limits remain open. Held policy PRs and all future modules were not inspected or changed.

No code edits or GitHub mutations were made.
